<?php 
$last="";
$var ="hello";
for($i=0;$i<2;$i++)
{
echo $i;

	
	$last.=",".$var;
	echo $last;	
}
?>