<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
 
                 
<link href="uploadify.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-3.2.1.min.js"
  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"></script>
<script type="text/javascript" src="uploadify.swf"></script>
<script type="text/javascript" src="jquery.uploadify.min.js"></script>
 <script type="text/javascript">
$(document).ready(function() {
	alert("hello");
  $('#file_upload').uploadify({
    'uploader'  : 'uploadify.swf',
    'script'    : 'upload.php',
    'cancelImg' : 'cancel.png',
    'folder'    : 'uploads',
    'auto'      : true
  });
});
</script>
</head>
<body>
	<input id="file_upload" name="file_upload" type="file" />
</body>
</html>