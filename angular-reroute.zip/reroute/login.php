<?php error_reporting(0);?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="node_modules/angular/angular.min.js"></script>
</head>
<body>
<div class="container">
    <div class="row">
        <h4 class="page-header">Welcome back.</h4>
    <form name="login_form" action="login_submit.php">
                <div class="col-md-6">
            <div class="jumbotron">
                <h3  class="page-header">Login</h3>
                <?php if($_REQUEST['user']=='fail') {?>
                <div class="alert alert-danger">!Invalid Username</div>
                <?php } else if($_REQUEST['pass']=='fail') { ?>
                <div class="alert alert-danger">!Invalid Password</div>
                <?php } else if($_REQUEST['login']=='fail') { ?>
                <div class="alert alert-danger">Incorrect Username and Password</div>
                <?php } ?>
                <div class="row">
                    <div class="form-group">
                        <label class="control-label">UserName</label>
                        <input type="text" class="form-control"  name="username" placeholder="UserName">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label class="control-label">Password</label>
                        <input type="password" class="form-control"  name="password" placeholder="***************">
                    </div>
                </div>
                <div class="row">
                    <button class="btn btn-primary" name="login">Login</button>
                </div>
            </div>
        </div>
    </form>
        <div class="col-md-6" ng-app="signupApp" ng-controller="signupCtrl">
            <form name="registerForm" id="registerForm" ng-submit="register()">
            <div class="jumbotron">
                <h3 class="page-header">Register Yourself!!</h3>
                <div class="alert alert-success" ng-show="msg" ng-cloak>{{msgData}}</div>
                <div class="row">
                    <div class="form-group">
                        <label class="control-label">Name</label>
                        <input class="form-control" type="text" name="name" required autocomplete="off" ng-model="dataFrm.name">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label class="control-label">Email Address</label>
                        <input class="form-control" type="email" required name="email" autocomplete="off" ng-model="dataFrm.email">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label class="control-label">Mobile</label>
                        <input class="form-control" type="text" required maxlength="10" name="mobile" autocomplete="off" ng-model="dataFrm.mobile">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label class="control-label">Password</label>
                        <input class="form-control" type="password" autocomplete="off" required name="password" ng-model="dataFrm.password">
                    </div>
                </div>
                <div class="row">
                    <span style="color: red;" ng-show="errCpass" ng-cloak>{{cPassVal}}</span>
                    <div class="form-group">
                        <label class="control-label">Confirm Password</label>
                        <input class="form-control" type="password" required autocomplete="off" name="cPass" ng-model="dataFrm.cPass">
                    </div>
                </div>
                <div class="row">
                   <input type="submit" class="btn btn-warning" name="signup" ng-disabled="registerForm.$invalid" value="Register">  
                </div>
            </div>
        </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="controller/register.js"></script>
</body>
</html>