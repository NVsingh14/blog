
var mysignup = angular.module('signupApp',[]);

mysignup.controller('signupCtrl',['$scope','$http','$timeout','$window',function($scope,$http,$timeout,$window) {
	$scope.dataFrm = {};
	$scope.register = function()
	{
		if($scope.dataFrm.password===$scope.dataFrm.cPass)
		{
			$scope.errCpass=false;
			$http.post('user_signup.php',{data:$scope.dataFrm})
			.then(function(response){
                            //console.log(response);
                            $scope.dataFrm=null;
                            //$scope.listLoader=true;
                            $scope.msg=true;
                            $scope.msgData="Registration Successfull";
                            $timeout(function(){
                                //$scope.listLoader=false;
                                $scope.msg=false;
                            },2000)

                        })
		}
		else {
			$scope.errCpass=true;
			$scope.cPassVal="Please Enter The Same Password";
		}
	}
	
    }]); //end of controller 