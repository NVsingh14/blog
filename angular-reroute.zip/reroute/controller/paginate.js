
	app.filter('beginning_data',function(){
		return function(input,begin) {
			if(input) {
				begin = +begin;
				return input.slice(begin);
			}
			return [];
		}
	});

	app.controller('paginateCtrl', ['$scope','$http','$timeout','$window','$location',function($scope,$http,$timeout,$window,$location) {

		$http.get('fetch_category_data.php').success(function(user_data) {
			$timeout(function(){
			$scope.listLoader=false;
			$scope.filter_data=$scope.file.length;
			},1000)
			$scope.listLoader=true;
			$scope.filter_data=0;
			$scope.file = user_data;
			$scope.current_grid = 1;
			$scope.data_limit =10;
			//$scope.filter_data = $scope.file.length;
			$scope.entire_user = $scope.file.length;
		});

		$scope.page_position = function(page_number)
		{
			$scope.current_grid = page_number;
		};
		$scope.filter = function()
		{
			$timeout(function(){
				$scope.filter_data=$scope.searched.length;
			},20);
		};

		$scope.sort_with = function(base)
		{
			$scope.base = base;
			$scope.reverse = !$scope.reverse;
		};

		$scope.delete_data = function(did)
		{
			var c = confirm("Are you Sure You Want To Delete?");
			if(c)
			{

			$http.post('delete.php',{id:did,table:'category',field:'cat_id'}).then(function(response){
				//$scope.listLoader=true;
				console.log(response);
				$scope.msg=true;
				$scope.msgData="Data Deleted Successfully";
				//return false;
				$timeout(function(){
					$scope.msg = false;
					$window.location.reload();
				},2000)
				//alert('enter console');
				
			}); //end of post 

			} //end of if
			else
			{
				return false;
			}
		}


	}]); //end of controller