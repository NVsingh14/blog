<?php 

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
$REQ = $REQData->call;

	
		if(preg_match('/^[a-z]A-Z0-9_]+$/', $REQ)) {
			$classname = $REQ;
			$obj = new $classname;
			$obj->REQData = $REQData;
			$obj->startProcessing();
		}
		else
		{
			//PROBLEM WITH THE REQUEST ======
			exit;
		}
?>