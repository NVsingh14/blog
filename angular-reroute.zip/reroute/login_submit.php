<?php 
require_once('config/config.php');
include_once('class/class.main.php');

if(isset($_REQUEST['username']) && ($_REQUEST['password']))
{
	$username = $_REQUEST['username'];
	$pass = md5($_REQUEST['password']);
	$sql = $dbo->prepare("select * from user where email='".$username."' and password='".$pass."' ");
	$sql->execute();
	if($sql->rowCount()>0 )
	{
		$rec = $sql->fetch(PDO::FETCH_ASSOC);
		session_start();
		$_SESSION['username'] = $rec['name'];
		$_SESSION['user_id'] = $rec['id'];
		$_SESSION['email'] = $rec['email'];
		header('Location:index.php');
	}
	else
	{
		header('Location:login.php?login=fail');
	}

}
else if($_REQUEST['username']=='')
{
header('Location:login.php?user=fail');
}
else if($_REQUEST['password']=='')
{
header('Location:login.php?pass=fail');
}
?>