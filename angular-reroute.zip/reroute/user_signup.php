<?php 
error_reporting(0);
require_once('config/config.php');
include_once('class/class.main.php');
$data = json_decode(file_get_contents("php://input"));

$name = $data->data->name;
$email = $data->data->email;
$mobile = $data->data->mobile;
$pass = $data->data->password;
$password = md5($pass);

$res = $objmain->signup($name,$email,$mobile,$password);
if($res==1)
{
	echo"Data Inserted";
}
else
{
	echo "try again";

}
?>