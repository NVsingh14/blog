<!DOCTYPE html>
<html>
<head>
	<title>Form</title>
</head>
<body>
	<form method="post">
<label>Q->1 : </label><p>What is my name</p>
<input type="radio" name="one" value="abc">Abc
<input type="radio" name="one" value="xyz">Xyz
<input type="radio" name="one" value="def">def
<input type="radio" name="one" value="jkl">jkl
<input type="submit" name="sub">
</form>
<?php 
if(isset($_POST['sub']))
{
	$value = $_POST['one'];
	$str='abc';
	if($value==$str)
	{
		echo"ABC";
	}
	else{
		echo "other";
	}
}
?>
</body>
</html>