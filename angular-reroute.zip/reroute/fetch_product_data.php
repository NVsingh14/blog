<?php 
error_reporting(0);
include('config/config.php');
	$res = json_decode(file_get_contents("php://input"));
	//echo $data->id;
	if($res->id>0)
	{

		$sql = $dbo->prepare("select * from product where p_id='".$res->id."' ");
		$sql->execute();
		$no = $sql->rowCount();
		if($no>0)
		{
			while($row=$sql->fetch(PDO::FETCH_BOTH))
				{
					$data[] = array('id'=>$row['p_id'],'prd_name'=>$row['product_name'],'item_code'=>$row['item_code'],'editor1'=>$row['description'],'prd_price'=>$row['price'],'discount_flat'=>$row['discount_flat'],'discount_percent'=>$row['discount_percent'],'slug'=>$row['slug'],'image'=>$row['feature_img']);
				}
		}

	}
	else
	{
	$sql = $dbo->prepare("select * from product order by p_id asc");
	$sql->execute();
	$no = $sql->rowCount();
	if($no>0)
	{
		while($row = $sql->fetch(PDO::FETCH_BOTH))
			{
				$data[] = $row;
			}
	}


}
	echo json_encode($data);
?>