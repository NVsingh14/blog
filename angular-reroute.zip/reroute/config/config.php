<?php 
$hostname="localhost";
$user="root";
$pass="";
$dbname="admin";

try{
	$dbo = new PDO('mysql:host='.$hostname.';dbname='.$dbname,$user,$pass);
}
catch(PDOException $e)
{
	print"Error".$e->getMessage();
}
?>