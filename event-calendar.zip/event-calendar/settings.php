<?php

/* Google App Client Id */
define('CLIENT_ID', '456457157639-8hnq5idj9t4ja6g4r0dj6li2t5rri4h0.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'v3HlbYqpZMfO8IzaQPfMw2bd');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost/event-calendar/google-login.php');

?>