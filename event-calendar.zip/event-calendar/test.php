<?php
	session_start();
	require_once('google-calendar-api.php');

	print_r($_SESSION['access_token']);

	$capi = new GoogleCalendarApi();
	$calendar_id = "ddlcoucrin1ts6ups2cthkasm0@group.calendar.google.com";
	// $user_timezone = $capi->GetUserCalendarTimezone($_SESSION['access_token']);
	$event_id = $capi->GetCalendarEvent($calendar_id,'', '', '', '$user_timezone', $_SESSION['access_token']);

	print_r($event_id);
?>