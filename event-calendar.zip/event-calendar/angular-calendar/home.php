<?php 
session_start();
if(!isset($_SESSION['access_token'])) {
  header('Location: google-login.php');
  exit(); 
}
error_reporting(0);
ob_start();
include("header.php");
define("PAGE_AJAX","ajax_phone_cost.php"); 

?>
<style>
mwl-calendar .event
{
    display: none;
}
</style>
<div class="headingWrap">
    <div class="container">
        <div class="headingTitle">
             <div class="row">
                 <div class="col-sm-6">
                     <h1>Calendar Testing</h1>
                     <!--a target="" href="https://calendar.google.com/calendar/embed?src=kn39i685cvlsbfmh2svarh378o%40group.calendar.google.com&ctz=Asia%2FCalcutta"><img border="0" src="https://www.google.com/calendar/images/ext/gc_button1_en.gif"></a-->
                 </div>
                 <div class="col-sm-6">
                    <div class="pull-right"></div>
                 </div>
            </div>
        </div>
    </div>
</div> 
<div class="container theme-showcase mainWrp" ng-controller="phoneCostController">
    
    <div class="row">
            <div class="col-md-6">
                <div class="box box-success">
                    
                        <h3 class="box-title" ng-cloak>{{cTitle}}</h3>
                   
                    <div class="box-body">
                        
                            
                            <!--CALENDAR TESTING STARTS ================================== -->
                             <div class="row">
                                  
                                 
                                <div class="col-md-10 col-sm-12"> 
                                        <h2 class="text-center" ng-cloak>{{ calendarTitle }}</h2>
                                        <button
                                          class="btn btn-primary"
                                          mwl-date-modifier
                                          date="viewDate"
                                          decrement="calendarView">
                                          Previous
                                        </button>
                                        
                                        <button
                                          class="btn btn-default"
                                          mwl-date-modifier
                                          date="viewDate"
                                          set-to-today>
                                          Today
                                        </button>
                                        
                                        <button
                                          class="btn btn-primary"
                                          mwl-date-modifier
                                          date="viewDate"
                                          increment="calendarView">
                                          Next
                                        </button>
                                    
                                    
                                    <mwl-calendar
                                        view="calendarView"
                                        view-date="viewDate"
                                        events="events"
                                        view-title="calendarTitle"
                                        on-event-click="eventClicked(calendarEvent)"
                                        
                                        cell-is-open="true">
                                    </mwl-calendar>
                                </div>
                            </div> 
                            
                            <!--CALENDAR TESTING ENDS ================================== -->
                             
                        
                    
                    </div>
                </div>
            </div>
       
        
        <div class="col-md-6">
            <div class="box box-success">
                
                  <!--h3 class="box-title">Manage</h3-->

                  <div class="pull-right totalRcrds" ng-show="allListArray.length > 0" >
                 
                 TESTING DATA : {{totalItems}}
            </div>
                
                <!--div class="box-body">
                    <div ng-show="listPageLoader" class="loadDiv" style="z-index: 9999; text-align:center; height:200px; width:100%;">
                        <img src="<?php echo LOGIN_IMAGES;?>load.gif">
                    </div>
                    
                    <div ng-if="allListArray.length" ng-cloak>     
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th width="10%" class="text-center">Status </th>
                                        <th class="text-left" width="20%">Time(In Minutes)</th>
                                        <th class="text-left" width="20%">Cost(INR)</th> 
                                        <th class="text-left" width="20%">Cost(USD)</th>
                                        <th width="20%" class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr dir-paginate="listObj in allListArray | itemsPerPage: itemsPerPage" total-items="totalItems" current-page="pagination.current" ng-style="{{ listObj.entities_count > 0 && {'font-weight':''} || '' }} " >
                                        <td class="text-center"> 
                                            <div ng-init='listObj.loading = false' >
                                                <a href="javascript: void(0)" ng-click="updateStatus(listObj.phone_cost_id,listObj.status,$index)" ng-hide="listObj.loading">
                                                <span title="{{ listObj.status!=0 ?'Active' : 'In-Active'}}" ng-class="listObj.status == 1 && 'fa fa-check-circle-o green font22' || 'fa fa-times-circle-o red font22'" aria-hidden="true"></span>
                                                </a> 
                                                <span ng-show="listObj.loading" class="loadStatus"><img src="<?php echo LOGIN_IMAGES;?>load.gif" /></span>
                                            </div>
                                        </td>
                                             
                                        <td class="text-left">{{listObj.call_time}}</td>
                                        <td class="text-left">{{'Rs ' + listObj.call_cost_inr}}</td>
                                        <td class="text-left">{{'$' + listObj.call_cost_usd}}</td>
                                        <td align="center"> 
                                           
                                                <a type="button" class="btn btn-xs btn-primary" href="javascript: void(0)" ng-click="modifyData(listObj.phone_cost_id)"><i class="fa fa-cogs" aria-hidden="true"></i> Edit</a>
                                                <a type="button" class="btn btn-xs btn-danger" href="javascript:void(0);" ng-click="listObj.vCount>0 || deleteData(listObj.phone_cost_id)" ng-disabled='listObj.vCount>0' ><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a>
                                         </td>
                                    </tr> 
                                </tbody>
                            </table>
                        </div>
                         <div style="clear: both;"></div>
                        <dir-pagination-controls on-page-change="pageChanged(newPageNumber)"></dir-pagination-controls>
                    </div>
                    
                    <div ng-cloak ng-if="allListArray.length == 0" style="margin-top:10px; padding-bottom:30px; text-align: center; font-weight: bold;">
                        Nothing Found!
                    </div>
                
                </div-->
            </div>
        </div>
        
    </div>
   
</div> <!-- content-wrapper end -->


     
<script>
(function(){

    angular.module("iwsApp").config(['$routeProvider', function($routeProvider) {
            $routeProvider.
            when('phone_cost.php', {templateUrl: 'phone_cost.php',controller: 'phoneCostController'}).
            when('listCost/:page', {templateUrl: 'banner.php',controller: 'phoneCostController'}).
            otherwise({redirectTo: 'phone_cost.php'});
         }]);
         
     
    angular.module('iwsApp').controller('phoneCostController', ['$scope', '$http', '$httpParamSerializer', '$location', '$routeParams', 'myConfig', '$timeout', '$filter','$window','$q', 'Upload', 'calendarConfig', function($scope, $http, $httpParamSerializer, $location, $routeParams, myConfig, $timeout, $filter,$window,$q, Upload, calendarConfig){
         
        $scope.submitProcess = 0;
        $scope.submitProcessMsg = '';
        $scope.fullPageLoader = 0;
        $scope.successMsg = '';
        $scope.listPageLoader = 0;
        $scope.allListArray = {};
        $scope.dataFrm = {};
        $scope.dataFrm.status = true;
        $scope.cTitle = 'Add';
        $scope.totalItems = 0;
        $scope.itemsPerPage = '7'; // this should match however many results your API puts on one page
     
        $scope.pagination = {
                current: $routeParams.page
            };

             $scope.pageChanged = function(newPage) {
                
                
                $location.url("/listCost/" + newPage);
                $scope.listData(newPage);
            };
    
            
  //====================================================== calendar starts ===========================================================================          
      $scope.calendarView = 'month';
      $scope.viewDate = new Date();
      
      $scope.events = [
          {
                title: 'My New Event Title', // The title of the event
                startsAt: new Date(2018,1,1,9,15), // A javascript date object for when the event starts
                endsAt: new Date(2018,8,26,9,15), // Optional - a javascript date object for when the event ends
                color: { // can also be calendarConfig.colorTypes.warning for shortcuts to the deprecated event types
                  primary: '#006425', // the primary event color (should be darker than secondary)
                  secondary: '#fdf1ba' // the secondary event color (should be lighter than primary)
                },
                actions: [{ // an array of actions that will be displayed next to the event title
                  label: '<i class=\'glyphicon glyphicon-pencil\'></i>', // the label of the action
                  cssClass: 'edit-action', // a CSS class that will be added to the action element so you can implement custom styling
                  onClick: function(args) { // the action that occurs when it is clicked. The first argument will be an object containing the parent event
                    console.log('Edit event', args.calendarEvent);
                       // alert('Edit event == ' +  args.calendarEvent.startsAt.toLocaleTimeString())
                      var month = args.calendarEvent.startsAt.getMonth();
                        if(month < parseInt(10))
                        {
                            month = '0'+month;
                        }
                        var day = args.calendarEvent.startsAt.getDate();
                        if(day < parseInt(10))
                        {
                            day = '0'+day;
                        }
                        
                           var date_time = args.calendarEvent.startsAt.getFullYear() + '-' + month + '-' + day + ' ' + args.calendarEvent.startsAt.toLocaleTimeString();
                          alert("Date Time " + date_time)
                  }
                }],
                draggable: true, //Allow an event to be dragged and dropped
                resizable: true, //Allow an event to be resizable
                incrementsBadgeTotal: true, //If set to false then will not count towards the badge total amount on the month and year view
                recursOn: 'year', // If set the event will recur on the given period. Valid values are year or month
                cssClass: 'a-css-class-name', //A CSS class (or more, just separate with spaces) that will be added to the event when it is displayed on each view. Useful for marking an event as selected / active etc
                allDay: false // set to true to display the event as an all day event on the day view
          },
          {
                title: 'My Second Event Title', // The title of the event
                startsAt: new Date(2018,1,1,9,30), // A javascript date object for when the event starts
                endsAt: new Date(2018,8,26,9,30), // Optional - a javascript date object for when the event ends
                color: { // can also be calendarConfig.colorTypes.warning for shortcuts to the deprecated event types
                  primary: '#006425', // the primary event color (should be darker than secondary)
                  secondary: '#fdf1ba' // the secondary event color (should be lighter than primary)
                },
                actions: [{ // an array of actions that will be displayed next to the event title
                  label: '<i class=\'glyphicon glyphicon-pencil\'></i>', // the label of the action
                  cssClass: 'edit-action', // a CSS class that will be added to the action element so you can implement custom styling
                  onClick: function(args) { // the action that occurs when it is clicked. The first argument will be an object containing the parent event
                    console.log('Edit event', args.calendarEvent);
                        var month = args.calendarEvent.startsAt.getMonth();
                        console.log(month);
                        if(month < parseInt(10))
                        {
                            month = '0'+month;
                        }
                        var day = args.calendarEvent.startsAt.getDate();
                        if(day < parseInt(10))
                        {
                            day = '0'+day;
                        }
                        
                           var date_time = args.calendarEvent.startsAt.getFullYear() + '-' + month + '-' + day + ' ' + args.calendarEvent.startsAt.toLocaleTimeString();
                          alert("Date Time " + date_time)
                  }
                }],
                draggable: true, //Allow an event to be dragged and dropped
                resizable: true, //Allow an event to be resizable
                incrementsBadgeTotal: true, //If set to false then will not count towards the badge total amount on the month and year view
                recursOn: 'year', // If set the event will recur on the given period. Valid values are year or month
                cssClass: 'a-css-class-name', //A CSS class (or more, just separate with spaces) that will be added to the event when it is displayed on each view. Useful for marking an event as selected / active etc
                allDay: false // set to true to display the event as an all day event on the day view
          },
          {
                title: 'My Third Event Title', // The title of the event
                startsAt: new Date(2018,1,1,9,45), // A javascript date object for when the event starts
                endsAt: new Date(2018,8,26,9,45), // Optional - a javascript date object for when the event ends
                color: { // can also be calendarConfig.colorTypes.warning for shortcuts to the deprecated event types
                  primary: '#006425', // the primary event color (should be darker than secondary)
                  secondary: '#fdf1ba' // the secondary event color (should be lighter than primary)
                },
                actions: [{ // an array of actions that will be displayed next to the event title
                  label: '<i class=\'glyphicon glyphicon-pencil\'></i>', // the label of the action
                  cssClass: 'edit-action', // a CSS class that will be added to the action element so you can implement custom styling
                  onClick: function(args) { // the action that occurs when it is clicked. The first argument will be an object containing the parent event
                    console.log('Edit event', args.calendarEvent);
                        var month = args.calendarEvent.startsAt.getMonth();
                        if(month < parseInt(10))
                        {
                            month = '0'+month;
                        }
                        var day = args.calendarEvent.startsAt.getDate();
                        if(day < parseInt(10))
                        {
                            day = '0'+day;
                        }
                        
                           var date_time = args.calendarEvent.startsAt.getFullYear() + '-' + month + '-' + day + ' ' + args.calendarEvent.startsAt.toLocaleTimeString();
                          alert("Date Time " + date_time)
                  }
                }],
                draggable: true, //Allow an event to be dragged and dropped
                resizable: true, //Allow an event to be resizable
                incrementsBadgeTotal: true, //If set to false then will not count towards the badge total amount on the month and year view
                recursOn: 'year', // If set the event will recur on the given period. Valid values are year or month
                cssClass: 'a-css-class-name', //A CSS class (or more, just separate with spaces) that will be added to the event when it is displayed on each view. Useful for marking an event as selected / active etc
                allDay: false // set to true to display the event as an all day event on the day view
          },
          {
                title: 'My First Event Title', // The title of the event
                startsAt: new Date(2018,1,1,9), // A javascript date object for when the event starts
                endsAt: new Date(2018,8,26,9), // Optional - a javascript date object for when the event ends
                color: { // can also be calendarConfig.colorTypes.warning for shortcuts to the deprecated event types
                  primary: '#006425', // the primary event color (should be darker than secondary)
                  secondary: '#fdf1ba' // the secondary event color (should be lighter than primary)
                },
                actions: [{ // an array of actions that will be displayed next to the event title
                  label: '<i class=\'glyphicon glyphicon-pencil\'></i>', // the label of the action
                  cssClass: 'edit-action', // a CSS class that will be added to the action element so you can implement custom styling
                  onClick: function(args) { // the action that occurs when it is clicked. The first argument will be an object containing the parent event
                    console.log('Edit event', args.calendarEvent);
                    var month = args.calendarEvent.startsAt.getMonth();
                    if(month < parseInt(10))
                    {
                        month = '0'+month;
                    }
                    var day = args.calendarEvent.startsAt.getDate();
                    if(day < parseInt(10))
                    {
                        day = '0'+day;
                    }
                    
                       var date_time = args.calendarEvent.startsAt.getFullYear() + '-' + month + '-' + day + ' ' + args.calendarEvent.startsAt.toLocaleTimeString();
                      alert("Date Time " + date_time)
                  }
                }],
                draggable: true, //Allow an event to be dragged and dropped
                resizable: true, //Allow an event to be resizable
                incrementsBadgeTotal: true, //If set to false then will not count towards the badge total amount on the month and year view
                recursOn: 'year', // If set the event will recur on the given period. Valid values are year or month
                cssClass: 'a-css-class-name', //A CSS class (or more, just separate with spaces) that will be added to the event when it is displayed on each view. Useful for marking an event as selected / active etc
                allDay: false // set to true to display the event as an all day event on the day view
          }
           
          
          
        ];
    //====================================================== calendar ends ===========================================================================    
        $scope.submit = function() {
            //$scope.dataFrm
            $scope.submitProcess = 1;
            $scope.dataFrm.type = 'saveData';
       
            
            $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: $scope.dataFrm}).success(function(response){
                $scope.submitProcess = 2;

                if(response.SUCCESS == '1')
                {
                    $scope.submitProcessMsg = response.MSG;
                }
                else if(response.SUCCESS == '2')
                {
                    $scope.submitProcessMsg = response.MSG;
                }
                else
                {
                    $scope.submitProcessMsg = response.MSG;
                }

                $timeout(function(){
                    if(response.SUCCESS == '1') {
                        $window.location.reload();
                    }
                }, 1000);
            });

        };
        
      
        $scope.listData = function(page = 1) {
            $scope.listPageLoader = 1;
            $scope.allListArray = {};
            
            $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'listData', page: page}}).success(function(response){
                //console.log(response);
                $scope.allListArray = response.data;
                $scope.totalItems = response.total_records;
                $scope.listPageLoader = 0;
            });
        }; 
        
             
        $scope.listData();


        $scope.getEventDetails = function()
        {
             $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'getEventDetails', page: page}}).success(function(response){

                $scope.objClientList = response.data;
                //console.log($scope.objClientList);
            })
        }
        $timeout(function(){
                $scope.getEventDetails();
            }, 200);
        
        
        
        $scope.modifyData = function(phone_cost_id) {
           
            $scope.openForm = 1;
            $scope.cTitle = 'Modify';
            $scope.fullPageLoader = 1;
            $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'getDetail', 'phone_cost_id': phone_cost_id}}).success(function(response){
                
                //console.log(response);
                
                $scope.dataFrm.phone_cost_id = response.data[0].phone_cost_id;
                if(response.data[0].call_time!='')
                {
                $scope.dataFrm.call_time = response.data[0].call_time.replace(/\\/g,'');
                }
                

                if(response.data[0].call_cost_inr!='')
                {
                $scope.dataFrm.call_cost_inr = response.data[0].call_cost_inr.replace(/\\/g,'');
                }
                
                
                if(response.data[0].call_cost_usd!='')
                {
                $scope.dataFrm.call_cost_usd = response.data[0].call_cost_usd.replace(/\\/g,'');
                }
                
                
                $scope.fullPageLoader = 0;
            });
        };
        
        
        
        $scope.updateStatus = function(phone_cost_id, current_status, $index) {
            
            if(parseInt(current_status) == parseInt(1))
            {
                current_status = 0;
            }  
            else
            {
                current_status = 1;
            }
            
            
            $scope.allListArray[$index].loading = true;
            
             
            //// update ajax here ========
            $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type:'updateStatus', 'phone_cost_id': phone_cost_id, 'status': current_status}}).success(function(response){
                //console.log(response);
                $scope.allListArray[$index].loading = false;
                $scope.allListArray[$index].status = current_status;
                   
                
            }); 
        };
        
        
         
        $scope.deleteData = function(phone_cost_id) {
            var c = confirm("Are you sure you wish to delete?");
            if(c)
            {
                $scope.fullPageLoader = 1;
                
                
                $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'deleteData', 'phone_cost_id': phone_cost_id}}).success(function(response){
                    $scope.successMsg = response.MSG;

                    $timeout(function(){
                        $scope.fullPageLoader = 0;
                        if(response.SUCCESS == '1')
                        {
                            
                            $scope.cTitle = 'Add';
                            $scope.openForm = 0;
                            $scope.listData();
                            
                            $scope.dataFrm = {};
                            $scope.dataFrm.status = true;
                            
                            $scope.listData();
                        }
                    }, 1000);
                });
            }
        };  
 
   
   }]); 
   
    
})();
</script>
<?php
include("footer.php");
?>