<?php
ob_start();
error_reporting(0);

$PAGENAME = strtolower(basename($_SERVER['PHP_SELF']));
require("config-cms.php");
?>
<!DOCTYPE html>
<html ng-app="iwsApp">
<head>
	<meta content="text/html;charset=utf-8" http-equiv="Content-Type">
	<meta content="utf-8" http-equiv="encoding">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />

	<title><?php echo $_SESSION["COMPANY_NAME"];?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 	<link rel="shortcut icon" type="image/x-icon" href="<?php echo LOGIN_IMAGES; ?>favicon.ico"> -->

	<link href="<?php echo LOGIN_CSS; ?>font-roboto-condensed.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo LOGIN_CSS; ?>font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo LOGIN_CSS; ?>jquery-ui-1.10.4.css">

	<script type="text/javascript" src="<?php echo LOGIN_JS; ?>jquery-1.10.1.min.js"></script>
	<script type="text/javascript" src="<?php echo LOGIN_JS; ?>jquery-migrate-1.2.1.min.js"></script>
	<script type="text/javascript" src="<?php echo LOGIN_JS; ?>jquery-ui-1.9.1.custom.js"></script>

	<script src="<?php echo LOGIN_NODE_MODULES; ?>angular/angular.min.js"></script>
	<script src="<?php echo LOGIN_NODE_MODULES; ?>angular-route/angular-route.min.js"></script>
	<script src="<?php echo LOGIN_NODE_MODULES; ?>angular-sanitize/angular-sanitize.min.js"></script>
	<script src="<?php echo LOGIN_NODE_MODULES; ?>angular-utils-pagination/dirPagination.js"></script>

	<link href="<?php echo LOGIN_NODE_MODULES; ?>angular-ui-switch/angular-ui-switch.min.css" rel="stylesheet" type="text/css" />
	<script src="<?php echo LOGIN_NODE_MODULES; ?>angular-ui-switch/angular-ui-switch.min.js"></script>

	<script src="<?php echo LOGIN_NODE_MODULES; ?>checklist-model/checklist-model.js"></script>

    <script src="<?php echo LOGIN_NODE_MODULES;?>angular-filter-master/dist/angular-filter.min.js"></script>

	<script src="<?php echo LOGIN_NODE_MODULES; ?>ng-file-upload/dist/ng-file-upload-shim.min.js"></script> <!-- for no html5 browsers support -->
	<script src="<?php echo LOGIN_NODE_MODULES; ?>ng-file-upload/dist/ng-file-upload.min.js"></script><!-- for no html5 browsers support -->

	<link href="<?php echo LOGIN_NODE_MODULES; ?>angularjs-datepicker/src/css/angular-datepicker.css" rel="stylesheet" type="text/css" />
	<script src="<?php echo LOGIN_NODE_MODULES; ?>angularjs-datepicker/src/js/angular-datepicker.js"></script>

	<script src="<?php echo LOGIN_NODE_MODULES; ?>angular-moment-picker/js/moment-with-locales.js"></script>
	<script src="<?php echo LOGIN_NODE_MODULES; ?>angular-moment-picker/js/angular-moment-picker.min.js"></script>
	<link href="<?php echo LOGIN_NODE_MODULES; ?>angular-moment-picker/css/angular-moment-picker.min.css" rel="stylesheet">

    <script src="<?php echo LOGIN_NODE_MODULES;?>angular-bootstrap-lightbox/dist/angular-bootstrap-lightbox.js"></script> <!-- lite box open image-->
    <script src="<?php echo LOGIN_NODE_MODULES;?>ui-bootstrap-tpls-1.3.3.min.js"></script>

    <link rel="stylesheet" href="<?php echo LOGIN_NODE_MODULES; ?>ng-dialog/css/ngDialog.css" />
	<link rel="stylesheet" href="<?php echo LOGIN_NODE_MODULES; ?>ng-dialog/css/ngDialog-theme-default.css" />
	<script src="<?php echo LOGIN_NODE_MODULES; ?>ng-dialog/js/ngDialog.min.js"></script>

	<script src="<?php echo LOGIN_CKEDITOR ; ?>ckeditor.js"></script>
	<script src="<?php echo LOGIN_NODE_MODULES; ?>angular-ckeditor-master/angular-ckeditor.js"></script>
	<link rel="stylesheet" href="<?php echo LOGIN_NODE_MODULES; ?>bootstrap/dist/css/bootstrap.min.css">
    <!----------------------------------------------CALENDAR EVENT TESTING STARTS----------------------------------------------------------------------->
    <link href="<?php echo LOGIN_NODE_MODULES; ?>angular-bootstrap-calendar-master/dist/css/angular-bootstrap-calendar.min.css" rel="stylesheet">
    <script src="<?php echo LOGIN_NODE_MODULES; ?>angular-bootstrap-calendar-master/dist/js/angular-bootstrap-calendar-tpls.min.js"></script>
    <!----------------------------------------------CALENDAR EVENT TESTING ENDS----------------------------------------------------------------------->

	<link rel="stylesheet" href="<?php echo LOGIN_CSS;?>all-skins.min.css">
	<link rel="stylesheet" href="<?php echo LOGIN_CSS;?>flaticon.css">
	<link rel="stylesheet" href="<?php echo LOGIN_CSS;?>style.css">
	<link rel="stylesheet" href="<?php echo LOGIN_CSS;?>menu.css">


	<!-- App Start -->
	<script src="<?php echo LOGIN_JS; ?>app.js"></script>
	<script src="<?php echo LOGIN_JS; ?>myscript-cms.js"></script>

	<script src="<?php echo LOGIN_NODE_MODULES; ?>bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo LOGIN_NODE_MODULES; ?>angular-drag-and-drop-lists.js"></script>
    
</head>

<body class="skin-black layout-top-nav">
	<div class="clearfix mainWrap">
		<header class="main-header">
			<nav class="navbar navbar-static-top">

				<div class="container">
					<div class="row">
						<div class="col-md-2 col-sm-2 col-xs-2">
							<div class="fplogo">
								<a href="index.php">
								 <img src="kundliwala-images/logo.png" alt="KUNDLIWALA" height="90px" > 
									
								</a>
							</div>
						</div>

						<div class="col-md-9 col-sm-10 col-xs-10">
							<div class="mainMenuBar">
								<a href="javascript:void(0)" class="hamburger">
									<span class="h-top"></span>
									<span class="h-middle"></span>
									<span class="h-bottom"></span>
								</a>
								<?php
                                include ("menu.php");
                                ?>
							</div>
						</div>

						<div class="col-md-1 hidden-sm hidden-xs">
							<ul class="adminMenu">
								<li>
									<a href="javascript: void(0);" class="myadmin">
										<i class="fa fa-user" aria-hidden="true"></i>
										<?php echo ucwords($_SESSION['KW_USERDISPLAYNAME']); ?>
									</a>
									<ul class="adminSubmenu">
										<li>
											<a href="change_password.php">
												<i class="fa fa-lock" aria-hidden="true"></i>
												Change Password
											</a>
										</li>
										<li>
											<a href="logout.php">
												<i class="fa fa-sign-out __web-inspector-hide-shortcut__" aria-hidden="true"></i>
												Logout
											</a>
										</li>
									</ul>
								</li>

							</ul>
						</div>

					</div>
				</div>
			</nav>
		</header>
