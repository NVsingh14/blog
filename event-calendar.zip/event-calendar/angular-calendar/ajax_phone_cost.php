<?php 
session_start();
error_reporting(0);
include("config-cms.php");
include("../library/class.imageresizer.php");
require_once('google-calendar-api.php');

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);
//echo $type;
switch($type)
{
		case "saveData":
			saveData();
			break;
		case "listData":
			listData();
			break;
		case "getDetail" :
			getDetail();
			break;
		case "CancelGallery":
			CancelGallery();
			break;
		case "deleteData":
			deleteData();
			break;
		case "deleteAllData":
			deleteAllData();
			break;
        
        case "updateStatus":
            updateStatus();
            break;
}	
		function saveData()
		{
			global $dCON, $REQData;
            
			$IP = $_SERVER['REMOTE_ADDR'];
			$TIME = date("Y-m-d H:i:s");
			$call_time = trustme($REQData->call_time);
			$phone_cost_id=intval($REQData->phone_cost_id);
            $call_cost_inr = trustme($REQData->call_cost_inr); 
            $call_cost_usd = trustme($REQData->call_cost_usd);
           
			if(intval($phone_cost_id)==intval(0))
			{
                $CHK = checkDuplicate(PHONE_COST_TBL,"call_time~~~status","$call_time~~~2","=~~~!=");
                if(intval($CHK) == intval(0))
                {
                    $MAXID = getMaxId(PHONE_COST_TBL,"phone_cost_id");
    				$SQL = "";
    				$SQL .= " INSERT INTO " . PHONE_COST_TBL . " SET ";
    				$SQL .= " phone_cost_id=:phone_cost_id, ";
                    $SQL .= " call_time=:call_time, ";
                    $SQL .= " call_cost_inr=:call_cost_inr, ";
                    $SQL .= " call_cost_usd = :call_cost_usd, ";
                    
    				$SQL .= " add_ip=:add_ip, ";
    				$SQL .= " add_by=:add_by, ";
    				$SQL .= " add_time=:add_time ";
                    //echo $SQL;
    				$stmt = $dCON->prepare( $SQL );
    				$stmt->bindParam(":phone_cost_id", $MAXID); 
                    $stmt->bindParam(":call_time",$call_time);
                    $stmt->bindParam(":call_cost_inr",$call_cost_inr); 
                    $stmt->bindParam(":call_cost_usd",$call_cost_usd);
                     
    				$stmt->bindParam(":add_ip", $IP);
    				$stmt->bindParam(":add_by", $_SESSION['KW_USERNAME']);
    				$stmt->bindParam(":add_time", $TIME);
    				$rs = $stmt->execute();
    				$stmt->closeCursor();

                }
                else
                {
                    $rs=2;
                }

			}
			else if(intval($phone_cost_id) > intval(0) )
			{
		     $CHK = checkDuplicate(PHONE_COST_TBL,"call_time~~~phone_cost_id",$call_time."~~~".$phone_cost_id,"=~~~<>","");
               if( intval($CHK) == intval(0) )
                {  
    				$SQL= "";
    				$SQL .= "UPDATE " . PHONE_COST_TBL . " SET ";
                    $SQL .= " call_time=:call_time, ";
                    $SQL .= " call_cost_inr = :call_cost_inr, "; 
                    $SQL .= " call_cost_usd = :call_cost_usd, ";
                    
    				$SQL .= " update_ip=:update_ip, ";
    				$SQL .= " update_by = :update_by, ";
    				$SQL .= " update_time=:update_time ";
    				$SQL .= " WHERE phone_cost_id=:phone_cost_id ";
    			
    				$stmt = $dCON->prepare( $SQL );  
                    $stmt->bindParam(":call_time",$call_time);
                    $stmt->bindParam(":call_cost_inr",$call_cost_inr);
                    $stmt->bindParam(":call_cost_usd",$call_cost_usd);
                    
    				$stmt->bindParam(":update_ip", $IP);
    				$stmt->bindParam(":update_by", $_SESSION['KW_USERNAME']);
    				$stmt->bindParam(":update_time", $TIME);
    				$stmt->bindParam(":phone_cost_id",$phone_cost_id);

    				$rs = $stmt->execute();
    				$stmt->closeCursor();
                }
                else 
    			{
    				$rs=2;
    			}

			}

			
		$RETURN_ARRAY = array();
			 switch($rs)
			{
				case "1":
						$RETURN_ARRAY['SUCCESS'] = 1;
						$RETURN_ARRAY['MSG'] = "&#x2714; Successfully saved.";
						
						break;
				case "2":
						
						$RETURN_ARRAY['SUCCESS'] = 2;
						$RETURN_ARRAY['MSG'] = "&#x2757; Already Exists.";
						break; 
				default:
						$RETURN_ARRAY['SUCCESS'] = 0;
						$RETURN_ARRAY['MSG'] = "&#x2718; Sorry cannot process your request.";
						break;
			}

			echo json_encode($RETURN_ARRAY);

		}



function listData()
{
        
    global $dCON, $REQData;
    $page = intval($REQData->page) == 0 ? 1 : $REQData->page;
    
    $searchArr = array();
    
    $RETURN_ARRAY = array();
    $RETURN_ARRAY['searchedFields'] = array();
    
    $search = "";
    
    $SQL = "";
    $SQL .= " SELECT * ";
    $SQL .= " FROM " . PHONE_COST_TBL . " AS B ";
    $SQL .= " WHERE B.status <> '2' ";
    $SQL .= " $search ";
    $SQL .= " ORDER BY add_time DESC ";
    //echo $SQL;
    
    $SQL_COUNT  = "";
    $SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
        $SQL_COUNT .= $SQL;
    $SQL_COUNT .= " ) as aa ";
    
    
    $stmtCnt =  $dCON->prepare($SQL_COUNT);
    $stmtCnt->execute($searchArr);
    $noOfRecords_row = $stmtCnt->fetchObject();
    $stmtCnt->closeCursor();
    $noOfRecords = intval($noOfRecords_row->CT);

    $rowsPerPage = 7;

    $page = intval($page) - 1;
    $offset = $rowsPerPage * $page ;

    $SQL .= " LIMIT " . $offset . "," . $rowsPerPage;

    $stmt = $dCON->prepare($SQL);
    $stmt->execute($searchArr);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    
    $RETURN_ARRAY['data'] = $row;
    $RETURN_ARRAY['total_records'] = $noOfRecords;


    $capi = new GoogleCalendarApi();

    // Get user calendar timezone
    $user_timezone = $capi->GetUserCalendarTimezone($_SESSION['access_token']);

    $calendar_id = "ddlcoucrin1ts6ups2cthkasm0@group.calendar.google.com";

    // Create event on primary calendar
    $event_id = $capi->GetCalendarEvent($calendar_id, '', '', '', '$user_timezone', $_SESSION['access_token']);
    //echo "<pre>";
    //print_r($event_id['items']);
    //echo json_encode([ 'event_id' => $event_id ]);
    //echo "</pre>";
//exit;
    $RETURN_ARRAY['event_id'] = $event_id;
    
    echo json_encode($RETURN_ARRAY);    
          
}



function getDetail()
{
		global $dCON,$REQData;

		$phone_cost_id = intval($REQData->phone_cost_id);

		$SQL= "";
		$SQL .= " SELECT T.* ";
		$SQL .= " FROM ". PHONE_COST_TBL . " AS T ";
		$SQL .= " WHERE T.phone_cost_id=:phone_cost_id ";

		$stmt = $dCON->prepare( $SQL );
		$stmt->bindParam(":phone_cost_id", $phone_cost_id);
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();
		

		$RETURN_DATA = array();
		$RETURN_DATA['data'] = $row;
        
		echo json_encode($RETURN_DATA); 
}


function deleteData()
{
    global $dCON, $REQData;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    $phone_cost_id = intval($REQData->phone_cost_id);
    
    $STR  = "";
    $STR .= " UPDATE  " . PHONE_COST_TBL . "  SET "; 
    $STR .= " status = '2', ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE phone_cost_id = :phone_cost_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['KW_USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":phone_cost_id", intval($phone_cost_id));
    $dRES = $sDEF->execute();
    $sDEF->closeCursor();
    
    if(intval($dRES) > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }
    
    echo json_encode($RETURN_ARR);
}

function deleteAllData()
{
    global $dCON, $REQData;
    
    $indexIdsArray = $REQData->DIDS;
    $successCTR = 0;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    
    foreach($indexIdsArray as $indexIdObj)
    {
        $stmtDel = $dCON->prepare(" UPDATE " .PHONE_COST_TBL . " SET `status` = '2',update_ip =:update_ip,update_by = :update_by, update_time = :update_time  WHERE phone_cost_id = :phone_cost_id ");
        $stmtDel->bindParam(":update_ip", $IP);
        $stmtDel->bindParam(":update_by", $_SESSION['KW_USERNAME']);
        $stmtDel->bindParam(":update_time", $TIME);
        $stmtDel->bindParam(":phone_cost_id", $indexIdObj->phone_cost_id);
        $dRES = $stmtDel->execute();
        $stmtDel->closeCursor();
    }

    if($dRES > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }

    echo json_encode($RETURN_ARR);


}



	
function updateStatus()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->phone_cost_id);
    $VAL = trustme($REQData->status);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . PHONE_COST_TBL . "  SET "; 
    $STR .= " status = :status, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE phone_cost_id = :phone_cost_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":status", $VAL);
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['KW_USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":phone_cost_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();      
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}   	

 

?>

