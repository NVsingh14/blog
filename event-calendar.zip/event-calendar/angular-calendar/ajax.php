<?php
session_start();
header('Content-type: application/json');

require_once('google-calendar-api.php');

try {
	// Get event details
	$event = $_POST['event_details'];
	//print_r($event);

	$capi = new GoogleCalendarApi();

	// Get user calendar timezone
	$user_timezone = $capi->GetUserCalendarTimezone($_SESSION['access_token']);

	$calendar_id = "ddlcoucrin1ts6ups2cthkasm0@group.calendar.google.com";

	// Create event on primary calendar
	$event_id = $capi->GetCalendarEvent($calendar_id, '', '', '', '$user_timezone', $_SESSION['access_token']);
	echo "<pre>";
	print_r($event_id);
	echo json_encode([ 'event_id' => $event_id ]);
	echo "</pre>";
}
catch(Exception $e) {
	header('Bad Request', true, 400);
    echo json_encode(array( 'error' => 1, 'message' => $e->getMessage() ));
}

?>