<?php
/*ob_start();
session_start();*/
defined("INC_CLASS") or die("Invalid Access");
if(!isset($_SESSION['UID_MB']) && intval($_SESSION['UID_MB']) == intval(0))
{
    header("Location:login.php?msg=".urlencode("Please login to access the cms"));
    exit;    
}
?>