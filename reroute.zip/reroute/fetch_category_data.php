<?php 
include('config/config.php');
$sql = $dbo->prepare("select * from category order by cat_id asc");
$sql->execute();
while($row = $sql->fetch(PDO::FETCH_BOTH))
	{
		$data[] = $row;
	}
	echo json_encode($data);
?>