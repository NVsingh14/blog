<?php 

include 'dbclass1.php'; 
$db = new Lite3DB(); 

if(isset($_POST['do'])){ 

    extract($_POST); 
    //determine what direction in relation to $_POST['position'] 
    $otherpos = $do=='⇑'? $position-1:$position+1; 
    //get the two ID that should change order place 
    $sql = "SELECT id FROM forums WHERE position=$position"; 
    $posid = $db->GetRow($sql); 
    $sql = "SELECT id FROM forums WHERE position=$otherpos"; 
    $other = $db->GetRow($sql); 
    //change place for those two 
    $sql = "UPDATE forums SET position=$otherpos WHERE id=$posid->id"; 
    $db->Query($sql); 
    $sql = "UPDATE forums SET position=$position WHERE id=$other->id"; 
    $db->Query($sql); 

}else{ 
    // make sure all forums positions are numbered 1,2,3,4,5 etc. 
    $sql = "SELECT id FROM forums ORDER BY position"; 
    $forums = $db->GetAll($sql); 
    foreach($forums AS $f){ 
        $items[] = $f->id;     
    } 
    foreach($items AS $k=>$id){ 
        $k++; 
        $sql = "UPDATE forums SET position=$k WHERE id=$id"; 
        $db->Query($sql); 
    } 
} 

//get the number of forums to display 
$sql = "SELECT COUNT(*) AS max FROM forums"; 
$pos = $db->GetRow($sql); 
//get them by order of position 
$sql = "SELECT * FROM forums ORDER BY position"; 
$forums = $db->GetAll($sql); 

//display with up/down arrows for each 
//except first forum has only down-arrow 
//and last forum has only up-arrow 
$out ='<table>'."\n"; 
foreach($forums as $f){ 
    $out .= '<form method="post">'; 
    $out .= '<input type="hidden" name="position" value="'.$f->position.'">'."\n".'<tr>'; 
    if($f->position != 1) 
        $out .= '<td><input type="submit" name="do" value="⇑"></td>';  //up 
    else $out .= '<td></td>'; 
    if($f->position != $pos->max) 
        $out .= '<td><input type="submit" name="do" value="⇓"></td>';  //down 
    else $out .= '<td></td>'; 
    $out .= '<td>'.$f->name.'</td></tr>'."\n"; 
    $out .= '</form>'."\n"; 
} 
$out .= '</table>'; 
echo $out; 

?>