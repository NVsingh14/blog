<?php 
require_once('config/config.php');
	
$data = json_decode(file_get_contents("php://input"));
$id = $data->id;
$table = $data->table;
$field = $data->field;

	$res =$dbo->prepare("select * from $table where $field='".$id."' ");
	$res->execute();
	$no = $res->rowCount();
	if($no>0)
	{
		while($row = $res->fetch(PDO::FETCH_BOTH))
			{
				$arr[]=array('cat_id'=>$row['cat_id'],'cat_name'=>$row['cat_name'],'meta_title'=>$row['meta_title'],'keyword'=>$row['keyword'],'description'=>$row['description'],'slug'=>$row['slug']);
			}
	}
	echo json_encode($arr);

?>