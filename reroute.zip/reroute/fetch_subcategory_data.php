<?php 
include('config/config.php');
$sql = $dbo->prepare("select sub.*,cat.cat_id,cat.cat_name as cat_name from sub_category sub inner join category cat on cat.cat_id=sub.cat_id order by sub.sub_cat_id asc");
$sql->execute();
while($row = $sql->fetch(PDO::FETCH_BOTH))
	{
		$data[] = $row;
	}
	echo json_encode($data);
?>