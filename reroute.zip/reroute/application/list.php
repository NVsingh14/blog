<!DOCTYPE html>
<html>
<head>
	<title>List of squares and cube</title>
	 <script type="text/javascript" src="../node_modules/angular/angular.min.js"></script>
</head>
<body>
<div ng-app="listApp" ng-controller="listCtrl">
	<input type="text" ng-model="firstNum" name="firstNum">
	<input type="text" ng-model="secondNum" name="secondNum">
	<button type="submit" name="square" ng-click="listOfSquare()">Square</button>

	<table>
		<thead>
			<th>Number</th>
			<th>Square</th>
		</thead>
		<tbody >
			<tr>
			<td>{{number}}</td>
			<td>{{answer}}</td>
			</tr>
		</tbody>
	</table>
</div>
<script type="text/javascript">
	
	var myapp = angular.module("listApp",[]);
	myapp.service('MathService', function() {
		this.add = function(a,b) {return a + b};
		this.subtract = function(a,b) {return a-b};
		this.multiply = function(a,b) {return a*b};
		this.divide = function(a,b) {return a/b};

	}); //end of MathService

	myapp.service('CalculatorService',function(MathService){
		this.square = function(a) {return MathService.multiply(a,a);};
		this.cube = function(a) {return MathService.multiply(a,MathService.multiply(a,a));};
		this.add = function(a,b) {return MathService.add(a,b);};
		this.subtract = function(a,b) {return MathService.subtract(a,b);};
		this.divide = function(a,b) {return MathService.divide(a,b);};
		this.multiply = function(a,b) { return MathService.multiply(a,b);};

	}); //end of calculator service

	myapp.controller("listCtrl",function($scope,CalculatorService){

		$scope.listOfSquare = function()
		{
			var start = $scope.firstNum;
			var counter = $scope.secondNum
			for(var i=start;i<=counter;i++)
			{
				console.log('loop'+i);
				$scope.number=i;
				$scope.answer = CalculatorService.multiply(i,i);
			console.log($scope.answer);
		
			}
		}
	})
</script>
</body>
</html>