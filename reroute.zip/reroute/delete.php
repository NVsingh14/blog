<?php 
error_reporting(0);
require_once('config/config.php');
include('class/class.main.php');
$data = json_decode(file_get_contents("php://input"));
	$id=$data->id;
	$field=$data->field;
	$table = $data->table;
	$stype = $data->stype;
	$field_id = $data->call;
	if($stype!='' && $stype=='removeImage')
	{
		$res = $objmain->removeImage($id,$table,$field,$field_id);
		if($res==1)
		{
			echo "Image Remove Successfully";

		}
		else if($res==2)
		{
			echo "Invalid Data Has Been Pass";
		}
		else if($res==0)
		{
			echo "Sorry Can't Process Your Request";
		}
	}
	else
	{
	$res = $objmain->delete_data($id,$table,$field);

		if($res==1)
		{
			echo"Data Deleted";
		}
		else
		{
			echo "try again";
		}
	}
?>