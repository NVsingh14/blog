	
	app.config(['$routeProvider', function($routeProvider){

		$routeProvider
						.when('/welcome',{
							title:'Welcome',
							templateUrl:'welcome.html',
							controller:'welcomeCtrl'
						})
						.when('/catAdd',{
							title:'Add Category',
							templateUrl:'category.html',
							controller:'catCtrl'
						})
						.when('/catList',{
							title:'category list',
							templateUrl:'category-list.html',
							controller:'cat_listCtrl'
						})
						.when('/catAdd/:id',{
							templateUrl:'category.html',
							controller:'catCtrl'
						})
						.when('/subcatAdd',{
							title:'Add Subcategory',
							templateUrl:'subcategory.html',
							controller:'subcatCtrl'
						})
						.when('/subcatAdd/:id',{
							templateUrl:'subcategory.html',
							controller:'subcatCtrl'
						})
						.when('/subcatList',{
							title:'Subcategory List',
							templateUrl:'subcategory-list.html',
							controller:'subcatListCtrl'
						})
						.when('/prodAdd',{
							title:'Add Product',
							templateUrl:'product.html',
							controller:'prodCtrl'
						})
						.when('/prodList',{
							title:'Product List',
							templateUrl:'product_list.html',
							controller:'prodListCtrl'
						})
						.when('/prodAdd/:id',{
							title:'Add Product',
							templateUrl:'product.html',
							controller:'prodCtrl'
						})
						.when('/fetch',{
							title:'Fetch Category',
							templateUrl:'paginate.html',
							controller:'paginateCtrl'
						})
						.otherwise({
							redirectTo: 'welcome'
						});
	
	}]); //end of config