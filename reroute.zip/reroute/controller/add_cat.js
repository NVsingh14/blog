
	app.controller('catCtrl',['$scope','$http','$timeout','$routeParams','$location',function($scope,$http,$timeout,$routeParams,$location) {
		if($routeParams.id>0)
		{
			$scope.title="Update";
			console.log($routeParams.id);
			console.log("enter");
			$http.post('fetch_data.php',{id:$routeParams.id,table:'category',field:'cat_id'}).then(function(resp){
				//alert("console");
				//console.log(resp.data[0].cat_name);

				$scope.dataFrm.id = resp.data[0].cat_id;
				$scope.dataFrm.cat_name=resp.data[0].cat_name;
				$scope.dataFrm.meta_title = resp.data[0].meta_title;
				$scope.dataFrm.keyword = resp.data[0].keyword;
				$scope.dataFrm.description = resp.data[0].description;
				$scope.dataFrm.slug = resp.data[0].slug;
				//console.log($scope.dataFrm);
				$scope.update=true;
			})
		}
		else
		{
			$scope.submit=true;
			$scope.title="Add";
		}
		$scope.dataFrm = {
			cat_name:'',
			meta_title:'',
			keyword:'',
			description:'',
			slug:''
		};

		$scope.category_insert = function()
		{
			//alert("fun");
			console.log($scope.dataFrm);
			$http.post('category_insert.php',{data:$scope.dataFrm}).
			then(function(response){
				//alert("data");
				//console.log(response);
				$scope.dataFrm=null;
				$scope.msg=true;
				$scope.result="Data Inseted Successfully";
				$timeout(function(){
					$scope.msg=false;
					$location.path('/catList');
					
				},3000)

			})
		} //end of category insert

		$scope.category_update = function()
		{
			$http.post('category_update.php',{data:$scope.dataFrm}).then(function(resp){
				console.log(resp);
				//alert("data");
				$scope.msg=true;
				$scope.result="Updated Successfully";
				$timeout(function(){
					$scope.msg=false;
					$location.path('/catList');
				},3000)
			});
		}
	}]); //end of controller