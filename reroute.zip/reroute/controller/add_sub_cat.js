
app.controller('subcatCtrl',['$scope','$http','$timeout','$routeParams','$location',function($scope,$http,$timeout,$routeParams,$location) {

	if($routeParams.id>0)
	{	
		console.log($routeParams.id);
		console.log("enter");
		$scope.title="Update";
		$http.post('fetch_subcat_data.php',{id:$routeParams.id}).
		then(function(resp){
						//console.log(resp);
						$scope.dataFrm.id=resp.data[0].sub_cat_id;
						$scope.dataFrm.name = resp.data[0].cat_id;
						$scope.dataFrm.sub_cat_name = resp.data[0].sub_cat_name;
						$scope.dataFrm.meta_title = resp.data[0].meta_title;
						$scope.dataFrm.keyword = resp.data[0].keyword;
						$scope.dataFrm.description = resp.data[0].description;
						$scope.dataFrm.slug = resp.data[0].slug;
						//console.log($scope.dataFrm);
						$scope.update=true;
					})
	}
	else
	{
		$scope.submit=true;
		$scope.title="Add";
	}

	$http.get('fetch_category_data.php').then(function(response){
		$scope.result = response.data;
	});
	$scope.dataFrm = {
		cat_name:'',
		sub_cat_name:'',
		meta_title:'',
		keyword:'',
		description:'',
		slug:''
	};
	$scope.sub_category_insert = function()
	{
		$http.post('subCat_insert.php',{data:$scope.dataFrm}).
		then(function(response){
						//alert("response");
						//console.log(response);
						$scope.dataFrm=null;
						$scope.msg=true;
						$scope.msgData="Data Inserted Successfully";
						$timeout(function(){
							$scope.msg=false;
							$location.path('/subcatList');
						},3000)

					})
	}

	$scope.sub_category_update = function()
	{
		$http.post('subcategory_update.php',{data:$scope.dataFrm}).
		then(function(resp){
						//console.log(resp);
						$scope.msg=true;
						$scope.msgData="Updated Successfully";
						$timeout(function(){
							$scope.msg=false;
							$location.path('/subcatList');
						},3000)
					})
	}

	}]); //end of controller