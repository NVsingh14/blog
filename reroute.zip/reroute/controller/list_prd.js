	
	app.controller('prodListCtrl',['$scope','$http','$timeout','$window',function($scope,$http,$timeout,$window){

		$http.get('fetch_product_data.php').
				then(function(resp){
					console.log(resp);
					$scope.result = resp.data;
				});

				$scope.delete_product = function(did)
				{
					var c = confirm("Are You Sure To Delete This Item");
					if(c)
					{
						$http.post('delete.php',{id:did,table:'product',field:'p_id'}).
								then(function(response){
									console.log(response);
									$scope.msg=true;
									$scope.msgData = "Data Deleted Succesfully";
									$timeout(function(){
										$scope.msg=false;
										$window.location.reload();
									},3000)
								})
					}
					else
					{
						return false;
					}
				}
	}])