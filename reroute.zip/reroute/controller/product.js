
app.directive('ckEditor',function() {
	return {
		require:'?ngModel',
		link:function(scope,elm, attr, ngModel) {
			var ck = CKEDITOR.replace(elm[0]);

			if(!ngModel) return;

			ck.on('pasteState',function() {
				scope.$apply(function() {
					ngModel.$setViewValue(ck.getData());
				});
			});

			ngModel.$render = function (value) {
				ck.setData(ngModel.$viewValue);
			};
		}
	};
	}); //end of directive

app.controller('prodCtrl',['$scope','$http','$timeout','Upload','$routeParams','$window','$location',function($scope,$http,$timeout,Upload,$routeParams,$window,$location) {

	if($routeParams.id>0)
	{

		$scope.title = "Update";
		$scope.update=true;
		$http.post('fetch_product_data.php',{id:$routeParams.id}).
		then(function(response){
			//console.log(response);
			$scope.dataFrm.id = response.data[0].id;
			$scope.dataFrm.prd_name = response.data[0].prd_name;
			$scope.dataFrm.item_code = response.data[0].item_code;
			$scope.dataFrm.editor1 = response.data[0].editor1;
			$scope.dataFrm.prd_price = response.data[0].prd_price;
			$scope.dataFrm.discount_flat = response.data[0].discount_flat;
			$scope.dataFrm.discount_percent = response.data[0].discount_percent;
			$scope.dataFrm.slug = response.data[0].slug;
			$scope.dataFrm.img_hidden = response.data[0].image;
			$scope.fuploading=2;
			$scope.dataFrm.news_image_disp = "image/"+response.data[0].image;
			if($scope.dataFrm.discount_flat==null)
			{
				$scope.discount='percent';
			}
			else
			{
				$scope.discount = 'flat';
			}

			//console.log($scope.dataFrm);
		})
		
	}
	else
	{
		$scope.title="Add";
		$scope.submit = true;
	}
	$scope.dataFrm = {
		prd_name:'',
		item_code:'',
		editor1:'',
		prd_price:'',
		discount_val:'',
		slug:'',
		img_hidden:''
	}

	$scope.prd_sub = function()
	{
		//alert("hello");
	console.log($scope.dataFrm);
	$http.post('product_insert.php',{data:$scope.dataFrm}).
	then(function(resp){
		//alert("data");
		console.log(resp);
		$scope.dataFrm=null;
		$scope.msg=true;
		$scope.msgData="Data inserted Succsfully";
		$timeout(function(){
			$scope.msg=false;
			$window.location.reload();
		},3000)
	})

}

$scope.fuploading = 0;
$scope.upload = function(file) {
	//alert("enter");
	console.log(file);
	Upload.upload({
		url:'upload.php',
		data:{file:file}
	}).then(function (resp) {
		//alert("rest");
		console.log(resp);
		if(resp.data.SUCCESS=="1")
		{
			$scope.dataFrm.img_hidden = resp.data.IMAGE_NAME;
			$scope.dataFrm.news_image_disp = resp.data.PATH_TO_IMAGE;
			$scope.fuploading=2;
		}
		else
		{
			$scope.fileuploaderror = resp.data.MSG;
			$scope.fuploading=3;
			$timeout(function() {
				$scope.fuploading=0;
				$location.path("/prodList");
			},3000);
		}
	})

} //end of upload function

$scope.removeImage = function()
{
	var c =confirm("Are You Sure you wish to Delete?");
	if(c)
	{
			if($routeParams.id)
			{
				$http({method:'POST',url:'delete.php',data:{field:'feature_img',table:'product',stype:'removeImage',id:$routeParams.id,call:'p_id'}}).success(function(response){
					//console.log(response);
					$scope.fuploading=0;
					$scope.img_hidden='';
					$scope.news_image_disp='';

				});
			}
			else
			{
				$scope.fuploading = 0;
				$scope.dataFrm.img_hidden = '';  
				$scope.dataFrm.news_image_disp = '';  	
			}
	}
	
	}//end of remove image function

		$scope.prd_update = function()
		{
			console.log($scope.dataFrm);
			$http.post('product_update.php',{data:$scope.dataFrm}).
			then(function(resp){
				//console.log(resp);
				$scope.dataFrm=null;
				$scope.msg=true;
				$scope.msgData = "Updated Succsfully";
				$timeout(function() {
					$scope.msg=false;
					$location.path('/prodList');
				},3000)
			})
		}

	}]); //end of controller