
app.controller('subcatListCtrl',['$scope','$http','$timeout','$window',function($scope,$http,$timeout,$window) {

	$http.get('fetch_subcategory_data.php').
	then(function(resp){
					//console.log(resp);

					$scope.result=resp.data;
				})



	$scope.delete_subcategory = function(did)
	{
		var c = confirm("Are You Sure To Delete This Item ?");
		if(c)
		{
			$http.post('delete.php',{id:did,table:'sub_category',field:'sub_cat_id'}).then(function(response){
					//console.log(response);
					$scope.msg = true;
					$scope.msgData = "Data Deleted Successfully";
					$timeout(function(){
						$scope.msg=false;
						$window.location.reload();
					},3000)
				});
		}
		else
		{
			return false;
		}
	}
	}]); // end of controller