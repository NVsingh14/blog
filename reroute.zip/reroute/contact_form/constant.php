<?php
//reCAPTCHA Configuration - go to Google and get the below keys http://www.google.com/recaptcha/admin
define('SITE_KEY',"6LfRLhcTAAAAAOqtHfcEm9NdCzNQ0D9kCqD_oiNA"); 
define('SECRET_KEY',"6LfRLhcTAAAAAAhy-ddbdlzVBykh_RX4QlLiodrj")
?>