<?php 
require_once('config/config.php');
	//$arr[]=array();
$data = json_decode(file_get_contents("php://input"));
$id = $data->id;

	$res =$dbo->prepare("select * from sub_category where sub_cat_id='".$id."' ");
	$res->execute();
	$no = $res->rowCount();
	if($no>0)
	{
		while($row = $res->fetch(PDO::FETCH_BOTH)) {
			// {
			// 	$arr[]=array('cat_id'=>$row['cat_id'],'cat_name'=>$row['cat_name'],'meta_title'=>$row['meta_title'],'keyword'=>$row['keyword'],'description'=>$row['description'],'slug'=>$row['slug']);
			$arr[]=array('cat_id'=>$row['cat_id'],'sub_cat_id'=>$row['sub_cat_id'],'sub_cat_name'=>$row['sub_cat_name'],'meta_title'=>$row['meta_title'],'keyword'=>$row['keyword'],'description'=>$row['description'],'slug'=>$row['slug']);
			}
	}
	echo json_encode($arr);
?>