<?php 
/*$date1 = "2007-03-24";
$date2 = "2009-06-26";

$diff = abs(strtotime($date2) - strtotime($date1));

$years = floor($diff / (365*60*60*24));
$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

printf("%d years, %d months, %d days\n", $years, $months, $days);*/
/*date_default_timezone_set('Asia/Kolkata');
 //$date1timestamp = 
$date1 = date("Y-m-d H:i:s"); 
date_default_timezone_set('America/New_York');
 $date2 = date("Y-m-d H:i:s") ;

$diff = abs(strtotime($date2) - strtotime($date1)); 

$years   = floor($diff / (365*60*60*24)); 
$months  = floor(($diff - $years * 365*60*60*24) / (30*60*60*24)); 
$days    = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

echo $hours   = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/ (60*60)); 

$minuts  = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60); 

$seconds = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minuts*60)); 

printf("%d years, %d months, %d days, %d hours, %d minuts\n, %d seconds\n", $years, $months, $days, $hours, $minuts, $seconds); */
/*date_default_timezone_set('Asia/Kolkata');
 $date1timestamp = date("H:i:s");


date_default_timezone_set("America/New_York");
$date2timestamp = date("H:i:s");
//echo"bang====". $time;
function date_difference ($date1timestamp, $date2timestamp) {
$all = round(($date1timestamp - $date2timestamp) / 60);
$d = floor ($all / 1440);
$h = floor (($all - $d * 1440) / 60);
$m = $all - ($d * 1440) - ($h * 60);
//Since you need just hours and mins
return array('hours'=>$h, 'mins'=>$m);
}


$result = date_difference($date1timestamp, $date2timestamp);

echo"india:==". $date1timestamp."<br>";

echo "bangkok==".$date2timestamp."<br>";



print_r($result);*/
/*date_default_timezone_set('Asia/Kolkata');
 $date1timestamp = date("H:i:s");
date_default_timezone_set("America/New_York");
 $date2timestamp = date("H:i:s");
//"2008-12-13 10:44:00"

$to_time = strtotime($date1timestamp);
$from_time = strtotime($date2timestamp);
//echo round(abs($to_time - $from_time) / 60,2). " minute";
echo round(abs($to_time - $from_time)/60,2)."minute";

echo "<br>";
echo"india". $date1timestamp."<br>";
echo "new york===".$date2timestamp;*/


/*$newtimestamp = strtotime('2017-09-26 21:45 + 960  minute');
echo date('Y-m-d H:i:s', $newtimestamp);*/
date_default_timezone_set('Asia/Kolkata');
 $date1timestamp = date("Y-m-d H:i:s");

 date_default_timezone_set("America/New_York");
  $date2timestamp = date("Y-m-d H:i:s");


$start_date = new DateTime($date1timestamp);
$since_start = $start_date->diff(new DateTime($date2timestamp));
echo $since_start->days.' days total<br>';
echo $since_start->y.' years<br>';
echo $since_start->m.' months<br>';
echo $since_start->d.' days<br>';
echo $since_start->h.' hours<br>';
echo $since_start->i.' minutes<br>';
echo $since_start->s.' seconds<br>';
?>