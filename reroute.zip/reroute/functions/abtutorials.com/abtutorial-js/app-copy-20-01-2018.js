(function(){
 
  var app = angular.module("iwsApp", ['ngRoute', 'angularUtils.directives.dirPagination', 'ngSanitize', 'uiSwitch', 'checklist-model', 'ngDialog', 'ngFileUpload', '720kb.datepicker', 'ckeditor','bootstrapLightbox','ui.bootstrap','angular.filter','AngularPrint']);
  //'btorfs.multiselect'
 
  //var app = angular.module("iwsApp", ['ngRoute','angularUtils.directives.dirPagination', 'ckeditor', 'ngFileUpload', '720kb.datepicker', 'ngSanitize', 'uiSwitch', "checklist-model", 'color.picker', 'ngDialog', 'ui.bootstrap', 'ui.bootstrap.datetimepicker','angular.filter','bootstrapLightbox']); 
    
    
  app.constant("myConfig", {
    "ajax_url": "process.php",
    "upload_url": "upload.php",
  });

  /*
  app.run(function($interval, $http) {
     //alert(123);
     $interval(function(){
          var objData = {};
          $http({method: 'POST', url: 'check_session.php', data:objData}).success(function(response){
              //console.log(response);
              if(parseInt(response.UID) == parseInt(0)) {
                  //alert("ssssss");
                  window.location.reload();
              }
          });
          
     }, 600000); //2000
       
  });
  */
  
  
    app.directive('validNumber', function() {
        return {
            require: '?ngModel',
            link: function(scope, element, attrs, ngModelCtrl) {
              if(!ngModelCtrl) {
                return; 
              }
    
              ngModelCtrl.$parsers.push(function(val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }
                
                var clean = val.replace(/[^-0-9\.]/g, '');
                var negativeCheck = clean.split('-');
    			var decimalCheck = clean.split('.');
                if(!angular.isUndefined(negativeCheck[1])) {
                    negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                    clean =negativeCheck[0] + '-' + negativeCheck[1];
                    if(negativeCheck[0].length > 0) {
                    	clean =negativeCheck[0];
                    }
                    
                }
                  
                if(!angular.isUndefined(decimalCheck[1])) {
                    decimalCheck[1] = decimalCheck[1].slice(0,6);
                    clean =decimalCheck[0] + '.' + decimalCheck[1];
                }
    
                if (val !== clean) {
                  ngModelCtrl.$setViewValue(clean);
                  ngModelCtrl.$render();
                }
                return clean;
              });
    
              element.bind('keypress', function(event) {
                if(event.keyCode === 32) {
                  event.preventDefault();
                }
              });
            }
        };
    });
    
  
  
  
  
  
  
  app.directive('aDisabled', function() {
    return {
      compile: function(tElement, tAttrs, transclude) {
        //Disable ngClick
        tAttrs["ngClick"] = "!("+tAttrs["aDisabled"]+") && ("+tAttrs["ngClick"]+")";

        //return a link function
        return function (scope, iElement, iAttrs) {

          //Toggle "disabled" to class when aDisabled becomes true
          scope.$watch(iAttrs["aDisabled"], function(newValue) {
            if (newValue !== undefined) {
              iElement.toggleClass("disabled", newValue);
            }
          });

          //Disable href on click
          iElement.on("click", function(e) {
            if (scope.$eval(iAttrs["aDisabled"])) {
              e.preventDefault();
            }
          });
        };
      }
    };
  });

  app.directive('stringToNumber', function() {
    return {
      require: 'ngModel',
      link: function(scope, element, attrs, ngModel) {
        ngModel.$parsers.push(function(value) {
          return '' + value;
        });
        ngModel.$formatters.push(function(value) {
          return parseFloat(value);
        });
      }
    };
  });

  app.directive('onlyNum', function() {
    return function(scope, element, attrs) {
      var keyCode = [8,9,17,37,39,48,46,49,50,51,52,53,54,55,56,57,86,91,96,97,98,99,100,101,102,103,104,105,110,190];
      element.bind("keydown", function(event) {
        console.log($.inArray(event.which,keyCode));
        if($.inArray(event.which,keyCode) == -1) {
          scope.$apply(function(){
            scope.$eval(attrs.onlyNum);
            event.preventDefault();
          });
          event.preventDefault();
        }
      });
    };
  });

  app.directive('validateMobile', function() {
    return function(scope, element, attrs) {
      //var keyCode = [8,9,16,37,39,46,48,49,50,51,52,53,54,55,56,57,96,97,98,99,100,101,102,103,104,105,110,190,188];
      var keyCode = [8,9,16,37,39,46,48,49,50,51,52,53,54,55,56,57,76,86,96,97,98,99,100,101,102,103,104,105,110,190,188];
      element.bind("keydown", function(event) {
        console.log(event.which);
        //console.log($.inArray(event.which,keyCode));

        if($.inArray(event.which,keyCode) == -1) {
          scope.$apply(function(){
            scope.$eval(attrs.onlyNum);
            event.preventDefault();
          });
          event.preventDefault();
        }

      });

    };
  }); 



  app.filter('iwsApp').filter('capitalize', function() {
    return function(input) {
      return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    }
  });


  app.filter('iwsApp').filter('titleCase', function() {
    return function(input) {
      input = input || '';
      return input.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
    }
  });  


  /////////for ajax value bind

  app.directive('bindUnsafeHtml', ['$compile',
    function($compile) {
      return function(scope, element, attrs) {
        scope.$watch(
          function(scope) {
            // watch the 'bindUnsafeHtml' expression for changes
            return scope.$eval(attrs.bindUnsafeHtml);
          },
          function(value) {
            // when the 'bindUnsafeHtml' expression changes
            // assign it into the current DOM
            element.html(value);

            // compile the new DOM and link it to the current
            // scope.
            // NOTE: we only compile .childNodes so that
            // we don't get into infinite loop compiling ourselves
            $compile(element.contents())(scope);
          }
        );
      };
    }
  ]);
  
  
   app.directive('onlyDigits', function () {

        return {
            restrict: 'A',
            require: '?ngModel',
            link: function (scope, element, attrs, modelCtrl) {
                modelCtrl.$parsers.push(function (inputValue) {
                    if (inputValue == undefined) return '';
                    var transformedInput = inputValue.replace(/[^0-9]/g, '');
                    if (transformedInput !== inputValue) {
                        modelCtrl.$setViewValue(transformedInput);
                        modelCtrl.$render();
                    }
                    return transformedInput;
                });
            }
        };
    });
  
  
})();
