  $(document).ready(function(){
  //   $(window).on('resize', function () {
  //     //var mainheader = $(".main-header").height() + 13;
  //     var mainheader = $(".main-header").height() + 4;
  //     $('.layout-top-nav').css({'padding-top':mainheader});
  //   }).resize();
      


     if ($(window).width() < 1340) {
      // mobile menu
      $('.hamburger').click(function (event) {
        $(this).toggleClass('h-active');
        $('.main-nav').toggleClass('slidenav');
      });

      $('.header-home .main-nav ul li  a').click(function (event) {
        $('.hamburger').removeClass('h-active');
        $('.main-nav').removeClass('slidenav');
      });
    }        
    $(".main-nav .fl").on('click', function(event) {
      var $fl = $(this);
      $(this).parent().siblings().find('.submenu').slideUp();
      $(this).parent().siblings().find('.fl').addClass('flaticon-plus').text("+");       
      if($fl.hasClass('flaticon-plus')){
        $fl.removeClass('flaticon-plus').addClass('flaticon-minus').text("-");
      }else{
        $fl.removeClass('flaticon-minus').addClass('flaticon-plus').text("+");
      }
      $fl.next(".submenu").slideToggle();
    });

    if ($(window).width() < 768) {
      $(document).on('click', '.filterClick', function() {
      // $(".filterClick").unbind().click(function(e){
        $(".filterClick span").find('i').toggleClass('fa-chevron-down fa-chevron-up');
        $('.filterClickShow').slideToggle(500);
      });
    }
    
  });
  