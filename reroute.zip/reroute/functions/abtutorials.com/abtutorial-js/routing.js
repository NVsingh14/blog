angular.module('fpApp').config(['$routeProvider', function($routeProvider){

	$routeProvider
		.when("/dashboard", {
			templateUrl: 'abtutorial-js/dashboardComponent/dashboard.html',
			controller: 'dashboardController'
		}) 
		.when("/changePassword", {
			templateUrl: 'abtutorial-js/changePasswordComponent/changePassword.html',
			controller: 'changePasswordController'
		}) 
		
		.otherwise({
			redirectTo: 'dashboard'
		});

}]).run(function ($rootScope, $route) {
	$rootScope.$route = $route;
});
