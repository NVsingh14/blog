<?php
$PAGENAME = strtolower(basename(trustme($_SERVER['PHP_SELF'])));
    
//echo "==".$PAGENAME;    
    
if( $_SESSION['USERTYPE_ABT'] != CONSTANT_SITE_OWNER )
{
            
    if ( trim($PAGENAME) == "hsn_code.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1001,1002,1003,1004);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "product_category.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1005,1006);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "product_type.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1007,1008,1009);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    if ( trim($PAGENAME) == "property_type.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1010,1011,1012);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    
    if ( trim($PAGENAME) == "problem_type.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1013,1014,1015);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "user.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1016,1017,1018);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "product.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1019,1020,1021);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    
    if ( trim($PAGENAME) == "client.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1028,1029,1030,1031,1033,1034);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "client_rates.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1031);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "client_property.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1033);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    if ( trim($PAGENAME) == "client_user.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1034);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    if ( trim($PAGENAME) == "general_rates.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1038,1039,1040,1041);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "general_rates.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1038,1039,1040,1041);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "requisition.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1042,1043,1044,1045);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "po.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1046,1047,1048,1049);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "po.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1046,1047,1048,1049);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    if ( trim($PAGENAME) == "one_time_sale.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1051,1052,1053,1054);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "returns.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1061,1062);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "report_rented_inventory.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1064);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "report_unallocated_inventory.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1065);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "report_current.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1066);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "report_client.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1067);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    if ( trim($PAGENAME) == "monthly_billing.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1068);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    
    if ( trim($PAGENAME) == "testimonials.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1081,1082,1083);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    
    if ( trim($PAGENAME) == "service_request.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1056);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
    
    
    if ( trim($PAGENAME) == "service_request_manage.php"  )
    {
        $PAGEp = null;
        $PAGEp = array(1057,1058,1059);   
        if( intval(count(array_intersect($PERMISSION,$PAGEp))) <= intval(0) )
        {
            include("invalid_access.php"); 
            exit();   
        } 
    }
    
}
    
    
?>