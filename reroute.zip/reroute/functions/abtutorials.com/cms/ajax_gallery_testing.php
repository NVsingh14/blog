<?php 
session_start();
error_reporting(0);
include("config-cms.php");
include("../library/class.imageresizer.php");

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);

switch($type)
{
         case "removeImage":
            removeImage();
        break;

		case "saveData":
				saveData();
				break;
		case "listData":
			listData();
			break;
		case "getDetail" :
			getDetail();
			break;
		case "CancelGallery":
			CancelGallery();
			break;
		case "deleteData":
			deleteData();
			break;
		case "deleteAllData":
			deleteAllData();
			break;
		case "updateDisplayWebsite":
			updateDisplayWebsite();
			break;
        case "updateStatus":
			updateStatus();
			break;
}
        
        function removeImage()
        {
            global $dCON, $REQData;
            
            $image_name = trustme($REQData->image_name);
            $imageId = intval($REQData->gallery_id);
            $FOLDER_NAME = FLD_GALLERY_IMAGE;
          // echo " === " . $image_name . " === " . $imageId . " ====== " . $FOLDER_NAME;
          // exit();
            if($imageId == intval(0))
            {
                
                //delete image
                if(unlink($image_name)) 
                {
                    //deleteIMG("GALLERY",$image_name,CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD );
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete Image";
                }
            }
            else
            {
                if(unlink($image_name)) 
                {
                    $img_array = explode("/", $image_name);
                    $IMG =  $img_array[3];
                    
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R500-" . $IMG );
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R50-" . $IMG );
                                
                    $SQL = "";
                    $SQL .= "UPDATE " . GALLERY_TBL . " SET " ;
                    $SQL .= " gallery_image = :gallery_image, ";
                    $SQL .= " image_id = :image_id ";
                    $SQL .= " WHERE gallery_id = :gallery_id ";
                    //echo "$SQL---$img---$img_id-----$imageId" ;
                    
                    $gallery_image = "";
                    $img_id = intval(0);            
                         
                    $stk_upd = $dCON->prepare($SQL);
                    $stk_upd->bindParam(":gallery_image", $gallery_image);
                    $stk_upd->bindParam(":image_id", $img_id);
                    $stk_upd->bindParam(":gallery_id", $imageId);
                    $stk_upd->execute();
                    
                    $stk_upd->closeCursor();
                     
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete Image";
                }
                
            } 
        }

		
		function saveData()
		{
			global $dCON, $REQData;
			$IP = $_SERVER['REMOTE_ADDR'];
			$TIME = date("Y-m-d H:i:s");
            
            
            
			$image_caption = trustme($REQData->image_caption);
			$gallery_id=intval($REQData->gallery_id);
            $gallery_image = trustme($REQData->gallery_img); 
            $gallery_image_got = trustme($REQData->gallery_image_disp);
           
            $all_gallery_images_array = $REQData->all_gallery_images;
           
            
            $image_id = trustme($REQData->image_id);
            $status = intval(1);
            $TEMP_FOLDER_NAME = "";
            $TEMP_FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD . "/";
            
            if( !is_dir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_GALLERY_IMAGE))
            {
                $mask=umask(0);
                mkdir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_GALLERY_IMAGE, 0777);
                umask($mask);
            }  
            
            $FOLDER_NAME = "";
            $FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH .FLD_GALLERY_IMAGE. "/";
            
           
			if(intval($gallery_id)==intval(0))
			{
			  if(intval(count($all_gallery_images_array)) > intval(0))
                {
                    foreach($all_gallery_images_array as $obj_gallery_image)
                    {
                       $image_name = trustme($obj_gallery_image->IMAGE_NAME);

                        $MAXID = getMaxId(GALLERY_TBL,"gallery_id");
                     
                        //==============FOR IMAGE
                        
                        
                        if( trim($image_name) != "")
                        {
                            $f_ext = pathinfo($image_name);
                            $fNAM = $MAXID."-"."IMAGE";
                            $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                            rename($TEMP_FOLDER_NAME.$image_name, $FOLDER_NAME.$IMG);
                            resizeIMG("GALLERY",trim($IMG),$MAXID,$FOLDER_NAME);
                            
                            $image_id = intval(1);
                            
                        }
                       
                        /////FOR IMAGE ENDS
        
        				$SQL = "";
        				$SQL .= " INSERT INTO " . GALLERY_TBL . " SET ";
        				$SQL .= " gallery_id=:gallery_id, ";
                        $SQL .= " image_caption=:image_caption, ";
        				$SQL .= " gallery_image=:gallery_image, ";
                        $SQL .= " image_id=:image_id, ";
                        $SQL .= " status=:status, ";
        				$SQL .= " add_ip=:add_ip, ";
        				$SQL .= " add_by=:add_by, ";
        				$SQL .= " add_time=:add_time ";
        
        				$stmt = $dCON->prepare( $SQL );
        				$stmt->bindParam(":gallery_id", $MAXID);
                        $stmt->bindParam(":image_caption", $image_caption);  
                        $stmt->bindParam(":gallery_image",$IMG); 
                        $stmt->bindParam(":image_id",$image_id); 
                        $stmt->bindParam(":status",$status); 
        				$stmt->bindParam(":add_ip", $IP);
        				$stmt->bindParam(":add_by", $_SESSION['USERNAME']);
        				$stmt->bindParam(":add_time", $TIME);
        				$rs = $stmt->execute();
        				$stmt->closeCursor();
                    }
                }
			}
			else if(intval($gallery_id) > intval(0) )
			{
                    
				$SQL= "";
				$SQL .= "UPDATE " . GALLERY_TBL . " SET ";
                $SQL .= " image_caption=:image_caption, ";
                $SQL .= " status=:status, ";
				$SQL .= " update_ip=:update_ip, ";
				$SQL .= " update_by = :update_by, ";
				$SQL .= " update_time=:update_time ";
				$SQL .= " WHERE gallery_id=:gallery_id ";
				
				$stmt = $dCON->prepare( $SQL ); 
                $stmt->bindParam(":image_caption",$image_caption);
                $stmt->bindParam(":status",$status); 
				$stmt->bindParam(":update_ip", $IP);
				$stmt->bindParam(":update_by", $_SESSION['USERNAME']);
				$stmt->bindParam(":update_time", $TIME);
				$stmt->bindParam(":gallery_id",$gallery_id);

				$rs = $stmt->execute();
				$stmt->closeCursor();

			}

			else 
			{
				$rs=2;
			}
		$RETURN_ARRAY = array();
			 switch($rs)
			{
				case "1":
						$RETURN_ARRAY['SUCCESS'] = 1;
						$RETURN_ARRAY['MSG'] = "&#x2714; Successfully saved.";
						
						break;
				case "2":
						
						$RETURN_ARRAY['SUCCESS'] = 2;
						$RETURN_ARRAY['MSG'] = "&#x2757; Already Exists.";
						break; 
				default:
						$RETURN_ARRAY['SUCCESS'] = 0;
						//$RETURN_ARRAY['MSG'] = "&#x2718; Sorry cannot process your request.";
                        $RETURN_ARRAY['MSG'] = "Gallery Image is Required.";
						break;
			}

			echo json_encode($RETURN_ARRAY);

		}



function listData()
{
        
    global $dCON, $REQData;
    $page = intval($REQData->page) == 0 ? 1 : $REQData->page;
    
    $title = trustme($REQData->search_gallery_title);
    
    $search_name = trustme($REQData->search_gallery_ref);
    
    $searchArr = array();
    
    $RETURN_ARRAY = array();
    $RETURN_ARRAY['searchedFields'] = array();
    
    $search = "";
    if( trim($title) != "" )
    {
        $search .= " AND B.gallery_title = '".$title."' ";
      
        $RETURN_ARRAY['searchedFields'][] = $title;
    }
    
    
    if( trim($search_name) != "" )
    {
        $search .= " AND B.gallery_ref = '".$search_name."' ";
        $RETURN_ARRAY['searchedFields'][] = $search_name;
    }
    
    $SQL = "";
    $SQL .= " SELECT * ";
    $SQL .= ",(CASE WHEN gallery_image <> '' THEN CONCAT ('" . CMS_UPLOAD_FOLDER_RELATIVE_PATH . FLD_GALLERY_IMAGE . "/R50-" . "', B.gallery_image) ELSE '' END ) as gallery_image_disp ";
    $SQL .= " FROM " . GALLERY_TBL . " AS B ";
    $SQL .= " WHERE B.status <> '2' AND image_id <> '0' ";
    $SQL .= " $search order by add_time DESC";
    ///$SQL .= " ORDER BY gallery_title ";
    //echo $SQL;
    
    $SQL_COUNT  = "";
    $SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
        $SQL_COUNT .= $SQL;
    $SQL_COUNT .= " ) as aa ";
    
    
    $stmtCnt =  $dCON->prepare($SQL_COUNT);
    $stmtCnt->execute($searchArr);
    $noOfRecords_row = $stmtCnt->fetchObject();
    $stmtCnt->closeCursor();
    $noOfRecords = intval($noOfRecords_row->CT);

    $rowsPerPage = 2000;

    $page = intval($page) - 1;
    $offset = $rowsPerPage * $page ;

    $SQL .= " LIMIT " . $offset . "," . $rowsPerPage;

    $stmt = $dCON->prepare($SQL);
    $stmt->execute($searchArr);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    
    $RETURN_ARRAY['data'] = $row;
    $RETURN_ARRAY['total_records'] = $noOfRecords;
    
    echo json_encode($RETURN_ARRAY);    
          
}



function getDetail()
{
		global $dCON,$REQData;

		$gallery_id = intval($REQData->gallery_id);

		$SQL= "";
		$SQL .= " SELECT T.* ";
		$SQL .= " FROM ". GALLERY_TBL . " AS T ";
		$SQL .= " WHERE T.gallery_id=:gallery_id ";

		$stmt = $dCON->prepare( $SQL );
		$stmt->bindParam(":gallery_id", $gallery_id);
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();
		

		$RETURN_DATA = array();
		$RETURN_DATA['data'] = $row;
        
		echo json_encode($RETURN_DATA); 
}


function deleteData()
{
    global $dCON, $REQData;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    $gallery_id = intval($REQData->gallery_id);
    
    $STR  = "";
    $STR .= " UPDATE  " . GALLERY_TBL . "  SET "; 
    $STR .= " status = '2', ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE gallery_id = :gallery_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":gallery_id", intval($gallery_id));
    $dRES = $sDEF->execute();
    $sDEF->closeCursor();   
    
    if(intval($dRES) > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }
    
    echo json_encode($RETURN_ARR);
}

function deleteAllData()
{
    global $dCON, $REQData;
    
    $indexIdsArray = $REQData->DIDS;
    $successCTR = 0;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    
    foreach($indexIdsArray as $indexIdObj)
    {
       $stmtDel = $dCON->prepare(" UPDATE " .GALLERY_TBL . " SET `status` = '2',update_ip =:update_ip,update_by = :update_by, update_time = :update_time  WHERE gallery_id = :gallery_id ");
        $stmtDel->bindParam(":update_ip", $IP);
        $stmtDel->bindParam(":update_by", $_SESSION['USERNAME']);
        $stmtDel->bindParam(":update_time", $TIME);
        $stmtDel->bindParam(":gallery_id", $indexIdObj->gallery_id);
        $dRES = $stmtDel->execute();
        $stmtDel->closeCursor();

       
    }

    if($dRES > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }

    echo json_encode($RETURN_ARR);


}


function updateDisplayWebsite()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->gallery_id);
    $VAL = trustme($REQData->display_on_home);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . GALLERY_TBL . "  SET "; 
    $STR .= " display_on_home = :display_on_home, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE gallery_id = :gallery_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":display_on_home", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":gallery_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}

function updateStatus()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->gallery_id);
    $VAL = trustme($REQData->status);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . GALLERY_TBL . "  SET "; 
    $STR .= " status = :status, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE gallery_id = :gallery_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":status", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":gallery_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}	

			 

?>

