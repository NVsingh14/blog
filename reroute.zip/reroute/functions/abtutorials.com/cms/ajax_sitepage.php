<?php
session_start();
error_reporting(0);
include("config-cms.php");
include("../library/class.imageresizer.php");

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);
$type;

switch($type)
{	
		case "removeImage":
			removeImage();
			break;

		case "saveSitePageData":
				saveSitePageData();
				break;
		case "list_site_page":
			list_site_page();
			break;
		case "getSitePageData":
			getSitePageData();
			break;
		case "deleteData":
			deleteData();
			break;
		case "deleteAllData":
			deleteAllData();
			break;
		case "updateStatus":
			updateStatus();
			break;
		case "updateDisplayWebsite":
			updateDisplayWebsite();
			break;
}

	function removeImage()
        {
            global $dCON, $REQData;
            
            $file_name = trustme($REQData->file_name);
            
            $fileId = intval($REQData->site_id);
            $FOLDER_NAME = FLD_SITE_PAGE_FILE;
           
            if($fileId == intval(0))
            {
                
                //delete image
                if(unlink($file_name)) 
                {
                    //deleteIMG("GALLERY",$file_name,CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD );
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete File";
                }
            }
            else
            {
                if(unlink($file_name)) 
                {
                    $img_array = explode("/", $file_name);
                    $IMG =  $img_array[3];

                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME . $IMG );
                    //unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R50-" . $IMG );
                                
                    $SQL = "";
                    $SQL .= "UPDATE " . SITE_PAGE_TBL . " SET " ;
                    $SQL .= " document_file = :document_file, ";
                    $SQL .= " file_id = :file_id ";
                    $SQL .= " WHERE site_page_id = :site_page_id ";
                    //echo "$SQL---$img---$img_id-----$fileId" ;
                    
                    $document_file = "";
                    $img_id = intval(0);            
                         
                    $stk_upd = $dCON->prepare($SQL);
                    $stk_upd->bindParam(":document_file", $document_file);
                    $stk_upd->bindParam(":file_id", $img_id);
                    $stk_upd->bindParam(":site_page_id", $fileId);
                    $stk_upd->execute();
                    
                    $stk_upd->closeCursor();
                     
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete File";
                }
                
            } 
        }

	function saveSitePageData()
	{
		global $dCON, $REQData;
		$IP = $_SERVER['REMOTE_ADDR'];
		$TIME = date("Y-m-d H:i:s");
		$name = trustme($REQData->name);
		$url = trustme($REQData->url);
		$content = trustyou($REQData->content);
		$file = trustme($REQData->document_file);
        $document_type=trustme($REQData->document_type);
		$site_page_id = intval($REQData->site_id);
		$document_file = trustme($REQData->document_file); 
		$document_file_got = trustme($REQData->document_file_disp);
        
        $file_id = trustme($REQData->file_id);
       
        $TEMP_FOLDER_NAME = "";
        $TEMP_FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD . "/";
        
        if( !is_dir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_SITE_PAGE_FILE))
        {
            $mask=umask(0);
            mkdir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_SITE_PAGE_FILE, 0777);
            umask($mask);
        }  
        
        $FOLDER_NAME = "";
        $FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH .FLD_SITE_PAGE_FILE. "/";
    
		if(intval($site_page_id)==intval(0))
		{
        $CHK = checkDuplicate(SITE_PAGE_TBL,"status~~~title","2~~~$name","!=~~~=~~~=","");
            if(intval($CHK) == intval(0) )
            {
		           $MAXID = getMaxId(SITE_PAGE_TBL,"site_page_id");
             
                //==============FOR IMAGE
                    if( trim($document_file) != "")
                    {
                        $f_ext = pathinfo($document_file);
                        $fNAM = $MAXID."-".filterString($name);
                        $FILE =  strtolower($fNAM) . "." . $f_ext['extension'];
                        rename($TEMP_FOLDER_NAME.$document_file, $FOLDER_NAME.$FILE);
                        //resizeIMG("TESTIMONIAL",trim($IMG),$MAXID,$FOLDER_NAME);
                        
                        $file_id = intval(1);
                        
                    }
                    else
                    {
                        $FILE = "";
                        $file_id = intval(0);
                    }   
                    
                    /////FOR IMAGE ENDS

            		$SQL = "";
            		$SQL .= " INSERT INTO " . SITE_PAGE_TBL . " SET ";
            		$SQL .= " site_page_id=:site_page_id, ";
            		$SQL .= " title=:title,";
            		if($document_type=='url')
                    {
                    $SQL .= " url='".$url."', ";
                    $SQL .=" content='', ";
                    $SQL.= " document_file='', ";
                    }
                    else if($document_type=='content')
                    {
                    $SQL .= " url='', ";
                    $SQL .= " content='".$content."', ";
                    $SQL .= " document_file='', ";
                    }
                    else if($document_type=='file')
                    {
                    $SQL .=" url='', ";
                    $SQL .= " content ='', ";
                    $SQL .= " document_file='".$FILE."', ";
                    }
                    $SQL .= " file_id=:file_id, ";
            		$SQL .= " add_ip=:add_ip, ";
            		$SQL .= " add_by=:add_by, ";
            		$SQL .= " add_time=:add_time ";
            		//echo $SQL;
            		$stmt = $dCON->prepare( $SQL );
            		$stmt->bindParam(":site_page_id", $MAXID);  
            		$stmt->bindParam(":title",$name);
                    $stmt->bindParam(":file_id",$file_id); 
            		$stmt->bindParam(":add_ip", $IP);
            		$stmt->bindParam(":add_by", $_SESSION['USERNAME']);
            		$stmt->bindParam(":add_time", $TIME);
            		$rs = $stmt->execute();
            		$stmt->closeCursor();
            }
            else
            {
                $rs=2;
            }
		}
		else if(intval($site_page_id) > intval(0) )
		{

			 if(intval($file_id) == intval(0))
                {
                    
                   if( trim($document_file) != "")
                    {
                        $f_ext = pathinfo($document_file);

                        $fNAM = $site_page_id."-".filterString($name);
                        
                        $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                         
                        rename($TEMP_FOLDER_NAME.$document_file, $FOLDER_NAME.$IMG);
                        //resizeIMG("TESTIMONIAL",trim($IMG),$MAXID,$FOLDER_NAME);
                        
                        $file_id = intval(1);
                        
                    }
                    else
                    {
                        $IMG = "";
                        $file_id = intval(0);
                    }  
                }
            else
            { 
                if($document_file_got != "")
                {  
                    $chksql = " select title,document_file from " . SITE_PAGE_TBL . " where site_page_id='".$site_page_id."' ";
                    $chkstmt = $dCON->prepare($chksql);
                    $chkstmt->execute();
                    $row = $chkstmt->fetch(PDO::FETCH_ASSOC);
                    $title_name=$row['title'];
                    $db_file_name = $row['document_file'];
                    $f_ext = pathinfo($document_file_got);
                    $fNAM = $site_page_id."-".filterString($name); 
                    $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                  /*  $img_array = explode("/", $document_file_got);
                    if($title_name==$name)
                    {
                        rename($TEMP_FOLDER_NAME.$img_array[3], $FOLDER_NAME.$IMG);
                    }
                    else 
                    {
                       rename($FOLDER_NAME.$img_array[3], $FOLDER_NAME.$IMG);
                    }*/

                    $img_array = explode("/", $document_file_got);

                    if($title_name==$name && $img_array[3]!=$db_file_name)
                    {
                        unlink($FOLDER_NAME.$db_file_name);
                        $fNAM = $site_page_id."-".filterString($title_name);
                        $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                        rename($TEMP_FOLDER_NAME.$img_array[3], $FOLDER_NAME.$IMG);
                    }
                    
                    else if($title_name!=$name)
                    {
                        if($img_array[3]!=$db_file_name)
                        {
                            unlink($FOLDER_NAME.$db_file_name);
                            $fNAM = $site_page_id."-".filterString($name);
                            $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                            rename($TEMP_FOLDER_NAME.$img_array[3], $FOLDER_NAME.$IMG);
                            
                        }
                        else
                        {
                            $IMG =  $img_array[3];
                        }
                        
                    }
                    
                    $file_id = intval(1);
                }
                else
                {
                    $IMG = "";
                    $file_id = intval(0);
                }
            }  
				$SQL= "";
				$SQL .= "UPDATE " . SITE_PAGE_TBL . " SET ";
				$SQL .= " title=:title,";
                if($document_type=='url')
                {
				$SQL .= " url='".$url."', ";
                $SQL .=" content='', ";
                $SQL.= " document_file='', ";
                }
                else if($document_type=='content')
                {
                $SQL .= " url='', ";
				$SQL .= " content='".$content."', ";
                $SQL .= " document_file='', ";
                }
                else if($document_type=='file')
                {
                $SQL .=" url='', ";
                $SQL .= " content ='', ";
                $SQL .= " document_file='".$IMG."', ";
                }
                $SQL .= " file_id=:file_id, ";
				$SQL .= " update_ip=:update_ip, ";
				$SQL .= " update_by = :update_by, ";
				$SQL .= " update_time=:update_time ";
				$SQL .= " WHERE site_page_id=:site_page_id ";
				//echo $SQL;
				$stmt = $dCON->prepare( $SQL ); 
				$stmt->bindParam(":title",$name);
                $stmt->bindParam(":file_id",$file_id); 
				$stmt->bindParam(":update_ip", $IP);
				$stmt->bindParam(":update_by", $_SESSION['USERNAME']);
				$stmt->bindParam(":update_time", $TIME);
				$stmt->bindParam(":site_page_id",$site_page_id);

				$rs = $stmt->execute();
				$stmt->closeCursor();

			}

			else 
			{
				$rs=2;
			}
		$RETURN_ARRAY = array();
			 switch($rs)
			{
				case "1":
						$RETURN_ARRAY['SUCCESS'] = 1;
						$RETURN_ARRAY['MSG'] = "&#x2714; Successfully saved.";
						
						break;
				case "2":
						
						$RETURN_ARRAY['SUCCESS'] = 2;
						$RETURN_ARRAY['MSG'] = "&#x2757; Already Exists.";
						break; 
				default:
						$RETURN_ARRAY['SUCCESS'] = 0;
						$RETURN_ARRAY['MSG'] = "&#x2718; Sorry cannot process your request.";
						break;
			}

			echo json_encode($RETURN_ARRAY);
	}


function list_site_page()
{  
    global $dCON, $REQData;
    $page = intval($REQData->page) == 0 ? 1 : $REQData->page;
    $name = trustme($REQData->search_site_title);
    
    $searchArr = array();
    
    $RETURN_ARRAY = array();
    $RETURN_ARRAY['searchedFields'] = array();
    $search = "";
    if( trim($name) != "" )
    {
        $search .= " AND ( B.title = '".$name."' or B.title like '%".$name."%' )" ;
      
        $RETURN_ARRAY['searchedFields'][] = $name;
    }
    $SQL = "";
    $SQL .= " SELECT *, SUBSTRING_INDEX(content, ' ', 30) as contents_got,SUBSTRING_INDEX(document_file,'.',-1) AS file_ext ";
    $SQL .= " FROM " . SITE_PAGE_TBL . " AS B ";
    $SQL .= " WHERE B.status <> '2' ";
    $SQL .= " $search ";
    $SQL .= " ORDER BY site_page_id desc ";
    //echo $SQL;
    
    $SQL_COUNT  = "";
    $SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
    $SQL_COUNT .= $SQL;
    $SQL_COUNT .= " ) as aa ";
    $stmtCnt =  $dCON->prepare($SQL_COUNT);
    $stmtCnt->execute($searchArr);
    $noOfRecords_row = $stmtCnt->fetchObject();
    $stmtCnt->closeCursor();
    $noOfRecords = intval($noOfRecords_row->CT);
    $rowsPerPage = 25;
    $page = intval($page) - 1;
    $offset = $rowsPerPage * $page ;
    $SQL .= " LIMIT " . $offset . "," . $rowsPerPage;
    $stmt = $dCON->prepare($SQL);
    $stmt->execute($searchArr);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    $RETURN_ARRAY['data'] = $row;
    $RETURN_ARRAY['total_records'] = $noOfRecords;
    
    echo json_encode($RETURN_ARRAY);    
          
}



function getSitePageData()
{
		global $dCON,$REQData;

		$site_id = intval($REQData->site_id);

		$SQL= "";
		$SQL .= " SELECT T.* ";
		$SQL .= " FROM ". SITE_PAGE_TBL . " AS T ";
		$SQL .= " WHERE T.site_page_id=:site_id ";

		$stmt = $dCON->prepare( $SQL );
		$stmt->bindParam(":site_id", $site_id);
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();
		

		$RETURN_DATA = array();
		$RETURN_DATA['data'] = $row;
        
		echo json_encode($RETURN_DATA); 
}

function deleteData()
{
    global $dCON, $REQData;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    $site_id = intval($REQData->site_id);
    
    $STR  = "";
    $STR .= " UPDATE  " . SITE_PAGE_TBL . "  SET "; 
    $STR .= " status = '2', ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE site_page_id = :site_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":site_id", intval($site_id));
    $dRES = $sDEF->execute();
    $sDEF->closeCursor();   
    
    if(intval($dRES) > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }
    
    echo json_encode($RETURN_ARR);
}

function deleteAllData()
{
    global $dCON, $REQData;
    
    $indexIdsArray = $REQData->DIDS;
    $successCTR = 0;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    
    foreach($indexIdsArray as $indexIdObj)
    {
       $stmtDel = $dCON->prepare(" UPDATE " .SITE_PAGE_TBL . " SET `status` = '2',update_ip =:update_ip,update_by = :update_by, update_time = :update_time  WHERE site_page_id = :site_id ");
        $stmtDel->bindParam(":update_ip", $IP);
        $stmtDel->bindParam(":update_by", $_SESSION['USERNAME']);
        $stmtDel->bindParam(":update_time", $TIME);
        $stmtDel->bindParam(":site_id", $indexIdObj->site_page_id);
        $dRES = $stmtDel->execute();
        $stmtDel->closeCursor();

       
    }

    if($dRES > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }

    echo json_encode($RETURN_ARR);


}
function updateStatus()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->site_id);
    $VAL = trustme($REQData->status);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . SITE_PAGE_TBL . "  SET "; 
    $STR .= " status = :status, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE site_page_id = :site_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":status", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":site_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}


function updateDisplayWebsite()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->site_id);
    $VAL = trustme($REQData->display_on_home);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . SITE_PAGE_TBL . "  SET "; 
    $STR .= " display_on_home = :display_on_home, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE site_page_id = :site_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":display_on_home", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":site_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}


?>