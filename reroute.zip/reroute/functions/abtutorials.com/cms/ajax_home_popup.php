<?php 
session_start();
error_reporting(0);
include("config-cms.php");
include("../library/class.imageresizer.php");

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);
$type;

switch($type)
{
         case "removeImage":
            removeImage();
        break;

		case "saveData":
				saveData();
				break;
                
        case "listData";
                listData();
                break;
}
        
        function removeImage()
        {
            global $dCON, $REQData;
            
            $image_name = trustme($REQData->image_name);
            $imageId = intval($REQData->table_id);
            $FOLDER_NAME = FLD_HOME_POP_UP;
          // echo " === " . $image_name . " === " . $imageId . " ====== " . $FOLDER_NAME;
           
            if($imageId == intval(0))
            {
                echo " iddd 0";
                exit();
                //delete image
                if(unlink($image_name)) 
                {
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R500-".$image_name);
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R50-".$image_name);
                    //deleteIMG("GALLERY",$image_name,CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD );
                    $table_id = intval(1001);
                     $SQL = "";
                    $SQL .= "UPDATE " . HOME_POPUP_TBL . " SET " ;
                    $SQL .= " image_name = :image_name, ";
                    $SQL .= " image_id = :image_id ";
                    $SQL .= " WHERE table_id = :table_id ";
                    //echo "$SQL---$img---$img_id-----$imageId" ;
                    
                    $image_name = "";
                    $img_id = intval(0);            
                         
                    $stk_upd = $dCON->prepare($SQL);
                    $stk_upd->bindParam(":image_name", $image_name);
                    $stk_upd->bindParam(":image_id", $img_id);
                    $stk_upd->bindParam(":table_id", $table_id);
                    $stk_upd->execute();
                    
                    $stk_upd->closeCursor();
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete Image";
                }
            }
            else
            {
                
                if(unlink($image_name)) 
                {
                    $img_array = explode("/", $image_name);
                    $IMG =  $img_array[3];
                    
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R500-" . $IMG );
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R50-" . $IMG );
                    
                    $table_id = intval(1001);
                    $SQL = "";
                    $SQL .= "UPDATE " . HOME_POPUP_TBL . " SET " ;
                    $SQL .= " image_name = :image_name, ";
                    $SQL .= " image_id = :image_id ";
                    $SQL .= " WHERE table_id = :table_id ";
                    //echo "$SQL---$img---$img_id-----$imageId" ;
                    
                    $image_name = "";
                    $img_id = intval(0);            
                         
                    $stk_upd = $dCON->prepare($SQL);
                    $stk_upd->bindParam(":image_name", $image_name);
                    $stk_upd->bindParam(":image_id", $img_id);
                    $stk_upd->bindParam(":table_id", $table_id);
                    $stk_upd->execute();
                    
                    $stk_upd->closeCursor();         
                   
                     
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete Image";
                }
                
            } 
        }

		
	function saveData()
		{
			global $dCON, $REQData;
			$IP = $_SERVER['REMOTE_ADDR'];
			$TIME = date("Y-m-d H:i:s");
			//$image_caption = trustme($REQData->image_caption);
		//	$table_id=intval($REQData->table_id);
           $table_id = intval(1001);
            $gallery_image = trustme($REQData->gallery_img); 
            $gallery_image_got = trustme($REQData->gallery_image_disp);
            
            $image_id = trustme($REQData->image_id);
            
            $status = intval(1);
            $TEMP_FOLDER_NAME = "";
            $TEMP_FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD . "/";
            
            if( !is_dir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_HOME_POP_UP))
            {
                $mask=umask(0);
                mkdir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_HOME_POP_UP, 0777);
                umask($mask);
            }  
            
            $FOLDER_NAME = "";
            $FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH .FLD_HOME_POP_UP. "/";
            
          
			if(intval($table_id)==intval(0))
			{

			 $MAXID = getMaxId(GALLERY_TBL,"table_id");
             
                //==============FOR IMAGE
                
                
                if( trim($gallery_image) != "")
                {
                    $f_ext = pathinfo($gallery_image);
                    $fNAM = $MAXID."-"."IMAGE";
                    $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                    rename($TEMP_FOLDER_NAME.$gallery_image, $FOLDER_NAME.$IMG);
                    resizeIMG("HOME_POP_UP",trim($IMG),$MAXID,$FOLDER_NAME);
                    
                    $image_id = intval(1);
                    
                }
                else
                {
                    $IMG = "";
                    $image_id = intval(0);
                }   
                
                /////FOR IMAGE ENDS

				$SQL = "";
				$SQL .= " INSERT INTO " . HOME_POPUP_TBL . " SET ";
				$SQL .= " table_id=:table_id, ";
                //$SQL .= " image_caption=:image_caption, ";
				$SQL .= " image_name=:gallery_image, ";
                $SQL .= " image_id=:image_id, ";
               // $SQL .= " status=:status, ";
				$SQL .= " add_ip=:add_ip, ";
				$SQL .= " add_by=:add_by, ";
				$SQL .= " add_time=:add_time ";

				$stmt = $dCON->prepare( $SQL );
				$stmt->bindParam(":table_id", $MAXID);
              //  $stmt->bindParam(":image_caption", $image_caption);  
                $stmt->bindParam(":gallery_image",$IMG); 
                $stmt->bindParam(":image_id",$image_id); 
               // $stmt->bindParam(":status",$status); 
				$stmt->bindParam(":add_ip", $IP);
				$stmt->bindParam(":add_by", $_SESSION['USERNAME']);
				$stmt->bindParam(":add_time", $TIME);
				$rs = $stmt->execute();
				$stmt->closeCursor();
			}
			else if(intval($table_id) > intval(0) )
			{
		      
                if(intval($image_id) == intval(0))
                    {
                       
                        $MAXID = intval(1001);	
                        if( trim($gallery_image) != "")
                        {
                            $f_ext = pathinfo($gallery_image);
                            $fNAM = $table_id."-"."IMAGE";
                            
                            $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                            
                            rename($TEMP_FOLDER_NAME.$gallery_image, $FOLDER_NAME.$IMG);
                            resizeIMG("HOME_POP_UP",trim($IMG),$MAXID,$FOLDER_NAME);
                            
                            $image_id = intval(1);
                            
                        }
                        else
                        {
                            $IMG = "";
                            $image_id = intval(0);
                        }
                        
                    }
                    else
                    {
                        //echo " ===== " . $gallery_image_got ; 
                        
        				$SQLG = " SELECT * FROM " . HOME_POPUP_TBL . " WHERE table_id=:table_id ";
        		
        				$stmtg = $dCON->prepare( $SQLG );
        				$stmtg->bindParam(":table_id", $table_id);
        				$stmtg->execute();
                        $ROW = $stmtg->fetch();
                        
        				$stmtg->closeCursor();
                        $image_existing = $ROW['image_name'];
                      
                        if($gallery_image_got != "")
                        {     
                            $img_array = explode("/", $gallery_image_got);
                            
                           $IMG =  $img_array[3];
                           
                           if($IMG == $image_existing){
                                $IMG =  $image_existing;
                           }
                           else
                           {
                               unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/".$image_existing);  
                               unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R500-".$image_existing);
                               unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R50-".$image_existing);  
                               
                                $f_ext = pathinfo($IMG);
                                $fNAM = $table_id."-"."IMAGE";
                                
                                $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                                
                                rename($TEMP_FOLDER_NAME.$gallery_image, $FOLDER_NAME.$IMG);
                                resizeIMG("HOME_POP_UP",trim($IMG),$MAXID,$FOLDER_NAME);
                           }
                           //$IMG = $gallery_image_got;
                            $image_id = intval(1);
                        }
                        else
                        {
                            $IMG = "";
                            $image_id = intval(0);
                        }
                        
                    }
                    
                    
                    
                    
				$SQL= "";
				$SQL .= "UPDATE " . HOME_POPUP_TBL . " SET ";
                $SQL .= " image_name=:gallery_image, ";
              //  $SQL .= " image_caption=:image_caption, ";
                $SQL .= " image_id=:image_id, ";
               // $SQL .= " status=:status, ";
				$SQL .= " update_ip=:update_ip, ";
				$SQL .= " update_by = :update_by, ";
				$SQL .= " update_time=:update_time ";
				$SQL .= " WHERE table_id=:table_id ";
				
				$stmt = $dCON->prepare( $SQL );  
                $stmt->bindParam(":gallery_image",$IMG); 
              //  $stmt->bindParam(":image_caption",$image_caption);
                $stmt->bindParam(":image_id",$image_id); 
               // $stmt->bindParam(":status",$status); 
				$stmt->bindParam(":update_ip", $IP);
				$stmt->bindParam(":update_by", $_SESSION['USERNAME']);
				$stmt->bindParam(":update_time", $TIME);
				$stmt->bindParam(":table_id",$table_id);

				$rs = $stmt->execute();
				$stmt->closeCursor();

			}

			else 
			{
				$rs=2;
			}
		$RETURN_ARRAY = array();
			 switch($rs)
			{
				case "1":
						$RETURN_ARRAY['SUCCESS'] = 1;
						$RETURN_ARRAY['MSG'] = "&#x2714; Successfully saved.";
						
						break;
				case "2":
						
						$RETURN_ARRAY['SUCCESS'] = 2;
						$RETURN_ARRAY['MSG'] = "&#x2757; Already Exists.";
						break; 
				default:
						$RETURN_ARRAY['SUCCESS'] = 0;
						$RETURN_ARRAY['MSG'] = "&#x2718; Sorry cannot process your request.";
						break;
			}

			echo json_encode($RETURN_ARRAY);

		}
        
        
function listData()
{
        
    global $dCON, $REQData;
    $page = intval($REQData->page) == 0 ? 1 : $REQData->page;
    
    $title = trustme($REQData->search_gallery_title);
    
    $search_name = trustme($REQData->search_gallery_ref);
    
    $searchArr = array();
    
    $RETURN_ARRAY = array();
    $RETURN_ARRAY['searchedFields'] = array();
    
    
    
  
    
    $SQL = "";
    $SQL .= " SELECT * ";
    $SQL .= " , ( CASE WHEN image_name <> '' THEN CONCAT('" . CMS_UPLOAD_FOLDER_RELATIVE_PATH . "home_pop_up/" . "', B.image_name) ELSE '' END ) as popup_image_disp ";
    $SQL .= " FROM " . HOME_POPUP_TBL . " AS B ";
    
    $SQL .= " WHERE B.image_id != '0' AND B.table_id = '1001' ";
  
    ///$SQL .= " ORDER BY gallery_title ";
    //echo $SQL;
    
    $SQL_COUNT  = "";
    $SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
        $SQL_COUNT .= $SQL;
    $SQL_COUNT .= " ) as aa ";
    
    
    $stmtCnt =  $dCON->prepare($SQL_COUNT);
    $stmtCnt->execute($searchArr);
    $noOfRecords_row = $stmtCnt->fetchObject();
    $stmtCnt->closeCursor();
    $noOfRecords = intval($noOfRecords_row->CT);

    $rowsPerPage = 2000;

    $page = intval($page) - 1;
    $offset = $rowsPerPage * $page ;

    $SQL .= " LIMIT " . $offset . "," . $rowsPerPage;

    $stmt = $dCON->prepare($SQL);
    $stmt->execute($searchArr);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    
    $RETURN_ARRAY['data'] = $row;
    $RETURN_ARRAY['total_records'] = $noOfRecords;
    
    echo json_encode($RETURN_ARRAY);    
          
}

			 

?>

