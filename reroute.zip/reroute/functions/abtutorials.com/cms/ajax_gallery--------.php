<?php 
session_start();
error_reporting(0);
include("config-cms.php");

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);

switch($type)
{
    case "saveData":
        saveData();
        break; 
    case "listData":
        listData();
        break; 
    case "updateStatus":
        updateStatus();
        break;   
    case "getDetail":
        getDetail();
        break;
    case "deleteData":
        deleteData();
        break; 
    case "savePosition":
        savePosition();
        break;    
            
 }

function saveData()
{
    global $dCON, $REQData;
    
    $IP = $_SERVER['REMOTE_ADDR'];
    $TIME = date("Y-m-d H:i:s");
     
    $category_name = trustme($REQData->category_name);
    $annual_depreciation = floatval($REQData->annual_depreciation);
    $category_tds = floatval($REQData->category_tds);
    
    $rent_to_own = intval($REQData->rent_to_own);
    if(intval($rent_to_own) == intval(1))
    {
        $duration = intval($REQData->duration);
    }
    else
    {
        $duration = 0;
    }
  
    $status = trustme($REQData->status);
    
    $category_id = intval($REQData->category_id);
     
    
    if(intval($category_id) == intval(0))
    {
        
        $CHK = checkDuplicate(PRODUCT_CATEGORY_TBL,"status~~~category_name","2~~~$category_name","!=~~~=~~~=","");
                      
        if( ( intval($CHK) == intval(0) ) )
        {
            $MAXID = getMaxId(PRODUCT_CATEGORY_TBL,"category_id"); 
            
            $MAX_POS = 0;
            $MAX_POS = getMaxPosition(PRODUCT_CATEGORY_TBL,"position","","","=");
            
            $SQL  = "";
            $SQL .= " INSERT INTO " . PRODUCT_CATEGORY_TBL . " SET ";
            $SQL .= " category_id = :category_id, ";  
            $SQL .= " category_name = :category_name, ";
            $SQL .= " annual_depreciation = :annual_depreciation, ";
            $SQL .= " category_tds = :category_tds, ";
            $SQL .= " rent_to_own = :rent_to_own, ";
            $SQL .= " duration = :duration, "; 
            //$SQL .= " status = :status, ";
            $SQL .= " position = :position, "; 
            $SQL .= " add_ip = :add_ip, ";
            $SQL .= " add_by = :add_by, "; 
            $SQL .= " add_time = :add_time"; 
                        
            $stmt = $dCON->prepare( $SQL );
            $stmt->bindParam(":category_id", $MAXID);             
            $stmt->bindParam(":category_name", $category_name);
            $stmt->bindParam(":annual_depreciation", $annual_depreciation);
            $stmt->bindParam(":category_tds", $category_tds);
            $stmt->bindParam(":rent_to_own", $rent_to_own);
            $stmt->bindParam(":duration", $duration);
            //$stmt->bindParam(":status", $status); 
            $stmt->bindParam(":position", $MAX_POS); 
            $stmt->bindParam(":add_ip", $IP);
            $stmt->bindParam(":add_by", $_SESSION['USERNAME']);
            $stmt->bindParam(":add_time", $TIME);
            $rs = $stmt->execute();
            $stmt->closeCursor();
            if( intval($rs) == intval(1) )
            { 
                
            }  
             
        }
        else
        {
            $rs = 2;
            
        }
            
    }
    else if(intval($category_id) > intval(0))
    {
        
        
        $CHK = checkDuplicate(PRODUCT_CATEGORY_TBL,"status~~~category_name~~~category_id","2~~~$category_name~~~$category_id","!=~~~=~~~!=","");
         
        
        if( ( intval($CHK) == intval(0) ) )
        {
            
            $SQL  = "";
            $SQL .= " UPDATE " . PRODUCT_CATEGORY_TBL . " SET "; 
            $SQL .= " category_name = :category_name, "; 
            $SQL .= " annual_depreciation = :annual_depreciation, "; 
            $SQL .= " category_tds = :category_tds, ";
            $SQL .= " rent_to_own = :rent_to_own, ";
            $SQL .= " duration = :duration, "; 
            //$SQL .= " status = :status, "; 
            $SQL .= " update_ip = :update_ip, ";
            $SQL .= " update_by = :update_by, "; 
            $SQL .= " update_time = :update_time"; 
            $SQL .= " WHERE category_id = :category_id "; 
            
            $stmt = $dCON->prepare( $SQL );
            $stmt->bindParam(":category_name", $category_name);
            $stmt->bindParam(":annual_depreciation", $annual_depreciation);
            $stmt->bindParam(":category_tds", $category_tds);
            $stmt->bindParam(":rent_to_own", $rent_to_own);
            $stmt->bindParam(":duration", $duration);
            //$stmt->bindParam(":status", $status); 
            $stmt->bindParam(":update_ip", $IP);
            $stmt->bindParam(":update_by", $_SESSION['USERNAME']);
            $stmt->bindParam(":update_time", $TIME);
            $stmt->bindParam(":category_id", $category_id); 
            $rs = $stmt->execute();
            $stmt->closeCursor();
            if( intval($rs) == intval(1) )
            {               
                
                $stkUpdate = $dCON->prepare("update " . PO_ASSIGN_PRODUCT_TBL . " set rent_to_own = '$rent_to_own', rent_to_own_duration = '$duration' WHERE category_id = :category_id and return_id = 0 " );
                $stkUpdate->bindParam(":category_id", $category_id);
                $stkUpdate->execute();
                $stkUpdate->closeCursor();
                          
            }  
                 
        }
        else
        {
            $rs = 2;            
        }
    }
    
    
    $RETURN_ARRAY = array();
    
    switch($rs)
    {
        case "1":
            $RETURN_ARRAY['SUCCESS'] = 1;
            $RETURN_ARRAY['MSG'] = "Successfully saved.";
            
            break;
        case "2":
            
            $RETURN_ARRAY['SUCCESS'] = 2;
            $RETURN_ARRAY['MSG'] = "Already Exists.";
            break; 
        default:
            $RETURN_ARRAY['SUCCESS'] = 0;
            $RETURN_ARRAY['MSG'] = "Sorry cannot process your request.";
            break;
    }
    
    echo json_encode($RETURN_ARRAY);  
}




function listData()
{
        
    global $dCON, $REQData;
     
    $SQL2 = "";
    $SQL2 .= " SELECT S.* ";
    $SQL2 .= " ,(SELECT count(*) FROM " . PRODUCT_TYPE_TBL . " as V WHERE V.category_id = S.category_id ) as vCount  ";
    $SQL2 .= " FROM " . PRODUCT_CATEGORY_TBL . " AS S ";
    $SQL2 .= " WHERE S.status <> '2' ";
    $SQL2 .= " $search ";
    $SQL2 .= " ORDER BY S.category_name, S.position ";
    $stmt = $dCON->prepare($SQL2); 
    $stmt->execute();
    $row = $stmt->fetchAll();
    
    $RETURN_ARRAY = array();
    
    $RETURN_ARRAY['data'] = $row;
    $RETURN_ARRAY['noofrecords'] = count($row);
    
    echo json_encode($RETURN_ARRAY);    
          
}


function updateStatus()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->category_id);
    $VAL = trustme($REQData->status);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . PRODUCT_CATEGORY_TBL . "  SET "; 
    $STR .= " status = :status, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE category_id = :category_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":status", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":category_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}


function getDetail()
{
    global $dCON, $REQData;
    
    $category_id = intval($REQData->category_id);
    
    $SQL  = "";
    $SQL .= " SELECT T.*  "; 
    $SQL .= " FROM " . PRODUCT_CATEGORY_TBL . " AS T WHERE T.`status` <> '2' ";
    $SQL .= " AND category_id = :category_id ";
    //echo "===".$SQL;
    
    $stmt = $dCON->prepare($SQL);
    $stmt->bindParam(":category_id", $category_id); 
    $stmt->execute();
    $row = $stmt->fetchAll();
    $stmt->closeCursor();
     

    $RETURN_DATA = array();
    $RETURN_DATA['total_records'] = intval(count($row));
    $RETURN_DATA['data'] = $row;

    echo json_encode($RETURN_DATA);    
    
}


function savePosition()
{
    global $dCON, $REQData;
    
        
    foreach($REQData->data as $dataObj)
    { 
        $stmtPos = $dCON->prepare(" UPDATE " . PRODUCT_CATEGORY_TBL . " SET `position` = :position WHERE category_id = :category_id ");
        $stmtPos->bindParam(":position", intval($dataObj->segment_position));
        $stmtPos->bindParam(":category_id", intval($dataObj->category_id)); 
        $dRES = $stmtPos->execute();
        $stmtPos->closeCursor();
    }
}



function deleteData()
{
    global $dCON, $REQData;
    
    $category_id = intval($REQData->category_id);
    
    $stmtDel = $dCON->prepare(" UPDATE " . PRODUCT_CATEGORY_TBL . " SET `status` = '2' WHERE category_id = :category_id ");
    $stmtDel->bindParam(":category_id", intval($category_id));
    $dRES = $stmtDel->execute();
    $stmtDel->closeCursor();
    
    if(intval($dRES) > 0)
    {
        
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }
    
    echo json_encode($RETURN_ARR);
}


?>

