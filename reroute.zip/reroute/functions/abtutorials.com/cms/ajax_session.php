<?php
ob_start();
session_start();
 
if(!isset($_SESSION['UID_ABTUTORIAL']) && intval($_SESSION['UID_ABTUTORIAL']) == intval(0))
{
    header("Location:login.php?msg=".urlencode("Please login to access the app"));
    exit;    
}
?>