<?php 
session_start();
error_reporting(0);
include("config-cms.php");

include("../library/class.imageresizer.php");


$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);

switch($type)
{
   
   case "chkProduct":
        chkProduct();
        break; 
    case "removeImage":
        removeImage();
        break; 
      
    case "saveData":
        saveData();
        break; 
        
    case "listData":
        listData();
        break; 
        
    case "updateStatus":
        updateStatus();
        break;  
         
    case "getDetail":
        getDetail();
        break;
    case "deleteData":
        deleteData();
        break; 
    case "deleteAllData":
        deleteAllData();
        break; 
    case "updateDisplayWebsite":
        updateDisplayWebsite();
        break;
    
}


function removeImage()
{
    global $dCON, $REQData;
    
    $image_name = trustme($REQData->image_name);
    $product_type_id = intval($REQData->product_type_id);
    
    
    if($product_type_id == intval(0))
    {
        //delete image
        if(unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD . "/" . $image_name)) 
        {
            deleteIMG("PRODUCT_IMAGE",$document_name,CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD );
            echo "1~~~Deleted";
        } 
        else 
        {
            echo "0~~~Sorry Cannot Delete File";
        }
    }
    else
    {
        if(unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . FLD_PRODUCT_IMAGE . "/" . $image_name)) 
        {
            
            deleteIMG("PRODUCT_IMAGE",$document_name,CMS_UPLOAD_FOLDER_RELATIVE_PATH . FLD_PRODUCT_IMAGE );
                      
            $stk_del = $dCON->prepare("update " . PRODUCT_TYPE_TBL . " set product_image = '' WHERE product_type_id = :product_type_id " );
            $stk_del->bindParam(":product_type_id", $product_type_id);
            $stk_del->execute();
            $stk_del->closeCursor();
             
            echo "1~~~Deleted";
        } 
        else 
        {
            echo "0~~~Sorry Cannot Delete File";
        }
        
    } 
}



function chkProduct()
{
        
    global $dCON, $REQData;
    
    $product_type_name = trustme($REQData->product_type_name);
    $product_type_id = intval($REQData->product_type_id);    
    $category_id = intval($REQData->category_id);    
         
         
         
    $SQL = "";
    $SQL .= " SELECT count(*) as ct FROM " . PRODUCT_TYPE_TBL . " AS C ";
    $SQL .= " WHERE C.status <> '2' and product_type_name = '".$product_type_name."' ";
    $SQL .= " and category_id = '".$category_id."' ";
    
    if(intval($product_type_id)>intval(0))
    {
        $SQL .= " and product_type_id != '".$product_type_id."' ";
    }
    
    $stmt = $dCON->prepare($SQL); 
    $stmt->execute();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $RETURN_ARRAY = array();
    
    $RETURN_ARRAY['dataRow'] = $row;
    
    echo json_encode($RETURN_ARRAY);    
          
}




function saveData()
{
    global $dCON, $REQData;
    //echo "<pre>";
    //print_r($REQData);
    //echo "</pre>";
    //exit;
    $IP = $_SERVER['REMOTE_ADDR'];
    $TIME = date("Y-m-d H:i:s");
    
    $product_type_name = trustme($REQData->product_type_name); 
    $category_id = intval($REQData->category_id);
    $product_type_Prefix = trustme($REQData->product_type_Prefix);
    $hsn_code_id = intval($REQData->hsn_code_id);
    
    $standard_delivery_time = trustme($REQData->standard_delivery_time); 
    $display_on_website = intval($REQData->display_on_website);
    
    if(intval($hsn_code_id) > intval(0))
    {
        $rsHSN = getDetails(HSN_CODE_TBL, '*', "status~~~hsn_code_id","1~~~".intval($hsn_code_id),'=~~~=', '', '' , "");
        $hsn_code_name = $rsHSN[0]['hsn_code_name'];
        $hsn_code_value = $rsHSN[0]['hsn_code_value'];
    }
    
                    
    $status = 1;//trustme($REQData->status);
    $product_type_id = intval($REQData->product_type_id);
    
    
    $product_image = trustme($REQData->product_image);
    
    $TEMP_FOLDER_NAME = "";
    $TEMP_FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD . "/";
    
    $FOLDER_NAME = "";
    $FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH . FLD_PRODUCT_IMAGE . "/";
    
    //echo "--".$FOLDER_NAME."--".$TEMP_FOLDER_NAME;
    
    //exit;
    
    if(intval($product_type_id) == intval(0))
    {
        
        $CHK = checkDuplicate(PRODUCT_TYPE_TBL,"status~~~product_type_name~~~category_id","2~~~$product_type_name~~~$category_id","!=~~~=~~~=","");
                      
        if( ( intval($CHK) == intval(0) ) )
        {
            $MAXID = getMaxId(PRODUCT_TYPE_TBL,"product_type_id"); 
            
            if($product_image != "")
            {
                $title_filter = filterString($product_type_name);
                $f_ext = pathinfo($product_image);
                
                $l_path_name =  strtolower($title_filter) . "-" . $MAXID ."." . $f_ext['extension'];
                
                rename($TEMP_FOLDER_NAME.$product_image, $FOLDER_NAME.$l_path_name);
                
                resizeIMG("PRODUCT",trim($l_path_name),$MAXID,$FOLDER_NAME); 
                
            }
            else
            {
                $l_path_name = "";
            }
            
            
            
            $SQL  = "";
            $SQL .= " INSERT INTO " . PRODUCT_TYPE_TBL . " SET ";            
            $SQL .= " product_type_id = :product_type_id,"; 
            $SQL .= " category_id = :category_id,"; 
            $SQL .= " product_type_name = :product_type_name,"; 
            $SQL .= " product_type_Prefix = :product_type_Prefix,"; 
            $SQL .= " hsn_code_id = :hsn_code_id,"; 
            $SQL .= " hsn_code_name = :hsn_code_name,"; 
            $SQL .= " hsn_code_value = :hsn_code_value,"; 
            $SQL .= " product_image = :product_image,"; 
            $SQL .= " standard_delivery_time = :standard_delivery_time,"; 
            $SQL .= " display_on_website = :display_on_website,"; 
            //$SQL .= " status = :status, "; 
            $SQL .= " add_ip = :add_ip, ";
            $SQL .= " add_by = :add_by, "; 
            $SQL .= " add_time = :add_time"; 
                        
            $stmt = $dCON->prepare( $SQL );
            $stmt->bindParam(":product_type_id", $MAXID);    
            $stmt->bindParam(":category_id", $category_id); 
            $stmt->bindParam(":product_type_name", $product_type_name); 
            $stmt->bindParam(":product_type_Prefix", $product_type_Prefix); 
            $stmt->bindParam(":hsn_code_id", $hsn_code_id); 
            $stmt->bindParam(":hsn_code_name", $hsn_code_name); 
            $stmt->bindParam(":hsn_code_value", $hsn_code_value); 
            $stmt->bindParam(":product_image", $l_path_name); 
            $stmt->bindParam(":standard_delivery_time", $standard_delivery_time); 
            $stmt->bindParam(":display_on_website", $display_on_website); 
            //$stmt->bindParam(":status", $status); 
            $stmt->bindParam(":add_ip", $IP);
            $stmt->bindParam(":add_by", $_SESSION['USERNAME']);
            $stmt->bindParam(":add_time", $TIME);
            $rs = $stmt->execute();
            $stmt->closeCursor();
            
            if( intval($rs) == intval(1) )
            { 
                
            }  
             
        }
        else
        {
            $rs = 2;
            
        }
            
    }
    else if(intval($product_type_id) > intval(0))
    {
        $product_image_added = trustme($REQData->product_image_added);
      
        $CHK = checkDuplicate(PRODUCT_TYPE_TBL,"status~~~product_type_name~~~category_id~~~product_type_id","2~~~$product_type_name~~~$category_id~~~$product_type_id","!=~~~=~~~=~~~!=","");
       
        
        if( ( intval($CHK) == intval(0) ) )
        {
           
            if($product_image != "")
            {
                $title_filter = filterString($product_type_name);
                $f_ext = pathinfo($product_image);
                
                $l_path_name =  strtolower($title_filter) . "-" . $product_type_id."." . $f_ext['extension'];
                rename($TEMP_FOLDER_NAME.$product_image, $FOLDER_NAME.$l_path_name);
                
                resizeIMG("PRODUCT",trim($l_path_name),$product_type_id,$FOLDER_NAME); 
            }
            else
            {
                $l_path_name = $product_image_added."";
            } 
           
           
            $SQL  = "";
            $SQL .= " UPDATE " . PRODUCT_TYPE_TBL . " SET "; 
            $SQL .= " category_id = :category_id,"; 
            $SQL .= " product_type_name = :product_type_name,"; 
            $SQL .= " product_type_Prefix = :product_type_Prefix,"; 
            $SQL .= " hsn_code_id = :hsn_code_id,"; 
            $SQL .= " hsn_code_name = :hsn_code_name,"; 
            $SQL .= " hsn_code_value = :hsn_code_value,"; 
            $SQL .= " product_image = :product_image,"; 
            $SQL .= " standard_delivery_time = :standard_delivery_time,"; 
            $SQL .= " display_on_website = :display_on_website,"; 
            //$SQL .= " status = :status, "; 
            $SQL .= " update_ip = :update_ip, ";
            $SQL .= " update_by = :update_by, "; 
            $SQL .= " update_time = :update_time"; 
            $SQL .= " WHERE product_type_id = :product_type_id "; 
            $stmt = $dCON->prepare( $SQL );
           
            $stmt->bindParam(":category_id", $category_id); 
            $stmt->bindParam(":product_type_name", $product_type_name); 
            $stmt->bindParam(":product_type_Prefix", $product_type_Prefix); 
            $stmt->bindParam(":hsn_code_id", $hsn_code_id); 
            $stmt->bindParam(":hsn_code_name", $hsn_code_name); 
            $stmt->bindParam(":hsn_code_value", $hsn_code_value); 
            $stmt->bindParam(":product_image", $l_path_name);             
            $stmt->bindParam(":standard_delivery_time", $standard_delivery_time); 
            $stmt->bindParam(":display_on_website", $display_on_website);             
            //$stmt->bindParam(":status", $status); 
            $stmt->bindParam(":update_ip", $IP);
            $stmt->bindParam(":update_by", $_SESSION['USERNAME']);
            $stmt->bindParam(":update_time", $TIME);
            $stmt->bindParam(":product_type_id", $product_type_id); 
            $rs = $stmt->execute();
            $stmt->closeCursor();
            if( intval($rs) == intval(1) )
            {               
                $stkUpdate = $dCON->prepare("update " . PURCHASE_TBL . " set category_id = '$category_id' WHERE product_type_id = :product_type_id " );
                $stkUpdate->bindParam(":product_type_id", $product_type_id);
                $stkUpdate->execute();
                $stkUpdate->closeCursor();
                
                $stkUpdate = $dCON->prepare("update " . PO_ASSIGN_PRODUCT_TBL . " set category_id = '$category_id' WHERE product_type_id = :product_type_id and return_id = 0 " );
                $stkUpdate->bindParam(":product_type_id", $product_type_id);
                $stkUpdate->execute();
                $stkUpdate->closeCursor();
                    
            }  
                 
        }
        else
        {
            $rs = 2;            
        }
    }
    
    
    $RETURN_ARRAY = array();
    
    switch($rs)
    {
        case "1":
            $RETURN_ARRAY['SUCCESS'] = 1;
            $RETURN_ARRAY['MSG'] = "&#x2714; Successfully saved.";
            
            break;
        case "2":
            
            $RETURN_ARRAY['SUCCESS'] = 2;
            $RETURN_ARRAY['MSG'] = "&#x2757; Already Exists.";
            break; 
        default:
            $RETURN_ARRAY['SUCCESS'] = 0;
            $RETURN_ARRAY['MSG'] = "&#x2718; Sorry cannot process your request.";
            break;
    }
    
    echo json_encode($RETURN_ARRAY);  
}




function listData()
{
        
    global $dCON, $REQData;
    $page = intval($REQData->page) == 0 ? 1 : $REQData->page;
    
    $category_id = intval($REQData->search_category_id);
    $product_type_name = trustme($REQData->search_product_type_name);
    $hsn_code_id = trustme($REQData->search_hsn_code_id);
    $product_type_Prefix = trustme($REQData->product_type_Prefix);
    
    
    $search_status = trustme($REQData->search_status);
    
    $searchArr = array();
    
    $RETURN_ARRAY = array();
    $RETURN_ARRAY['searchedFields'] = array();
    
    if( intval($category_id) > intval(0) )
    {
        $search .= " AND B.category_id = '".$category_id."' ";
        $RETURN_ARRAY['searchedFields'][] = getDetails(PRODUCT_CATEGORY_TBL, 'category_name', "status~~~category_id","2~~~$category_id",'!=~~~=', '', '' , "");
    }
    
    if( trim($product_type_name) != "" )
    {
        $search .= " AND B.product_type_name like '%".$product_type_name."%' ";
        $RETURN_ARRAY['searchedFields'][] = $product_type_name;
    }
    
    if( intval($hsn_code_id) > intval(0) )
    {
        $search .= " AND B.hsn_code_id = '".$hsn_code_id."' ";
        $RETURN_ARRAY['searchedFields'][] = getDetails(HSN_CODE_TBL, 'hsn_code_name', "status~~~hsn_code_id","2~~~$hsn_code_id",'!=~~~=', '', '' , "");
    }
    
    if( trim($product_type_Prefix) != "" )
    {
        $search .= " AND B.product_type_Prefix like '%".$product_type_Prefix."%' ";
        $RETURN_ARRAY['searchedFields'][] = $product_type_Prefix;
    }
    
    
    if( trim($search_status) != "" )
    {
        $searchArr[":search_status"] = $search_status;
        $search .= " AND B.status = :search_status ";
        $RETURN_ARRAY['searchedFields'][] = $search_status == 0 ? "Inactive" : "Active";
    }
    
    $SQL = "";
    $SQL .= " SELECT B.* ";
    $SQL .= " , ( CASE WHEN product_image <> '' THEN CONCAT('" . CMS_UPLOAD_FOLDER_RELATIVE_PATH . FLD_PRODUCT_IMAGE . "/R50-" . "', B.product_image) ELSE '' END ) as product_image_disp ";
    $SQL .= " ,(SELECT category_name FROM " . PRODUCT_CATEGORY_TBL . " as C WHERE C.category_id = B.category_id and status='1' ) as category_name ";
    $SQL .= " FROM " . PRODUCT_TYPE_TBL . " AS B ";
    $SQL .= " WHERE B.status <> '2' ";
    $SQL .= " $search ";
    $SQL .= " ORDER BY product_type_name ";
    //echo $SQL;
    
    $SQL_COUNT  = "";
    $SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
        $SQL_COUNT .= $SQL;
    $SQL_COUNT .= " ) as aa ";
    
    
    $stmtCnt =  $dCON->prepare($SQL_COUNT);
    $stmtCnt->execute($searchArr);
    $noOfRecords_row = $stmtCnt->fetchObject();
    $stmtCnt->closeCursor();
    $noOfRecords = intval($noOfRecords_row->CT);

    $rowsPerPage = 100;

    $page = intval($page) - 1;
    $offset = $rowsPerPage * $page ;

    $SQL .= " LIMIT " . $offset . "," . $rowsPerPage;

    $stmt = $dCON->prepare($SQL);
    $stmt->execute($searchArr);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    
    $RETURN_ARRAY['data'] = $row;
    $RETURN_ARRAY['total_records'] = $noOfRecords;
    
    echo json_encode($RETURN_ARRAY);    
          
}




function updateStatus()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->product_type_id);
    $VAL = trustme($REQData->status);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . PRODUCT_TYPE_TBL . "  SET "; 
    $STR .= " status = :status, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE product_type_id = :product_type_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":status", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":product_type_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}

function getDetail()
{
    global $dCON, $REQData;
    
    $product_type_id = intval($REQData->product_type_id);
    
    $SQL  = "";
    $SQL .= " SELECT T.*  "; 
    $SQL .= " , ( CASE WHEN product_image <> '' THEN CONCAT('" . CMS_UPLOAD_FOLDER_RELATIVE_PATH . FLD_PRODUCT_IMAGE . "/" . "', T.product_image) ELSE '' END ) as product_image_disp ";
    $SQL .= " FROM " . PRODUCT_TYPE_TBL . " AS T WHERE T.`status` <> '2' ";
    $SQL .= " AND product_type_id = :product_type_id";
    
    //echo "===".$SQL;
    $stmt = $dCON->prepare($SQL);
    $stmt->bindParam(":product_type_id", $product_type_id); 
    $stmt->execute();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    
    if(intval(count($row)) >intval(0))
    {
        
    }  
     

    $RETURN_DATA = array();
    $RETURN_DATA['total_records'] = intval(count($row));
    $RETURN_DATA['data'] = $row;
    
    echo json_encode($RETURN_DATA);    
    
}


function deleteData()
{
    global $dCON, $REQData;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    $product_type_id = intval($REQData->product_type_id);
    
    //$stmtDel = $dCON->prepare(" UPDATE " . PRODUCT_TYPE_TBL . " SET `status` = '2' WHERE product_type_id = :product_type_id ");
    //$stmtDel->bindParam(":product_type_id", intval($product_type_id));
    //$dRES = $stmtDel->execute();
    //$stmtDel->closeCursor();
    
    $STR  = "";
    $STR .= " UPDATE  " . PRODUCT_TYPE_TBL . "  SET "; 
    $STR .= " status = '2', ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE product_type_id = :product_type_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":product_type_id", intval($product_type_id));
    $dRES = $sDEF->execute();
    $sDEF->closeCursor();   
    
    if(intval($dRES) > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }
    
    echo json_encode($RETURN_ARR);
}


function deleteAllData()
{
    global $dCON, $REQData;
    
    $indexIdsArray = $REQData->DIDS;
    $successCTR = 0;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    
    foreach($indexIdsArray as $indexIdObj)
    {
        $stmtDel = $dCON->prepare(" UPDATE " .PRODUCT_TYPE_TBL . " SET `status` = '2',update_by = :update_by, update_ip = :update_ip, update_time = :update_time  WHERE product_type_id = :product_type_id ");
        $stmtDel->bindParam(":update_ip", $IP);
        $stmtDel->bindParam(":update_by", $_SESSION['USERNAME']);
        $stmtDel->bindParam(":update_time", $TIME);
        $stmtDel->bindParam(":product_type_id", $indexIdObj->product_type_id);
        $dRES = $stmtDel->execute();
        $stmtDel->closeCursor();

        if(intval($dRES) > 0)
        {
            $successCTR++;
        }
    }

    if($successCTR > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }

    echo json_encode($RETURN_ARR);


}

function updateDisplayWebsite()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->product_type_id);
    $VAL = trustme($REQData->display_on_website);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . PRODUCT_TYPE_TBL . "  SET "; 
    $STR .= " display_on_website = :display_on_website, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE product_type_id = :product_type_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":display_on_website", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":product_type_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}



?>

