<?php 
error_reporting(0);
ob_start();
include("header.php");
define("PAGE_AJAX","ajax_banner.php"); 

?>
<div class="headingWrap">
	<div class="container">
		<div class="headingTitle">
			 <div class="row">
                 <div class="col-sm-6">
                     <h1>Banner</h1>
                 </div>
                 <div class="col-sm-6">
                    <div class="pull-right"></div>
                 </div>
            </div>
		</div>
	</div>
</div> 
<div class="container theme-showcase mainWrp" ng-controller="bannerController">
    
    <div class="row">
            <div class="col-md-6">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title" ng-cloak>{{cTitle}}</h3>
                    </div>
                    <div class="box-body">
                        <form name="frmAdd" id="frmAdd" novalidate ng-submit="frmAdd.$valid && submit()">
                            <div class="row">
                                <div class="col-md-12 col-sm-6 form-group">
                                    <label for="">Upload Image <font color="red">*</font> &nbsp;<a href="javascript: void(0)" ngf-select="upload($file)" ngf-max-size="5MB"><i class="fa fa-upload" aria-hidden="true"></i> Upload</a></label>
                                    <input  type="hidden" name="banner_image"  ng-model="dataFrm.banner_image">  <!--ng-required="!dataFrm.hall_id" /-->
                                    <input type="hidden" name="image_id"  ng-model="dataFrm.image_id">
                
                                    <div ngf-model-invalid="errorFile" ngf-drop="upload($file)" class="drag-drop-box" ngf-drag-over-class="'dragover'" ngf-multiple="false" ngf-pattern="'image/png,image/jpeg,image/jpg,image/gif'" accept="image/*" ngf-max-size="5MB">
            
                                        <div ng-if="fuploading == 0" style="position:absolute; top:50%; text-align:center; width: 100%;">Drop Image file here (jpg/png/gif) - Max Image Size: 5MB</div>
                                        <div ng-cloak ng-if="fuploading == 1" style="position:absolute; top:50%; margin-top:-16px; text-align:center; width: 100%;"><img src="<?php echo LOGIN_IMAGES;?>load.gif" border="0"></div>
                                        <div ng-cloak ng-if="fuploading == 2" style="text-align:center; width: 100%;">
                                            <img ng-src="{{dataFrm.banner_image_disp}}" width="150" ><br />
                                            <a href="javscript: void(0)" ng-click="removeImage(dataFrm.banner_id)"><i class="fa fa-trash" aria-hidden="true" title="Remove"></i></a>
                                            <br />To change the image please drag new image here!
                                        </div>
                                        <div ng-cloak ng-if="fuploading == 3" style="position:absolute; top:50%; text-align:center; width: 100%;">{{fileuploaderror}}</div>
                                        
                                    </div>
                                </div>
                                

                                <div class="col-md-12 col-sm-6">   
                                    <fieldset class="form-group">
                                        <label for="cgst_percentage">Title </label>
                                         <div class="">
                                           <div ckeditor="options" ng-model="dataFrm.banner_title"></div>
                                           
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-10 col-sm-12">
                                    <input ng-if="submitProcess == 0" type="submit" name="submit" value="Save" class="btn btn-primary saveBtn" ng-disabled="frmAdd.$invalid" />
                                    
                                    <div ng-if="submitProcess == 1" ng-cloak>
    									<img src="<?php echo LOGIN_IMAGES;?>load.gif" width="30" align="absmiddle" />
    									Processing...
    								</div>
                                    
                                    <div class="row" ng-if="submitProcess == 2" ng-cloak>
            							<div class="col-md-12">
            								<div ng-bind-html="submitProcessMsg"></div>
            							</div>
            						</div>
                                    
                               </div>
                            </div> 
                             
                        </form>
                    
                    </div>
                </div>
            </div>
       
        
        <div class="col-md-6">
            <div class="box box-success">
                <div class="box-header with-border">
                  <h3 class="box-title">Manage</h3>

                  <div class="pull-right totalRcrds" ng-show="allListArray.length > 0" >
                 
                 Total Records : {{totalItems}}
            </div>
                </div>
                <div class="box-body">
                    <div ng-show="listPageLoader" class="loadDiv" style="z-index: 9999; text-align:center; height:200px; width:100%;">
                        <img src="<?php echo LOGIN_IMAGES;?>load.gif">
                    </div>
                    
                    <div ng-if="allListArray.length" ng-cloak>     
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th width="10%" class="text-center">Status </th>
                                        <th width="20%" class="text-left">Image</th> 
                                        <th class="text-left" width="20%">Title</th> 
                                        <th width="20%" class="text-center" ng-if="!$first">Position</th>
                                        <th width="20%" class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr dir-paginate="listObj in allListArray | itemsPerPage: itemsPerPage" total-items="totalItems" current-page="pagination.current" ng-style="{{ listObj.entities_count > 0 && {'font-weight':''} || '' }} " >
                                        <td class="text-center"> 
                                            <div ng-init='listObj.loading = false' >
                                                <a href="javascript: void(0)" ng-click="updateStatus(listObj.banner_id,listObj.status,$index)" ng-hide="listObj.loading">
                                                <span title="{{ listObj.status!=0 ?'Active' : 'In-Active'}}" ng-class="listObj.status == 1 && 'fa fa-check-circle-o green font22' || 'fa fa-times-circle-o red font22'" aria-hidden="true"></span>
                                                </a> 
                                                <span ng-show="listObj.loading" class="loadStatus"><img src="<?php echo LOGIN_IMAGES;?>load.gif" /></span>
                                            </div>
                                        </td>
                                        <td>
                                            <img ng-src="{{'../uploads_abtutorial/banner_image/R50-'+listObj.banner_image}}" style="width: 50px;" ng-if="listObj.image_id != '0'"/>
                                        </td> 
                                             
                                        <td class="text-left" ng-bind-html="listObj.banner_title">
                                             
                                        </td> 

                                        
                                        <td class="text-center" style="vertical-align: middle;">
                                            <div ng-if="!posLoader">
                                                <a href="javascript: void(0);" ng-if="!$first" ng-click="goUp($index,listObj.banner_id,listObj.position)">
                                                    <span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span>
                                                </a>

                                                <a href="javascript: void(0);" ng-if="!$last" ng-click="goDown($index,listObj.banner_id,listObj.position)">
                                                    <span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span>
                                                </a>
                                            </div>
                                            <span ng-if="listObj.posLoader" class="loadStatus"><img src="<?php echo LOGIN_IMAGES;?>load.gif" /></span>
                                            <!-- <img src="voxel_images/load.gif" width="10" ng-if="posLoader"> -->
                                        </td>
                                        <td align="center"> 
                                           
                                                <a type="button" class="btn btn-xs btn-primary" href="javascript: void(0)" ng-click="modifyData(listObj.banner_id)"><i class="fa fa-cogs" aria-hidden="true"></i> Edit</a>
                                                <a type="button" class="btn btn-xs btn-danger" href="javascript:void(0);" ng-click="listObj.vCount>0 || deleteData(listObj.banner_id)" ng-disabled='listObj.vCount>0' ><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a>
                                         </td>
                                    </tr> 
                                </tbody>
                            </table>
                        </div>
                         <div style="clear: both;"></div>
                        <dir-pagination-controls on-page-change="pageChanged(newPageNumber)"></dir-pagination-controls>
                    </div>
                    
                    <div ng-cloak ng-if="allListArray.length == 0" style="margin-top:10px; padding-bottom:30px; text-align: center; font-weight: bold;">
                        Nothing Found!
                    </div>
                
                </div>
            </div>
        </div>
        
    </div>
   
</div> <!-- content-wrapper end -->


     
<script>
(function(){

    angular.module("iwsApp").config(['$routeProvider', function($routeProvider) {
            $routeProvider. 
             
            when('banner.php', {
               templateUrl: 'banner.php',
               controller: 'bannerController'
            }).
            when('listbanner/:page', {
               templateUrl: 'banner.php',
               controller: 'bannerController'
            }).
            
            otherwise({
               redirectTo: 'banner.php'
            });
         }]);
         
     
    angular.module('iwsApp').controller('bannerController', ['$scope', '$http', '$httpParamSerializer', '$location', '$routeParams', 'myConfig', '$timeout', '$filter','$window','$q', 'Upload', function($scope, $http, $httpParamSerializer, $location, $routeParams, myConfig, $timeout, $filter,$window,$q, Upload){
         
        $scope.submitProcess = 0;
        $scope.submitProcessMsg = '';
        $scope.fullPageLoader = 0;
        $scope.successMsg = '';
        $scope.listPageLoader = 0;
        $scope.allListArray = {};
        $scope.dataFrm = {};
        $scope.dataFrm.status = true;
        $scope.cTitle = 'Add';
        $scope.totalItems = 0;
        $scope.itemsPerPage = '100'; // this should match however many results your API puts on one page

        $scope.pagination = {
                current: $routeParams.page
            };

             $scope.pageChanged = function(newPage) {
                
                
                $location.url("/listbanner/" + newPage);
                $scope.listData(newPage);
            };

        $scope.options = {
            toolbar:[
                ['Bold', 'Italic','Underline','Cut','Copy','Paste','Undo','Redo'], 
                ['JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock']
                
            ],
            language: 'en',
            allowedContent: true,
            entities: false,
            filebrowserBrowseUrl : 'ckfinder/ckfinder.html',
            filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',
            filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',
            filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
            filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
            filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
            
        };

        /////===============================================IMAGE UPLOAD STARTS=========================================================    
        $scope.fuploading = 0;
        // upload on file select or drop
        $scope.upload = function (file) {
            //validate file extension starts
          var file_name = file.name;
           
          var indexxx = file_name.lastIndexOf(".");
           var final_extension = file_name.substring(indexxx, file_name.length);
           if((final_extension == ".jpg") || (final_extension == ".png") ||  (final_extension == ".gif") ){
            console.log("valid File");
           }else{
            alert("Please Upload a valid File");
            return false;
           } 
           ///////validate files extension ends
            Upload.upload({
                url: 'upload.php',
                data: {file: file}
            }).then(function (resp) {
                if (resp.data.SUCCESS == "1") {
                    $scope.dataFrm.banner_image = resp.data.IMAGE_NAME;
                    $scope.dataFrm.banner_image_disp = resp.data.PATH_TO_IMAGE;
                    $scope.fuploading = 2;
                }
                else
                {
                    $scope.fileuploaderror = resp.data.MSG;
                    $scope.fuploading = 3;
    
                    $timeout(function(){
                        $scope.fuploading = 0;
                    }, 3000);
                }
    
                //console.log(resp.data.PATH_TO_IMAGE);
    
            }, function (resp) {
                console.log('Error status: ' + resp.status);
            }, function (evt) {
                var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                //console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
                $scope.fuploading = 1;
            });
        }
    //====================================================  image upload ENDS==========================================================
       
        
        $scope.submit = function() {
            //$scope.dataFrm
            $scope.submitProcess = 1;
            $scope.dataFrm.type = 'saveData';
            if ( ($scope.fuploading == '0') ) {
                $scope.submitProcess = 2;
                $scope.submitProcessMsg = 'Banner image is required.';
                $timeout(function(){
                    $scope.submitProcess = 0;
                    $scope.submitProcessMsg = '';
                  }, 3000);
                return false;
             }
            
            $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: $scope.dataFrm}).success(function(response){
                $scope.submitProcess = 2;

                if(response.SUCCESS == '1')
                {
                    $scope.submitProcessMsg = response.MSG;
                }
                else if(response.SUCCESS == '2')
                {
                    $scope.submitProcessMsg = response.MSG;
                }
                else
                {
                    $scope.submitProcessMsg = response.MSG;
                }

                $timeout(function(){
                    $scope.submitProcess = 0;
                    if(response.SUCCESS == '1') {
                        $scope.cTitle = 'Add';
                        $scope.openForm = 0;
                        $scope.listData(1);
                        
                        $scope.dataFrm = {};
                        $scope.dataFrm.status = true;
                        $scope.fuploading = 0;
                    }
                }, 1000);
            });

        };
        
        ////to remove image ================================================================
        $scope.removeImage = function(banner_id) {
        //event.preventDefault();
        var c = confirm("Are you sure you wish to remove?");
        if(c) {
            
               if(banner_id) {
                    // to delete from main folder
                    $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'removeImage', 'banner_id': banner_id, 'image_name': $scope.dataFrm.banner_image_disp }}).success(function(response){
                        
                        $scope.fuploading = 0;
                        $scope.dataFrm.banner_image = ''; 
                        $scope.dataFrm.banner_image_disp = ''; 
                        $scope.dataFrm.image_id = 0;
                    }); 
                } else {
                    // to delete from temp_folder
                    $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'removeImage', 'banner_id': $routeParams.banner_id, 'image_name': $scope.dataFrm.banner_image_disp }}).success(function(response){
                        
                        $scope.fuploading = 0;
                        $scope.dataFrm.banner_image = '';  
                        $scope.dataFrm.banner_image_disp = '';  
                    });
                }
            }
        };
        
        /////remove image ends ================================================================
        
        $scope.listData = function(page = 1) {
            $scope.listPageLoader = 1;
            $scope.allListArray = {};
            
            $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'listData', page: page}}).success(function(response){
                //console.log(response);
                $scope.allListArray = response.data;
                $scope.totalItems = response.total_records;
                $scope.listPageLoader = 0;
            });
        }; 
        
        $scope.listData();
        
        
        
        $scope.modifyData = function(banner_id) {
           
            $scope.openForm = 1;
            $scope.cTitle = 'Modify';
            $scope.fullPageLoader = 1;
            $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'getDetail', 'banner_id': banner_id}}).success(function(response){
                
                //console.log(response);
                
                $scope.dataFrm.banner_id = response.data[0].banner_id;
                $scope.dataFrm.banner_title = response.data[0].banner_title.replace(/\\/g,'');
                if(response.data[0].banner_image !='')
                {

                $scope.dataFrm.banner_image_disp = '../uploads_abtutorial/banner_image/'+response.data[0].banner_image.replace(/\\/g,'');
                $scope.fuploading = 2;
                }
                else{
                    $scope.dataFrm.banner_image_disp = '';
                    $scope.fuploading = 0;
                }
                
                $scope.dataFrm.image_id = response.data[0].image_id.replace(/\\/g,''); 
                
                $scope.fullPageLoader = 0;
            });
        };
        
        
        
        $scope.updateStatus = function(banner_id, current_status, $index) {
            //alert(banner_id + "===" + current_status + "===" + $index)
            //return false;
            
            if(parseInt(current_status) == parseInt(1))
            {
                current_status = 0;
            }  
            else
            {
                current_status = 1;
            }
            
            
            $scope.allListArray[$index].loading = true;
            
             
            //// update ajax here ========
            $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type:'updateStatus', 'banner_id': banner_id, 'status': current_status}}).success(function(response){
                //console.log(response);
                $scope.allListArray[$index].loading = false;
                $scope.allListArray[$index].status = current_status;
                   
                
            }); 
        };
        
        
         
        $scope.deleteData = function(banner_id) {
            var c = confirm("Are you sure you wish to delete?");
            if(c)
            {
                $scope.fullPageLoader = 1;
                
                
                $http({method: 'POST', url: '<?php echo PAGE_AJAX;?>', data: {type: 'deleteData', 'banner_id': banner_id}}).success(function(response){
                    $scope.successMsg = response.MSG;

                    $timeout(function(){
                        $scope.fullPageLoader = 0;
                        if(response.SUCCESS == '1')
                        {
                            
                            $scope.cTitle = 'Add';
                            $scope.openForm = 0;
                            $scope.listData();
                            
                            $scope.dataFrm = {};
                            $scope.dataFrm.status = true;
                            
                            $scope.listData();
                        }
                    }, 1000);
                });
            }
        };  
 
        /////////// POSITION =====================
        $scope.posLoader = false;
        $scope.goUp = function(indx,banner_id,position) {
            $scope.posLoader = true;
            var newIndx = parseInt(position) - parseInt(1);
            //alert(indx+"===="+newIndx);
            thirdObj = {};
            thirdObj.type="savePosition";
            thirdObj.banner_id=banner_id;
            thirdObj.banner_position=position;
            thirdObj.other_position = newIndx;

            $http({method: 'POST', url:'<?php echo PAGE_AJAX; ?>', data: thirdObj}).success(function(response){
                //console.log(response);
                $scope.posLoader = false;
                $scope.listData();
            });

        };

        $scope.goDown = function(indx,banner_id,position) {
            $scope.posLoader = true;
            var newIndx = parseInt(position) + parseInt(1);
            //alert(indx+"===="+newIndx);
            thirdObj = {};
            thirdObj.type="savePosition";
            thirdObj.banner_id=banner_id;
            thirdObj.banner_position=position;
            thirdObj.other_position = newIndx;
       
            $http({method: 'POST', url:'<?php echo PAGE_AJAX;?>', data: thirdObj}).success(function(response){
                //console.log(response);
                $scope.posLoader = false;
                $scope.listData();
            });

        };
          
    }]); 
   
    
})();
</script>
<?php
include("footer.php");
?>