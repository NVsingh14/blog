<?php 
session_start();
error_reporting(0);
include("config-cms.php");
include("../library/class.imageresizer.php");

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);
$type;

switch($type)
{
         case "removeImage":
            removeImage();
        break;

		case "saveData":
				saveData();
				break;
		case "listData":
			listData();
			break;
		case "getDetail" :
			getDetail();
			break;
		case "CancelGallery":
			CancelGallery();
			break;
		case "deleteData":
			deleteData();
			break;
		case "deleteAllData":
			deleteAllData();
			break;
		case "updateDisplayWebsite":
			updateDisplayWebsite();
			break;
        case "savePosition":
            savePosition();
            break;
        case "updateStatus":
            updateStatus();
            break;
}
        
        function removeImage()
        {
            global $dCON, $REQData;
            
            $image_name = trustme($REQData->image_name);
            $imageId = intval($REQData->banner_id);
            $FOLDER_NAME = FLD_BANNER_IMAGE;
          // echo " === " . $image_name . " === " . $imageId . " ====== " . $FOLDER_NAME;
          // exit();
            if($imageId == intval(0))
            {
                
                //delete image
                if(unlink($image_name)) 
                {
                    //deleteIMG("GALLERY",$image_name,CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD );
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete Image";
                }
            }
            else
            {
                if(unlink($image_name)) 
                {
                    $img_array = explode("/", $image_name);
                    $IMG =  $img_array[3];
                    
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R500-" . $IMG );
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R50-" . $IMG );
                                
                    $SQL = "";
                    $SQL .= "UPDATE " . BANNER_TBL . " SET " ;
                    $SQL .= " banner_image = :banner_image, ";
                    $SQL .= " image_id = :image_id ";
                    $SQL .= " WHERE banner_id = :banner_id ";
                    //echo "$SQL---$img---$img_id-----$imageId" ;
                    
                    $banner_image = "";
                    $img_id = intval(0);            
                         
                    $stk_upd = $dCON->prepare($SQL);
                    $stk_upd->bindParam(":banner_image", $banner_image);
                    $stk_upd->bindParam(":image_id", $img_id);
                    $stk_upd->bindParam(":banner_id", $imageId);
                    $stk_upd->execute();
                    
                    $stk_upd->closeCursor();
                     
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete Image";
                }
                
            } 
        }

		
		function saveData()
		{
			global $dCON, $REQData;
			$IP = $_SERVER['REMOTE_ADDR'];
			$TIME = date("Y-m-d H:i:s");
			$banner_title = trustyou($REQData->banner_title);
			$banner_id=intval($REQData->banner_id);
            $banner_image = trustme($REQData->banner_image); 
            $banner_image_got = trustme($REQData->banner_image_disp);
            
            $image_id = trustme($REQData->image_id);
            $status = intval(1);
            $TEMP_FOLDER_NAME = "";
            $TEMP_FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD . "/";
            
            if( !is_dir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_BANNER_IMAGE))
            {
                $mask=umask(0);
                mkdir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_BANNER_IMAGE, 0777);
                umask($mask);
            }  
            
            $FOLDER_NAME = "";
            $FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH .FLD_BANNER_IMAGE. "/";
            
           
			if(intval($banner_id)==intval(0))
			{

			 $MAXID = getMaxId(BANNER_TBL,"banner_id");
             $MAX_POS=getMaxPosition(BANNER_TBL,"position");
             //echo $MAX_POS;exit;
                //==============FOR IMAGE
                
                
                if( trim($banner_image) != "")
                {
                    $f_ext = pathinfo($banner_image);
                    $fNAM = $MAXID."-".$f_ext['filename'];
                    $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                    rename($TEMP_FOLDER_NAME.$banner_image, $FOLDER_NAME.$IMG);
                    resizeIMG("GALLERY",trim($IMG),$MAXID,$FOLDER_NAME);
                    
                    $image_id = intval(1);
                    
                }
                else
                {
                    $IMG = "";
                    $image_id = intval(0);
                }   
                
                /////FOR IMAGE ENDS

				$SQL = "";
				$SQL .= " INSERT INTO " . BANNER_TBL . " SET ";
				$SQL .= " banner_id=:banner_id, ";
				$SQL .= " banner_image=:banner_image, ";
                $SQL .= " banner_title=:banner_title, ";
                $SQL .= " image_id=:image_id, ";
                $SQL .= " status=:status, ";
                $SQL .= " position=:position, ";
				$SQL .= " add_ip=:add_ip, ";
				$SQL .= " add_by=:add_by, ";
				$SQL .= " add_time=:add_time ";

				$stmt = $dCON->prepare( $SQL );
				$stmt->bindParam(":banner_id", $MAXID); 
                $stmt->bindParam(":banner_image",$IMG); 
                $stmt->bindParam(":banner_title",$banner_title);
                $stmt->bindParam(":image_id",$image_id); 
                $stmt->bindParam(":status",$status);
                $stmt->bindParam(":position",$MAX_POS); 
				$stmt->bindParam(":add_ip", $IP);
				$stmt->bindParam(":add_by", $_SESSION['USERNAME']);
				$stmt->bindParam(":add_time", $TIME);
				$rs = $stmt->execute();
				$stmt->closeCursor();
			}
			else if(intval($banner_id) > intval(0) )
			{
			
                if(intval($image_id) == intval(0))
                    {
                        
                        if( trim($banner_image) != "")
                        {
                            $f_ext = pathinfo($banner_image);
                            $fNAM = $banner_id."-"."IMAGE";
                            
                            $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                             
                            rename($TEMP_FOLDER_NAME.$banner_image, $FOLDER_NAME.$IMG);
                            resizeIMG("GALLERY",trim($IMG),$MAXID,$FOLDER_NAME);
                            
                            $image_id = intval(1);
                            
                        }
                        else
                        {
                            $IMG = "";
                            $image_id = intval(0);
                        }
                        
                    }
                    else
                    {
                         
                        if($banner_image_got != "")
                        {     
                            $img_array = explode("/", $banner_image_got);
                            
                            $IMG =  $img_array[3];
                            $image_id = intval(1);
                        }
                        else
                        {
                            $IMG = "";
                            $image_id = intval(0);
                        }
                        
                    }
                    
                    
                    
                        
    				$SQL= "";
    				$SQL .= "UPDATE " . BANNER_TBL . " SET ";
                    $SQL .= " banner_image=:banner_image, ";
                    $SQL .= " banner_title=:banner_title, ";
                    $SQL .= " image_id=:image_id, ";
                    $SQL .= " status=:status, ";
    				$SQL .= " update_ip=:update_ip, ";
    				$SQL .= " update_by = :update_by, ";
    				$SQL .= " update_time=:update_time ";
    				$SQL .= " WHERE banner_id=:banner_id ";
    				
    				$stmt = $dCON->prepare( $SQL );  
                    $stmt->bindParam(":banner_image",$IMG); 
                    $stmt->bindParam(":banner_title",$banner_title);
                    $stmt->bindParam(":image_id",$image_id); 
                    $stmt->bindParam(":status",$status); 
    				$stmt->bindParam(":update_ip", $IP);
    				$stmt->bindParam(":update_by", $_SESSION['USERNAME']);
    				$stmt->bindParam(":update_time", $TIME);
    				$stmt->bindParam(":banner_id",$banner_id);

    				$rs = $stmt->execute();
    				$stmt->closeCursor();

			}

			else 
			{
				$rs=2;
			}
		$RETURN_ARRAY = array();
			 switch($rs)
			{
				case "1":
						$RETURN_ARRAY['SUCCESS'] = 1;
						$RETURN_ARRAY['MSG'] = "&#x2714; Successfully saved.";
						
						break;
				case "2":
						
						$RETURN_ARRAY['SUCCESS'] = 2;
						$RETURN_ARRAY['MSG'] = "&#x2757; Already Exists.";
						break; 
				default:
						$RETURN_ARRAY['SUCCESS'] = 0;
						$RETURN_ARRAY['MSG'] = "&#x2718; Sorry cannot process your request.";
						break;
			}

			echo json_encode($RETURN_ARRAY);

		}



function listData()
{
        
    global $dCON, $REQData;
    $page = intval($REQData->page) == 0 ? 1 : $REQData->page;
    
    $searchArr = array();
    
    $RETURN_ARRAY = array();
    $RETURN_ARRAY['searchedFields'] = array();
    
    $search = "";
    
    $SQL = "";
    $SQL .= " SELECT * ";
    $SQL .= " FROM " . BANNER_TBL . " AS B ";
    $SQL .= " WHERE B.status <> '2' AND image_id <> '0' ";
    $SQL .= " $search ";
    $SQL .= " ORDER BY position ASC ";
    //echo $SQL;
    
    $SQL_COUNT  = "";
    $SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
        $SQL_COUNT .= $SQL;
    $SQL_COUNT .= " ) as aa ";
    
    
    $stmtCnt =  $dCON->prepare($SQL_COUNT);
    $stmtCnt->execute($searchArr);
    $noOfRecords_row = $stmtCnt->fetchObject();
    $stmtCnt->closeCursor();
    $noOfRecords = intval($noOfRecords_row->CT);

    $rowsPerPage = 100;

    $page = intval($page) - 1;
    $offset = $rowsPerPage * $page ;

    $SQL .= " LIMIT " . $offset . "," . $rowsPerPage;

    $stmt = $dCON->prepare($SQL);
    $stmt->execute($searchArr);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    
    $RETURN_ARRAY['data'] = $row;
    $RETURN_ARRAY['total_records'] = $noOfRecords;
    
    echo json_encode($RETURN_ARRAY);    
          
}



function getDetail()
{
		global $dCON,$REQData;

		$banner_id = intval($REQData->banner_id);

		$SQL= "";
		$SQL .= " SELECT T.* ";
		$SQL .= " FROM ". BANNER_TBL . " AS T ";
		$SQL .= " WHERE T.banner_id=:banner_id ";

		$stmt = $dCON->prepare( $SQL );
		$stmt->bindParam(":banner_id", $banner_id);
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();
		

		$RETURN_DATA = array();
		$RETURN_DATA['data'] = $row;
        
		echo json_encode($RETURN_DATA); 
}


function deleteData()
{
    global $dCON, $REQData;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    $banner_id = intval($REQData->banner_id);
    
    $STR  = "";
    $STR .= " UPDATE  " . BANNER_TBL . "  SET "; 
    $STR .= " status = '2', ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE banner_id = :banner_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":banner_id", intval($banner_id));
    $dRES = $sDEF->execute();
    $sDEF->closeCursor();   
    
    if(intval($dRES) > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }
    
    echo json_encode($RETURN_ARR);
}

function deleteAllData()
{
    global $dCON, $REQData;
    
    $indexIdsArray = $REQData->DIDS;
    $successCTR = 0;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    
    foreach($indexIdsArray as $indexIdObj)
    {
       $stmtDel = $dCON->prepare(" UPDATE " .BANNER_TBL . " SET `status` = '2',update_ip =:update_ip,update_by = :update_by, update_time = :update_time  WHERE banner_id = :banner_id ");
        $stmtDel->bindParam(":update_ip", $IP);
        $stmtDel->bindParam(":update_by", $_SESSION['USERNAME']);
        $stmtDel->bindParam(":update_time", $TIME);
        $stmtDel->bindParam(":banner_id", $indexIdObj->banner_id);
        $dRES = $stmtDel->execute();
        $stmtDel->closeCursor();

       
    }

    if($dRES > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }

    echo json_encode($RETURN_ARR);


}


function updateDisplayWebsite()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->banner_id);
    $VAL = trustme($REQData->display_on_home);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . BANNER_TBL . "  SET "; 
    $STR .= " display_on_home = :display_on_home, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE banner_id = :banner_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":display_on_home", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":banner_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}


function savePosition()
{
    global $dCON, $REQData;

    $ID = intval($REQData->banner_id);
    $banner_position = trustme($REQData->banner_position);
    $other_position = trustme($REQData->other_position);
     
    $POS_SQL="SELECT banner_id FROM " . BANNER_TBL . " WHERE position='".$banner_position."' ";
    $POS_STMT = $dCON->prepare($POS_SQL);
    $POS_STMT->execute();
    $POSITION = $POS_STMT->fetchAll(PDO::FETCH_ASSOC);

    $POS_STMT->closeCursor();

    $POS_SQL = " SELECT banner_id FROM " . BANNER_TBL . " WHERE position='".$other_position."' ";
    $OTH_STMT = $dCON->prepare($POS_SQL);
    $OTH_STMT->execute();
    $OTH_POS = $OTH_STMT->fetchAll(PDO::FETCH_ASSOC);

    $OTH_STMT->closeCursor(); 
    $posid = $POSITION[0]['banner_id'];
    $other = $OTH_POS[0]['banner_id'];


    $STR  = " UPDATE  " . BANNER_TBL . "  SET position ='".$other_position."' WHERE banner_id ='".$posid."' ";
    $upPOS = $dCON->prepare($STR); 
    $RES_POS = $upPOS->execute();
    $upPOS->closeCursor();

    $STR  = " UPDATE  " . BANNER_TBL . "  SET position ='".$banner_position."' WHERE banner_id ='".$other."' ";
    $upOTH = $dCON->prepare($STR); 
    $RES_OTH = $upOTH->execute();
    $upOTH->closeCursor();


if(intval($RES_POS) == intval(1) && intval($RES_OTH) == intval(1) )
{
    $RES=1;
}
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}
	
function updateStatus()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->banner_id);
    $VAL = trustme($REQData->status);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . BANNER_TBL . "  SET "; 
    $STR .= " status = :status, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE banner_id = :banner_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":status", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":banner_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}   		 

?>

