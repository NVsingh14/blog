<?php  
error_reporting(0);
include("config-cms.php");

$type =  trustme($_REQUEST['type']);


switch($type)
{
    case "saveListPosition":
        saveListPosition();
        break;
    case "saveListPositionHImg":
        saveListPositionHImg();
        break;   
    case "saveListPositionTwoImg":
        saveListPositionTwoImg();
        break;   
}


function saveListPosition()
{
    global $dCON;
    $tbl = trustme($_REQUEST['con']);
    $cname1 = trustme($_REQUEST['cname1']);
    $cname2 = trustme($_REQUEST['cname2']);
    $feature_position = trustme($_REQUEST['feature_position']);
    $condition_param = $_REQUEST['condition_param'];
    
    //echo "==".$_POST['listItem'];
    foreach ($_POST['listItem'] as $position => $item) 
    {
          
         
        $SQL  = "";
        $SQL .= " UPDATE " . $tbl ;
    
        if ($feature_position =='YES')
        {
            $SQL .= " SET position_feature = :position ";
        }
        else
        {
            $SQL .= " SET position = :position ";
        }
        
        $SQL .= " WHERE  $cname2 = :$cname2 ";    
        
        if(trim($condition_param)!="")
        {
            
            $condition_array = explode("~~~", $condition_param);
          
            foreach($condition_array as $col_condition)
            {
                
                $condition_value_array = explode("^^^", $col_condition);
                $column_name = trim($condition_value_array[0]);            
                $column_operator = trim($condition_value_array[1]);            
                $column_value = trim($condition_value_array[2]); 
                
                if($column_value !="")
                {
                    $SQL .= " AND " . $column_name . " " . $column_operator . " :$column_name ";
                    
                }
                 
            }       
            
        }
          
        //echo $SQL . $position ."--".;
       //exit();
        
        $stmt = $dCON->prepare( $SQL );
        $stmt->bindParam(":position", $position);
        $stmt->bindParam(":" . $cname2, $item); 
        
        if(trim($condition_param)!="")
        {
            
            $condition_array = explode("~~~", $condition_param);
          
            foreach($condition_array as $col_condition)
            {
                
                $condition_value_array = explode("^^^", $col_condition);
                $column_name = trim($condition_value_array[0]);            
                $column_operator = trim($condition_value_array[1]);            
                $column_value = trim($condition_value_array[2]); 
                           
                if($column_value !="")
                {
                    $stmt->bindParam(":" . $column_name, $column_value); 
                }
                       
            }       
            
        }
        
        $rs = $stmt->execute(); 
    }
    
    echo "- Position successfully saved";
}



function saveListPositionHImg()
{
    global $dCON;
    $tbl = trustme($_REQUEST['con']);
    $cname1 = trustme($_REQUEST['cname1']);
    $cname2 = trustme($_REQUEST['cname2']);
    $feature_position = trustme($_REQUEST['feature_position']);
    $condition_param = $_REQUEST['condition_param'];
    
    //echo "==".$_POST['listItemH'];
    foreach ($_POST['listItemH'] as $position => $item) 
    {
          
         
        $SQL  = "";
        $SQL .= " UPDATE " . $tbl ;
    
        if ($feature_position =='YES')
        {
            $SQL .= " SET position_feature = :position ";
        }
        else
        {
            $SQL .= " SET position = :position ";
        }
        
        $SQL .= " WHERE  $cname2 = :$cname2 ";    
        
        if(trim($condition_param)!="")
        {
            
            $condition_array = explode("~~~", $condition_param);
          
            foreach($condition_array as $col_condition)
            {
                
                $condition_value_array = explode("^^^", $col_condition);
                $column_name = trim($condition_value_array[0]);            
                $column_operator = trim($condition_value_array[1]);            
                $column_value = trim($condition_value_array[2]); 
                
                if($column_value !="")
                {
                    $SQL .= " AND " . $column_name . " " . $column_operator . " :$column_name ";
                    
                }
                 
            }       
            
        }
          
        //echo $SQL . $position ."--".;
       //exit();
        
        $stmt = $dCON->prepare( $SQL );
        $stmt->bindParam(":position", $position);
        $stmt->bindParam(":" . $cname2, $item); 
        
        if(trim($condition_param)!="")
        {
            
            $condition_array = explode("~~~", $condition_param);
          
            foreach($condition_array as $col_condition)
            {
                
                $condition_value_array = explode("^^^", $col_condition);
                $column_name = trim($condition_value_array[0]);            
                $column_operator = trim($condition_value_array[1]);            
                $column_value = trim($condition_value_array[2]); 
                           
                if($column_value !="")
                {
                    $stmt->bindParam(":" . $column_name, $column_value); 
                }
                       
            }       
            
        }
        
        $rs = $stmt->execute(); 
    }
    
    echo "- Position successfully saved";
}


function saveListPositionTwoImg()
{
    global $dCON;
    $tbl = trustme($_REQUEST['con']);
    $cname1 = trustme($_REQUEST['cname1']);
    $cname2 = trustme($_REQUEST['cname2']);
    $position_home_page = trustme($_REQUEST['position_home_page']);
    $condition_param = $_REQUEST['condition_param'];
    
    //echo "==".$_POST['listImgTwo'];
    foreach ($_POST['listImgTwo'] as $position => $item) 
    {
          
         
        $SQL  = "";
        $SQL .= " UPDATE " . $tbl ;
    
        if ($position_home_page =='YES')
        {
            $SQL .= " SET position_home_page = :position ";
        }
        else
        {
            $SQL .= " SET position = :position ";
        }
        
        $SQL .= " WHERE  $cname2 = :$cname2 ";    
        
        if(trim($condition_param)!="")
        {
            
            $condition_array = explode("~~~", $condition_param);
          
            foreach($condition_array as $col_condition)
            {
                
                $condition_value_array = explode("^^^", $col_condition);
                $column_name = trim($condition_value_array[0]);            
                $column_operator = trim($condition_value_array[1]);            
                $column_value = trim($condition_value_array[2]); 
                
                if($column_value !="")
                {
                    $SQL .= " AND " . $column_name . " " . $column_operator . " :$column_name ";
                    
                }
                 
            }       
            
        }
          
        //echo $SQL . $position ."--".;
       //exit();
        
        $stmt = $dCON->prepare( $SQL );
        $stmt->bindParam(":position", $position);
        $stmt->bindParam(":" . $cname2, $item); 
        
        if(trim($condition_param)!="")
        {
            
            $condition_array = explode("~~~", $condition_param);
          
            foreach($condition_array as $col_condition)
            {
                
                $condition_value_array = explode("^^^", $col_condition);
                $column_name = trim($condition_value_array[0]);            
                $column_operator = trim($condition_value_array[1]);            
                $column_value = trim($condition_value_array[2]); 
                           
                if($column_value !="")
                {
                    $stmt->bindParam(":" . $column_name, $column_value); 
                }
                       
            }       
            
        }
        
        $rs = $stmt->execute(); 
    }
    
    echo "- Position successfully saved";
}

