<?php 
session_start();
error_reporting(0);
include("config-cms.php");

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);
switch($type)
{
    case "changepassword":
        changepassword();
        break;
}

//Modify Data
function changepassword()
{
    global $dCON, $REQData;
    
    $newpass = trustme( $REQData->admin_password);
	

    $SQL = "";
    $SQL = " UPDATE " . ADMIN_TBL . " SET user_password  = ? where user_id = ? ";
        
    
    $stm = $dCON->prepare($SQL);
	$stm->bindParam(1, $newpass);
	$stm->bindParam(2, $_SESSION['UID_ABTUTORIAL']);
	$rs = $stm->execute();
    
    $RETURN_ARRAY = array();
    
    switch($rs)
	{
		case "1": 
            /*
            $QRY = "";
            $QRY .= " UPDATE  " . USER_TBL . " SET ";
            $QRY .= " user_password = AES_ENCRYPT(password, '" . CONSTANT_PASSWORD_KEY . "' ) ";
            $QRY .= " WHERE user_id =  :user_id ";
            //echo $QRY;
            
            $sUPD = $dCON->prepare( $QRY );
            $sUPD->bindParam(":user_id", $_SESSION['UID_CIIAPP']); 
            $sUPD->execute();
            $sUPD->closeCursor();
            */
            
            $RETURN_ARRAY['SUCCESS'] = 1;
            $RETURN_ARRAY['MSG'] = "Password successfully changed...";
            //echo "~~~1~~~Password successfully changed...~~~";
            break;
            
		default:
            $RETURN_ARRAY['SUCCESS'] = 0;
            $RETURN_ARRAY['MSG'] = "Sorry cannot process your request...";
            //echo "~~~0~~~Sorry cannot process your request...~~~";
            break;
	}
    
    echo json_encode($RETURN_ARRAY);
}
?>


