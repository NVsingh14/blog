<?php 
session_start();
error_reporting(0);
include("config-cms.php");
include("../library/class.imageresizer.php");

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);
$type;

switch($type)
{
         case "removeImage":
            removeImage();
        break;

		case "saveNewsDetail":
				saveNewsDetail();
				break;
		case "list_news":
			list_news();
			break;
		case "getNewsDetail" :
			getNewsDetail();
			break;
		case "CancelNews":
			CancelNews();
			break;
		case "deleteData":
			deleteData();
			break;
		case "deleteAllData":
			deleteAllData();
			break;
		case "updateDisplayWebsite":
			updateDisplayWebsite();
			break;
        case "updateStatus":
			updateStatus();
			break;
}
        
        function removeImage()
        {
            global $dCON, $REQData;
            
            $image_name = trustme($REQData->image_name);
            $imageId = intval($REQData->news_id);
            $FOLDER_NAME = FLD_NEWS;
           
            if($imageId == intval(0))
            {
               echo " i id 0000";
               exit();
                //delete image
                if(unlink($image_name)) 
                {
                    //deleteIMG("GALLERY",$image_name,CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD );
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete Image";
                }
            }
            else
            {
                if(unlink($image_name)) 
                {
                    $img_array = explode("/", $image_name);
                    $IMG =  $img_array[3];
                    
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R500-" . $IMG );
                    unlink(CMS_UPLOAD_FOLDER_RELATIVE_PATH . $FOLDER_NAME."/R50-" . $IMG );
                                
                    $SQL = "";
                    $SQL .= "UPDATE " . NEWS_TBL . " SET " ;
                    $SQL .= " news_image = :news_image, ";
                    $SQL .= " image_id = :image_id ";
                    $SQL .= " WHERE news_id = :news_id ";
                    
                    
                    $news_image = "";
                    $img_id = intval(0);            
                    
                    $stk_upd = $dCON->prepare($SQL);
                    $stk_upd->bindParam(":news_image", $news_image);
                    $stk_upd->bindParam(":image_id", $img_id);
                    $stk_upd->bindParam(":news_id", $imageId);
                    $stk_upd->execute();
                    
                    $stk_upd->closeCursor();
                     
                    echo "1~~~Deleted";
                } 
                else 
                {
                    echo "0~~~Sorry Cannot Delete Image";
                }
                
            } 
        }

		
		function saveNewsDetail()
		{
			global $dCON, $REQData;

			$IP = $_SERVER['REMOTE_ADDR'];
			$TIME = date("Y-m-d H:i:s");
			$name = trustme($REQData->name);
			$title = trustme($REQData->title);
			$description = trustyou($REQData->description);
			$news_id=intval($REQData->news_id);
            $external_link = trustme($REQData->external_link); 
            $start_date = trustme($REQData->start_date); 
            
            $start_date_array = explode("-", $start_date);
            $start_date = $start_date_array[2] . "-" . $start_date_array[1] . "-" . $start_date_array[0];
            
            $end_date = trustme($REQData->end_date);
            $end_date_array = explode("-", $end_date);
            $end_date = $end_date_array[2] . "-" . $end_date_array[1] . "-" . $end_date_array[0]; 
            
            $news_image = trustme($REQData->news_img); 
            $news_image_got = trustme($REQData->news_image_disp);
            
            $image_id = trustme($REQData->image_id);
            
            $TEMP_FOLDER_NAME = "";
            $TEMP_FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH . TEMP_UPLOAD . "/";
            
            if( !is_dir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_NEWS))
            {
                $mask=umask(0);
                mkdir(CMS_UPLOAD_FOLDER_RELATIVE_PATH . "/" . FLD_NEWS, 0777);
                umask($mask);
            }  
            
            $FOLDER_NAME = "";
            $FOLDER_NAME = CMS_UPLOAD_FOLDER_RELATIVE_PATH .FLD_NEWS. "/";
            
            
			if(intval($news_id)==intval(0))
			{

			 $MAXID = getMaxId(NEWS_TBL,"news_id");
             
                //==============FOR IMAGE
                
                
                if( trim($news_image) != "")
                {
                    $f_ext = pathinfo($news_image);
                    $fNAM = $MAXID."-".filterString($title);
                    $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                    rename($TEMP_FOLDER_NAME.$news_image, $FOLDER_NAME.$IMG);
                    resizeIMG("NEWS",trim($IMG),$MAXID,$FOLDER_NAME);
                    
                    $image_id = intval(1);
                    
                }
                else
                {
                    $IMG = "";
                    $image_id = intval(0);
                }   
                
                /////FOR IMAGE ENDS

				$SQL = "";
				$SQL .= " INSERT INTO " . NEWS_TBL . " SET ";
				$SQL .= " news_id=:news_id, ";
				$SQL .= " news_ref=:news_ref,";
				$SQL .= " news_title=:title, ";
                $SQL .= " external_link=:external_link, ";
                $SQL .= " start_date=:start_date, ";
                $SQL .= " end_date=:end_date, ";
                $SQL .= " news_description=:description, ";
				$SQL .= " news_image=:news_image, ";
                $SQL .= " image_id=:image_id, ";
				$SQL .= " add_ip=:add_ip, ";
				$SQL .= " add_by=:add_by, ";
				$SQL .= " add_time=:add_time ";

				$stmt = $dCON->prepare( $SQL );
				$stmt->bindParam(":news_id", $MAXID);  
				$stmt->bindParam(":news_ref",$name);
				$stmt->bindParam(":title",$title); 
                $stmt->bindParam(":external_link",$external_link);
                $stmt->bindParam(":start_date",$start_date);
                $stmt->bindParam(":end_date",$end_date);
				$stmt->bindParam(":description",$description); 
                $stmt->bindParam(":news_image",$IMG); 
                $stmt->bindParam(":image_id",$image_id); 
				$stmt->bindParam(":add_ip", $IP);
				$stmt->bindParam(":add_by", $_SESSION['USERNAME']);
				$stmt->bindParam(":add_time", $TIME);
				$rs = $stmt->execute();
				$stmt->closeCursor();
			}
			else if(intval($news_id) > intval(0) )
			{
			
                if(intval($image_id) == intval(0))
                    {
                        if( trim($news_image) != "")
                        {
                            
                            $f_ext = pathinfo($news_image);
                            $fNAM = $news_id."-".filterString($title);
                            
                            $IMG =  strtolower($fNAM) . "." . $f_ext['extension'];
                            
                            rename($TEMP_FOLDER_NAME.$news_image, $FOLDER_NAME.$IMG);
                            resizeIMG("NEWS",trim($IMG),$news_id,$FOLDER_NAME);
                            
                            $image_id = intval(1);
                            
                        }
                        else
                        {
                            $IMG = "";
                            $image_id = intval(0);
                        }
                         
                    }
                    else
                    {
                        if($news_image_got != "")
                        {     
                            $img_array = explode("/", $news_image_got);
                            
                            $IMG =  $img_array[3];
                            $image_id = intval(1);
                        }
                        else
                        {
                            $IMG = "";
                            $image_id = intval(0);
                        }
                        
                    }
                    
                    
				$SQL= "";
				$SQL .= "UPDATE " . NEWS_TBL . " SET ";
				$SQL .= " news_ref=:news_ref,";
				$SQL .= " news_title=:title, ";
                $SQL .= " external_link=:external_link, ";
				$SQL .= " news_description=:description, ";
                $SQL .= " start_date=:start_date, ";
                $SQL .= " end_date=:end_date, ";
                $SQL .= " news_image=:news_image, ";
                $SQL .= " image_id=:image_id, ";
				$SQL .= " update_ip=:update_ip, ";
				$SQL .= " update_by = :update_by, ";
				$SQL .= " update_time=:update_time ";
				$SQL .= " WHERE news_id=:news_id ";
				
				$stmt = $dCON->prepare( $SQL ); 
				$stmt->bindParam(":news_ref",$name);
				$stmt->bindParam(":title",$title);  
                $stmt->bindParam(":external_link",$external_link);
				$stmt->bindParam(":description",$description); 
                $stmt->bindParam(":start_date",$start_date); 
                $stmt->bindParam(":end_date",$end_date); 
                $stmt->bindParam(":news_image",$IMG); 
                $stmt->bindParam(":image_id",$image_id); 
				$stmt->bindParam(":update_ip", $IP);
				$stmt->bindParam(":update_by", $_SESSION['USERNAME']);
				$stmt->bindParam(":update_time", $TIME);
				$stmt->bindParam(":news_id",$news_id);

				$rs = $stmt->execute();
				$stmt->closeCursor();

			}

			else 
			{
				$rs=2;
			}
		$RETURN_ARRAY = array();
			 switch($rs)
			{
				case "1":
						$RETURN_ARRAY['SUCCESS'] = 1;
						$RETURN_ARRAY['MSG'] = "&#x2714; Successfully saved.";
						
						break;
				case "2":
						
						$RETURN_ARRAY['SUCCESS'] = 2;
						$RETURN_ARRAY['MSG'] = "&#x2757; Already Exists.";
						break; 
				default:
						$RETURN_ARRAY['SUCCESS'] = 0;
						$RETURN_ARRAY['MSG'] = "&#x2718; Sorry cannot process your request.";
						break;
			}

			echo json_encode($RETURN_ARRAY);

		}



function list_news()
{
        
    global $dCON, $REQData;
    $page = intval($REQData->page) == 0 ? 1 : $REQData->page;
    
    $title = trustme($REQData->search_news_title);
    $search_start_date_occured = trustme($REQData->search_start_date);
    $search_end_date_occured = trustme($REQData->search_end_date);
    $search_start_date = trustme($REQData->search_start_date);
    $search_start_date_array = explode("-", $search_start_date);
    $search_start_date = $search_start_date_array[2] . "-" . $search_start_date_array[1] . "-" . $search_start_date_array[0];
     
    $search_end_date = trustme($REQData->search_end_date);
    $search_end_date_array = explode("-", $search_end_date);
    $search_end_date = $search_end_date_array[2] . "-" . $search_end_date_array[1] . "-" . $search_end_date_array[0];
    
    if($search_end_date_occured == "")
    {
        $search_end_date = $search_start_date;
    }
    $search_name = trustme($REQData->search_news_ref);
    
    $searchArr = array();
    
    $RETURN_ARRAY = array();
    $RETURN_ARRAY['searchedFields'] = array();
    
    $search = "";
    if( trim($title) != "" )
    {
        $search .= " AND B.news_title LIKE '%".$title."%' ";
      
        $RETURN_ARRAY['searchedFields'][] = $title;
    }
    
    if( $search_start_date_occured != "" )
    {
        $search .= " AND B.start_date BETWEEN '".$search_start_date."' AND '".$search_end_date."' ";
        $searched_date = "";
        $searched_date .= $search_start_date_occured;
        if($search_end_date_occured != ""){
            $searched_date .= ", " .$search_end_date_occured;
        }
        $RETURN_ARRAY['searchedFields'][] = $searched_date;
    }
    
    if( trim($search_name) != "" )
    {
        $search .= " AND B.news_ref LIKE '%".$search_name."%' ";
        $RETURN_ARRAY['searchedFields'][] = $search_name;
    }
    
    $SQL = "";
    $SQL .= " SELECT B.*, DATE_FORMAT(start_date,'%d %b, %Y') AS startING_date ";
    $SQL .= ",(CASE WHEN news_image <> '' THEN CONCAT ('" . CMS_UPLOAD_FOLDER_RELATIVE_PATH . FLD_NEWS . "/R50-" . "', B.news_image) ELSE '' END ) as news_image_disp ";
    $SQL .= " FROM " . NEWS_TBL . " AS B ";
    $SQL .= " WHERE B.status <> '2' ";
    $SQL .= " $search ";
    $SQL .= " ORDER BY B.start_date DESC ";
    //echo $SQL;
    
    $SQL_COUNT  = "";
    $SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
        $SQL_COUNT .= $SQL;
    $SQL_COUNT .= " ) as aa ";
    
    
    $stmtCnt =  $dCON->prepare($SQL_COUNT);
    $stmtCnt->execute($searchArr);
    $noOfRecords_row = $stmtCnt->fetchObject();
    $stmtCnt->closeCursor();
    $noOfRecords = intval($noOfRecords_row->CT);
    
    $rowsPerPage = 25;

    $page = intval($page) - 1;
    $offset = $rowsPerPage * $page ;

    $SQL .= " LIMIT " . $offset . "," . $rowsPerPage;

    $stmt = $dCON->prepare($SQL);
    $stmt->execute($searchArr);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    
    $RETURN_ARRAY['data'] = $row;
    $RETURN_ARRAY['total_records'] = $noOfRecords;
    
    echo json_encode($RETURN_ARRAY);    
          
}



function getNewsDetail()
{
		global $dCON,$REQData;

		$news_id = intval($REQData->news_id);

		$SQL= "";
		$SQL .= " SELECT T.*,  DATE_FORMAT(start_date,'%d-%m-%Y') AS start_date,  DATE_FORMAT(end_date,'%d-%m-%Y') AS end_date ";
		$SQL .= " FROM ". NEWS_TBL . " AS T ";
		$SQL .= " WHERE T.news_id=:news_id ";

		$stmt = $dCON->prepare( $SQL );
		$stmt->bindParam(":news_id", $news_id);
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();
		

		$RETURN_DATA = array();
		$RETURN_DATA['data'] = $row;
        
		echo json_encode($RETURN_DATA); 
}


function deleteData()
{
    global $dCON, $REQData;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    $news_id = intval($REQData->news_id);
    
    $STR  = "";
    $STR .= " UPDATE  " . NEWS_TBL . "  SET "; 
    $STR .= " status = '2', ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE news_id = :news_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":news_id", intval($news_id));
    $dRES = $sDEF->execute();
    $sDEF->closeCursor();   
    
    if(intval($dRES) > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }
    
    echo json_encode($RETURN_ARR);
}

function deleteAllData()
{
    global $dCON, $REQData;
    
    $indexIdsArray = $REQData->DIDS;
    $successCTR = 0;
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
    
    
    foreach($indexIdsArray as $indexIdObj)
    {
       $stmtDel = $dCON->prepare(" UPDATE " .NEWS_TBL . " SET `status` = '2',update_ip =:update_ip,update_by = :update_by, update_time = :update_time  WHERE news_id = :news_id ");
        $stmtDel->bindParam(":update_ip", $IP);
        $stmtDel->bindParam(":update_by", $_SESSION['USERNAME']);
        $stmtDel->bindParam(":update_time", $TIME);
        $stmtDel->bindParam(":news_id", $indexIdObj->news_id);
        $dRES = $stmtDel->execute();
        $stmtDel->closeCursor();

       
    }

    if($dRES > 0)
    {
        $RETURN_ARR = array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
    }
    else
    {
        $RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
    }

    echo json_encode($RETURN_ARR);


}


function updateDisplayWebsite()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->news_id);
    $VAL = trustme($REQData->display_on_home);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . NEWS_TBL . "  SET "; 
    $STR .= " display_on_home = :display_on_home, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE news_id = :news_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":display_on_home", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":news_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}

	
function updateStatus()
{
    global $dCON, $REQData;
       
    $TIME = date("Y-m-d H:i:s");
    
    $ID = intval($REQData->news_id);
    $VAL = trustme($REQData->status);                           
    
    $TIME = date("Y-m-d H:i:s");
    $IP = trustme($_SERVER['REMOTE_ADDR']);
     
    $STR  = "";
    $STR .= " UPDATE  " . NEWS_TBL . "  SET "; 
    $STR .= " status = :status, ";
    $STR .= " update_by = :update_by, ";
    $STR .= " update_ip = :update_ip, ";
    $STR .= " update_time = :update_time ";
    $STR .= " WHERE news_id = :news_id ";
    $sDEF = $dCON->prepare($STR); 
    $sDEF->bindParam(":status", $VAL); 
    $sDEF->bindParam(":update_ip", $IP);
    $sDEF->bindParam(":update_by", $_SESSION['USERNAME']);
    $sDEF->bindParam(":update_time", $TIME);
    $sDEF->bindParam(":news_id", $ID);
    $RES = $sDEF->execute();
    $sDEF->closeCursor();         
    
    $RETURN_ARRAY = array();
    
    if ( intval($RES) == intval(1) )
    {     
        echo '~~~1~~~DONE~~~' . $ID . "~~~"; 
        
        $RETURN_ARRAY['SUCCESS'] = 1;
        $RETURN_ARRAY['MSG'] = "Done";
     }
    else
    {
        $RETURN_ARRAY['SUCCESS'] = 0;
        $RETURN_ARRAY['MSG'] = "Error";
    }
    
    echo json_encode($RETURN_ARRAY);     
}
			 

?>

