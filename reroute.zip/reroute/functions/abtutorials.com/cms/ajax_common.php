<?php
session_start();
error_reporting(0);
//include( "ajax_include.php"); 
include("config-cms.php");

$REQDataRaw = file_get_contents("php://input");
$REQData = json_decode($REQDataRaw);
//$REQ = $REQData->call;

$type =  trustme($REQData->type);

switch($type)
{
    case "getYear":
        getYear();
        break;
    case "getProductType":
        getProductType();
        break;
        
}

function getYear()
{
    global $dCON, $REQData;
    
    $show_data = trustme($REQData->show_data);
    $uptoValue = floatval($REQData->uptoValue);
    
    
    
    $SQL = "";
    $SQL .= " SELECT Y.year_id, Y.year_value FROM " . YEAR_TBL . " AS Y ";
    $SQL .= " where  status= 1 ";
    if($show_data !='All' || $show_data=='')
    {
        $SQL .= " and show_initial = 1 ";
    }
    
    if( intval($uptoValue) > intval(0))
    {
        $SQL .= " and Y.year_value <= '$uptoValue' ";
    }
    
    $SQL .= " ORDER BY Y.year_value ";
    $stmt = $dCON->prepare($SQL); 
    $stmt->execute();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $RETURN_ARRAY = array();    
    $RETURN_ARRAY['SQL'] = $SQL;
    $RETURN_ARRAY['dataRow'] = $row;    
    
    echo json_encode($RETURN_ARRAY);  
    
}

function getProductType()
{
    global $dCON, $REQData;
   
    $SQL = "";
    $SQL .= " SELECT product_type_id, product_type_name,product_type_Prefix FROM " . PRODUCT_TYPE_TBL . " AS A ";
    $SQL .= " WHERE A.status = '1' ";
    $SQL .= " ORDER BY A.product_type_name ";
    
    $stmt = $dCON->prepare($SQL); 
    $stmt->execute();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $RETURN_ARRAY = array();
    
    $RETURN_ARRAY['dataRow'] = $row;
    
    //sleep(5);
    echo json_encode($RETURN_ARRAY);    
    
}





?>