<?php 
error_reporting(0);
include("header.php");
 
?>


<div id="fullPageLoader" ng-show="fullPageLoader">
	<img id="loading-image" src="<?php echo LOGIN_IMAGES; ?>load.gif" alt="Loading..." />
</div>


<div ng-controller="changePasswordController">
    
    <div class="headingWrap">
    	<div class="container">
    		<div class="headingTitle">
    			<h1>{{addTitle}}</h1>
    		</div>
    	</div>
    </div> 
    
    
    
    <div class="">
    	<div class="container mainWrp">
			<form name="frmUser" id="frmUser" novalidate ng-submit="frmUser.$valid && submit()" autocomplete="off">
				<div class="panel panel-default chanPsd">
					<div class="panel-body addCuntry">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group" ng-class="{ 'has-error' : frmUser.admin_password.$invalid && !frmUser.admin_password.$pristine }">
									<label for="">New Password</label>
									<input type="password" class="form-control" placeholder="" maxlength="20" id="admin_password" name="admin_password" autocomplete="off" ng-model="dataFrm.admin_password" ng-minlength="4" ng-maxlength="20" required  ng-class="{'errorField': !dataFrm.admin_password}"/>
               						<p ng-show="frmUser.admin_password.$error.required && frmUser.admin_password.$dirty" class="help-block" ng-clock>Required</p>
               						<p ng-show="!frmUser.admin_password.$error.required && (frmUser.admin_password.$error.minlength || frmUser.admin_password.$error.maxlength) && frmUser.admin_password.$dirty" class="help-block" ng-clock>Passwords must be between 4 and 20 characters.</p>
								</div>
							</div>

							<div class="col-md-12">
								<div class="form-group" ng-class="{ 'has-error' : frmUser.admin_password_c.$invalid && !frmUser.admin_password_c.$pristine }">
									<label for="">Confirm Password</label>
									<input type="password" class="form-control" placeholder="" maxlength="20" id="admin_password_c" autocomplete="off" name="admin_password_c" ng-model="dataFrm.admin_password_c" ng-minlength="4" valid-admin_password-c required  ng-class="{'errorField': !dataFrm.admin_password_c || dataFrm.admin_password != dataFrm.admin_password_c}"/>
									<p ng-show="frmUser.admin_password_c.$error.required && frmUser.admin_password_c.$dirty" class="help-block" ng-clock>Please confirm your Password.</p>
									<p ng-show="!frmUser.admin_password_c.$error.required && (frmUser.admin_password_c.$error.minlength || frmUser.admin_password_c.$error.maxlength) && frmUser.admin_password_c.$dirty" class="help-block">Passwords must be between 4 and 20 characters.</p>
				                 </div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<button class="btn btn-primarys" type="submit" name="submit" ng-if="submitProcess == 0" ng-disabled="frmUser.$invalid || dataFrm.admin_password != dataFrm.admin_password_c"><i class="fa fa-lock" aria-hidden="true"></i> Change Password</button>
									<!-- <button class="btn btn-danger" type="button" name="cancel" ng-if="submitProcess == 0" ng-click="cancel()">Cancel</button> -->
                                    <div ng-if="submitProcess == 1" ng-clock>
										<img src="<?php echo LOGIN_IMAGES; ?>load.gif" width="30" align="absmiddle" />
										Processing...
									</div>
									
                                    <div ng-if="submitProcess == 2" ng-clock>
            							<div class="col-md-12">
            								<div ng-bind-html="submitProcessMsg"></div>
            							</div>
            						</div>
                                    
								</div>
							</div>
						</div>
						
						
					</div>
				</div>
			</form>
    		       
    	</div>
    </div> 
   
</div> <!-- content-wrapper end -->
     
<script>
(function(){
    
    angular.module('iwsApp').controller('changePasswordController', ['$http', 'myConfig', '$location', '$routeParams', '$scope', '$timeout', 'Upload', function($http, myConfig, $location, $routeParams, $scope, $timeout, Upload){
           
        $scope.addTitle = 'Change Password';
             
        $scope.dataFrm = {};
        $scope.dataFrm.status = 1;
        $scope.submitProcess = 0;
        $scope.fullPageLoader = 0;
                
        $scope.submit = function() {
            $scope.submitProcess = 1;
            $scope.dataFrm.type = 'changepassword';
          
            //$http({method: 'POST', url: myConfig.ajax_url, data: $scope.dataFrm}).success(function(response){
            $http({method: 'POST', url: 'ajax_changepassword.php', data: $scope.dataFrm}).success(function(response){
                
                //console.log(response)
                //alert(response.SUCCESS);                
                  $scope.submitProcess = 2;
    
                  if(response.SUCCESS == '1')
                  {
                      $scope.submitProcessMsg = '&#x2714; Successfully Changed';
    
                  }
                  else if(response.SUCCESS == '2')
                  {
                      $scope.submitProcessMsg = 'Both password do not match';
                  }
                  else
                  {
                      $scope.submitProcessMsg = '&#x2718; Sorry Cannot Process Your Request';
                  }
    
                 
                  $timeout(function(){
                      //$scope.submitProcess = 0;
                      if(response.SUCCESS == '1') {
                       
                          //$scope.dataFrm = {};
                          //location.href = 'index.php';
                         location.reload();
                         
                      }
                  }, 2000);
    
              });
            
            
        };
          
          
    }]); 
    
})();
</script>
<?php
include("footer.php");
?>