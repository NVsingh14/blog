<?php 
class Main{

public $dbo;
	
	 public function __construct() {
	
	$host_name ="localhost";
     $database ="admin";
  $username ="root";
  $password ="";
 		try {
 			$dbo = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
 		} catch (PDOException $e) {
 			print "Error!: " . $e->getMessage() . "<br/>";
 		
 		}
}
	


	public function category_add($cat_name,$meta_title,$keyword,$description,$slug)
	{
		global $dbo;
		$q = "insert into category set cat_name=:cat_name,meta_title=:meta_title,keyword=:keyword,description=:description,slug=:slug ";
		$sql=$dbo->prepare($q);
		$sql->bindParam(':cat_name',$cat_name,PDO::PARAM_STR,200);
		$sql->bindParam(':meta_title',$meta_title,PDO::PARAM_STR,200);
		$sql->bindParam(':keyword',$keyword,PDO::PARAM_STR,200);
		$sql->bindParam(':description',$description,PDO::PARAM_STR,200);
		$sql->bindParam(':slug',$slug,PDO::PARAM_STR,200);
		
		$sql->execute();
		$no=$sql->rowCount();
		if($no>0)
		{
			return 1;
			
		}
		else{
			return 0;
		}
		
	}
	public function category_update($id,$cat_name,$meta_title,$keyword,$description,$slug)
	{
		global $dbo;
		$q = "update category set cat_name=:cat_name,meta_title=:meta_title,keyword=:keyword,description=:description,slug=:slug where cat_id='".$id."'";
		$sql=$dbo->prepare($q);
		$sql->bindParam(':cat_name',$cat_name,PDO::PARAM_STR,200);
		$sql->bindParam(':meta_title',$meta_title,PDO::PARAM_STR,200);
		$sql->bindParam(':keyword',$keyword,PDO::PARAM_STR,200);
		$sql->bindParam(':description',$description,PDO::PARAM_STR,200);
		$sql->bindParam(':slug',$slug,PDO::PARAM_STR,200);

		return $sql->execute();
	}

	public function delete_data($id,$table,$field)
	{
		global $dbo;
		$q = "delete from $table where $field='".$id."'";
		$sql=$dbo->prepare($q);
		return $sql->execute();
	}

	public function removeImage($id,$table,$field,$field_id)
	{
		global $dbo;
		$img = $dbo->prepare("select $field from $table where $field_id='".$id."' ");
		$img->execute();
		$no=$img->rowCount();
		if($no>0)
		{

		$q = "update $table set $field='' where $field_id='".$id."' ";
		$sql = $dbo->prepare($q);
		$sql->execute();
		if($sql)
		{
			$row=$img->fetch(PDO::FETCH_ASSOC);
			$file = "image/".$row[$field];
			if(unlink($file) )
			{
				$returnArr = 1;
			}
			else
			{
				$returnArr = 0;
			}
		}

		} //end of if
	else 	{
				$returnArr = 2;
			} //end of else
		return $returnArr;
	}

	public function sub_category_add($cat_id,$sub_cat_name,$meta_title,$keyword,$description,$slug)
	{
		global $dbo;
		$q = "insert into sub_category set cat_id=:cat_id,sub_cat_name=:sub_cat_name,meta_title=:meta_title,keyword=:keyword,description=:description,slug=:slug ";
		//echo $q;
		//die();
		$sql=$dbo->prepare($q);
		$sql->bindParam(':cat_id',$cat_id,PDO::PARAM_STR,200);
		$sql->bindParam(':sub_cat_name',$sub_cat_name,PDO::PARAM_STR,200);
		$sql->bindParam(':meta_title',$meta_title,PDO::PARAM_STR,200);
		$sql->bindParam(':keyword',$keyword,PDO::PARAM_STR,200);
		$sql->bindParam(':description',$description,PDO::PARAM_STR,200);
		$sql->bindParam(':slug',$slug,PDO::PARAM_STR,200);
		
		$sql->execute();
		$no=$sql->rowCount();
		if($no>0)
		{
			return 1;
			
		}
		else{
			return 0;
		}
		
	}

	public function Subcategory_update($id,$cat_id,$subcat_name,$meta_title,$keyword,$description,$slug)
	{
		global $dbo;
		$q = "update sub_category set cat_id=:cat_id,sub_cat_name=:subcat_name,meta_title=:meta_title,keyword=:keyword,description=:description,slug=:slug where sub_cat_id='".$id."'";
		$sql=$dbo->prepare($q);
		$sql->bindParam(':cat_id',$cat_id,PDO::PARAM_STR,200);
		$sql->bindParam(':subcat_name',$subcat_name,PDO::PARAM_STR,200);
		$sql->bindParam(':meta_title',$meta_title,PDO::PARAM_STR,200);
		$sql->bindParam(':keyword',$keyword,PDO::PARAM_STR,200);
		$sql->bindParam(':description',$description,PDO::PARAM_STR,200);
		$sql->bindParam(':slug',$slug,PDO::PARAM_STR,200);

		return $sql->execute();

	}


	public function product_add($prd_name,$item_code,$desc,$price,$discount_flat,$discount_percent,$slug,$feature_img)
	{
		global $dbo;
		$q = "insert into product set product_name=:prd_name,item_code=:item_code,description=:desc,price=:price,discount_flat=:discount_flat,discount_percent=:discount_percent,slug=:slug,feature_img=:feature_img ";
		//echo $q;
		//die();
		$sql=$dbo->prepare($q);
		$sql->bindParam(':prd_name',$prd_name,PDO::PARAM_STR,200);
		$sql->bindParam(':item_code',$item_code,PDO::PARAM_STR,200);
		$sql->bindParam(':desc',$desc,PDO::PARAM_STR,200);
		$sql->bindParam(':price',$price,PDO::PARAM_STR,200);
		$sql->bindParam(':discount_flat',$discount_flat,PDO::PARAM_STR,200);
		$sql->bindParam(':discount_percent',$discount_percent,PDO::PARAM_STR,200);
		$sql->bindParam(':slug',$slug,PDO::PARAM_STR,200);
		$sql->bindParam(':feature_img',$feature_img,PDO::PARAM_STR,200);
		
		$sql->execute();
		$no=$sql->rowCount();
		if($no>0)
		{
			return 1;
			
		}
		else{
			return 0;
		}
		
	}

	public function product_update($id,$prd_name,$item_code,$description,$prd_price,$discount_flat,$discount_percent,$slug,$img)
	{
		global $dbo;
		$q = "update product set product_name=:prd_name,item_code=:item_code,description=:description,price=:price,discount_flat=:discount_flat,discount_percent=:discount_percent,slug=:slug,feature_img=:feature_img where p_id='".$id."'";
		echo $q;
		$sql = $dbo->prepare($q);
		$sql->bindParam(':prd_name',$prd_name,PDO::PARAM_STR,200);
		$sql->bindParam(':item_code',$item_code,PDO::PARAM_STR,200);
		$sql->bindParam(':description',$description,PDO::PARAM_STR,200);
		$sql->bindParam(':price',$prd_price,PDO::PARAM_STR,200);
		$sql->bindParam(':discount_flat',$discount_flat,PDO::PARAM_STR,200);
		$sql->bindParam(':discount_percent',$discount_percent,PDO::PARAM_STR,200);
		$sql->bindParam(':slug',$slug,PDO::PARAM_STR,200);
		$sql->bindParam(':feature_img',$img,PDO::PARAM_STR,200);

		return $sql->execute();
	}

} //class ends here
$objmain = new Main;
?>