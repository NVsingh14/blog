<?php 
class common {
	var $db;
	var $ip;
	var $time;
	public static $rowPerPage = 20;
	var $path_to_uploads = "";
	var $uploads_folder = "";
	var $temp_folder ="temp";
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "admin";
	public function __construct()
	{
		try{
			$this->db = new PDO("mysql:host=".$host,';dbname='.$dbname;$user,$pass);
		}
		catch(PDOException $e)
		{
			print "Error!".$e->getMessage()."<br>";
		}
		$this->ip = $_SERVER['REMOTE_ADDR'];
		$this->time = date("Y-m-d H:i:s");
	}

	public function trustme($var)
	{
		$filter = new inputfilter("","",0,0,1);
		return $filter->process(trim($var));
	}
	
	public function trustyou($var)
	{
		return trim($var);
	}

	public function trustHTML($var)
	{
		$filter = new inputfilter(array('table','div','p','td','tr','th','ul','li','b','strong'),"",1,1,1 );
		return $filter->process(trim($var));
	}
}
?>