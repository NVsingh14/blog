<?php 

class Process extends common{

	public function __construct()
	{
		parent::__construct();

	}
	private function _flashAndRedirect($success,$succssmsg,$failmsg)
	{
		if($success)
		{
			return array('SUCCESS'=> 1, "MSG"=>$succssmsg);
		}
		else
		{
			return array('SUCCESS'=>0,'MSG'=>$failmsg);
		}
	}

	public function startProcessing() {
		if(preg_match('/^[a-zA-Z0-9]+$/',$this->REQData->stype)) {
			$function = $this->trustme($this->REQData->stype);
			$return = $this->$function();
			echo json_encode($return);
		} else {
			echo "Invalid Request";
			exit;
		}
	}

	public function checkDuplicate()
	{
		$dupArr = array(":cat_name"=>$this->trustme($this->REQData->cat_name));

		$SQL="";
		$SQL .= "SELECT COUNT(*) as CT FROM ". $this->table. " WHERE cat_name = :cat_name AND `status` <> 2 ";

		if(isset($this->REQData->cat_id) && $this->REQData->cat_id > 0) {
			$SQL .= "AND cat_id <> :cat_id";
			$dupArr[':cat_id'] = $this->REQData->cat_id;
		}

		$stmt = $this->db->prepare($SQL);
		$res = $stmt->execute($dupArr);
		$rowObj = $stmt->fetchObject();
		$stmt->closeCursor();
		return intval($rowObj->CT);
	}

}
?>