(function(){

	var app = angular.module("isaydryfruitApp", ['ngRoute', 'ngSanitize', 'ngAnimate', 'ngMessages', 'uiSwitch', 'ckeditor', 'ngFileUpload', 'angularUtils.directives.dirPagination', 'checklist-model', 'dndLists', '720kb.datepicker']);

	app.constant("myConfig", {
		"ajax_url": "process.php",
		"upload_url": "upload.php",
	});

	app.filter('capitalize', function() {
		return function(input) {
			return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
		}
	});

	app.directive('stringToNumber', function() {
    return {
      require: 'ngModel',
      link: function(scope, element, attrs, ngModel) {
        ngModel.$parsers.push(function(value) {
          return '' + value;
        });
        ngModel.$formatters.push(function(value) {
          return parseFloat(value);
        });
      }
    };
  });


	// == UPDATE STATUS ==
	app.directive('updateStatusDiv', ['$http', 'myConfig', function($http, myConfig) {
		var directive = {};
		directive.restrict = 'E';

		directive.scope = {
			listObject: '=',
			call: '@',
			stype: '@',
			tableId: '='
		};

		directive.template = '<div ng-init="listObject.loading = false" >' +
									'<a href="javascript: void(0)" ng-click="updateStatus(listObject)" ng-hide="listObject.loading">' +
										'<i ng-show="listObject.status == 1" class="fas fa-eye"></i>' +
										'<i ng-show="listObject.status == 0" class="fas fa-eye-slash"></i>' +
									'</a>' +
								'</div>';

		directive.compile = function(element, attributes) {
			//linkFunction is linked with each element with scope to get the element specific data.
			var linkFunction = function($scope, element, attrs) {
				// console.log($scope.listObject, $scope.tableId, $scope.call, $scope.stype);

				$scope.updateStatus = function(listObj) {
					// console.log('updateStatus', listObj, $scope.table_id);
					if (parseInt(listObj.status) == parseInt(1)) {
						new_status = 0;
					} else {
						new_status = 1;
					}
					
					$scope.listObject.loading = true;
					
					$http({method: 'POST', url: myConfig.ajax_url, data: {call: $scope.call, stype: $scope.stype, table_id: $scope.tableId, new_status: new_status}}).then(function(response){
						//console.log(response);
						$scope.listObject.loading = false;
						$scope.listObject.status = new_status;
					});
				};
			};

			return linkFunction;
		}
		return directive;
	}]);
	// == END - UPDATE STATUS ==


/*	<td align="center">
		<update-status-div list-object="departmentObj" table-id="departmentObj.department_id" call="Department" stype="updateStatus"></update-status-div>
	</td>*/
	
})();
