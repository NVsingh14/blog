angular.module('sonaApp').controller('addCategoryController', ['$http', 'myConfig', '$location', '$routeParams', '$scope', '$timeout', 'Upload', '$route','CategoryDetails', function($http, myConfig, $location, $routeParams, $scope, $timeout, Upload, $route,CategoryDetails) {

	$scope.dataFrm = {};
	//$scope.team_arr = [];
	$scope.addTitle = 'Add';
	$scope.fullPageLoader = 1;
	$scope.submitProcess = 0;
	$scope.submitProcessMsg = '';
		$timeout(function(){
			$scope.fullPageLoader = 0;
		}, 1000);

	
/*	$scope.options_english = {
		language: 'en',
		allowedContent: true,
		entities: false,
		extraPlugins: 'divarea'
	};

	$scope.options_german = {
		language: 'en',
		allowedContent: true,
		entities: false,
		extraPlugins: 'divarea'
	};*/


	/*$scope.onReady = function () {
		// ...
		//console.log("ckeditor is ready......");
	};*/


	if ($routeParams.id) { 
		$scope.fullPageLoader = 1;
		$scope.addTitle = 'Modify';
		var promise = CategoryDetails.getEditableCategoryDetail($routeParams.id);

		promise.then(
			function(payload) {
				console.log(payload);
				$scope.dataFrm = payload.data.data;
				$scope.fuploading = 2;

				$timeout(function(){
					$scope.fullPageLoader = 0;
				}, 1000);
			},
			function(errorPayload) {
				console.log('failure loading category details', errorPayload);
			});

	} else {
		$scope.dataFrm.status = '1';
		$scope.fullPageLoader = 0;
	}
	$scope.cancel = function() {
		// $location.url("/homeBanner");
		$route.reload();
	};



	// Showcase Image
	/*$scope.fuploading = 0;
	$scope.uploadImage = function (file) {
		if (!file) {
			$scope.fuploading = 3;
			$scope.fileuploaderror = 'File not supported.'
			return;
		}

		Upload.upload({
			url: 'upload-multiple.php',
			data: {file: file}
		}).then(function (resp) {
			console.log('resp', resp);
			// console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
			if(resp.data.SUCCESS == "1") {
				$scope.dataFrm.product_img = resp.data.IMAGE_NAME;
				$scope.dataFrm.product_img_disp = resp.data.PATH_TO_IMAGE;
				$scope.fuploading = 2;
			} else {
				$scope.fileuploaderror = resp.data.MSG;
				$scope.dataFrm.product_img = '';
				$scope.fuploading = 3;
	
				$timeout(function(){
					$scope.fuploading = 0;
				}, 3000);
			}
			//console.log(resp.data.PATH_TO_IMAGE);
		}, function (resp) {
			console.log('Error status: ' + resp.status);
		}, function (evt) {
			var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
			//console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
			$scope.fuploading = 1;
		});
	};*/
	// End showcase image



	/*$scope.removeImage = function() {
		var c = confirm("Are you sure you wish to remove?");
		if (c) {
			$http({method: 'POST', url: myConfig.ajax_url, data: {stype: 'removeImage', call: 'category', 'category_id': $scope.dataFrm.category_id?$scope.dataFrm.category_id:0}}).then(function(response) {
				//$scope.fuploading = 0;
				//$scope.dataFrm.product_img = '';
				//$scope.dataFrm.product_img_disp = '';
			});
		}
	};*/


	$scope.submit = function() {
		$scope.submitProcess = 1;
		$scope.dataFrm.call = 'category';
		$scope.dataFrm.stype = 'saveData';
		//$scope.dataFrm.team_arr = $scope.team_arr;

		//console.log($scope.dataFrm);//return false;

		$http({method: 'POST', url: myConfig.ajax_url, data: $scope.dataFrm}).then(function(response){
			//console.log(response);
			$scope.submitProcess = 2;
			$scope.submitProcessMsg = response.data.MSG;

			$timeout(function(){
				$scope.submitProcess = 0;
				if (response.data.SUCCESS == '1') {
					$scope.dataFrm = {};
					 $location.url("/listCategory");
					$route.reload();
				} else {
					//$scope.dataFrm = {};
				}
			}, 3000);
		});
	};

}]);