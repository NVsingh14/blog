<?php
	require_once 'config.php';
	require_once 'global_function.php';
	defined("INC_CLASS") or die("Invalid Access");

	$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

	if ($isAjax) {
		$REQDataRaw = file_get_contents("php://input");
		$REQData = json_decode($REQDataRaw);
		$REQ = $REQData->call;

		if (preg_match('/^[a-zA-Z0-9_]+$/', $REQ)) {
			// continue script execution
			$className = $REQ;
			$obj = new $className; // prints namespacename\classname::__construct
			$obj->REQData = $REQData;
			$obj->startProcessing();
		} else {
			// PROBLEM WITH THE REQUEST ===============
			exit;
		}
	} else {
		$RETURN_ARR = array("SUCCESS" => 0, "MSG" => "Invalid request. Please refresh the page and try again.");
		echo json_encode($RETURN_ARR);
		exit;
	}

	

?>