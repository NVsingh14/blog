<?php
	ob_start();
	session_start();
	$thisDirectory = __DIR__.'/';
	require_once $thisDirectory.'library/main-config.php';

	define("INC_CLASS", "YES");
	define("CURRENT_TIME", date('H:i:s', time()), true);
	define("TODAY_DATE", date('Y-m-d'), true);

	require_once "library/common.class.php";
	require_once "library/inputfilter.class.php";

	// include_once $thisDirectory.'library/function.php';
	 include_once $thisDirectory.'global_function.php';

	function __autoload($className) { 
		if (file_exists("library/" . $className . '.class.php')) {
			require_once "library/" . $className . '.class.php';
			return true; 
		} 
		return false; 
	}

?>