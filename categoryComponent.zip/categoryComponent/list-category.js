angular.module('sonaApp').controller('listCategoryController', ['$scope', '$http', '$location', '$routeParams', 'myConfig', '$timeout', '$filter', 'CategoryDetails', function($scope, $http, $location, $routeParams, myConfig, $timeout, $filter, CategoryDetails){
    //$scope.allCategoryArray = {}; 
    $scope.searchedFields = {};
    $scope.dataFrm = {};
    $scope.fullPageLoader = 0;
    $scope.listPageLoader = 1;

    $scope.searchFrm = {};

    $scope.totalItems = 0;
    $scope.itemsPerPage = '20'; // this should match however many results your API puts on one page

    $scope.pagination = {
        current: $routeParams.page
    };

    
    //$scope.searchFrm.search_product_name = $location.search().search_product_name || "";
   // $scope.searchFrm.search_product_status = $location.search().search_product_status || "";

    $scope.pageChanged = function(newPage) {
        var objData = {};
        objData = $scope.searchFrm;
        objData.m = Math.random();
        $location.url("/listCategory/" + newPage + "/").search(objData);
    };

    var promise = CategoryDetails.getCategoryDetail();

    promise.then(
        function(payload) {
            console.log(payload);
           // $scope.allCategoryArray = payload.data.data;
            $scope.searchedFields = payload.data.searchedFields;
            $scope.totalItems = payload.data.total_records; 
            $scope.listPageLoader = 0;
			
            //console.log($scope.allCategoryArray);
            $scope.showCheckAll = true;
        },
        function(errorPayload) {
            console.log('failure loading category details', errorPayload);
            $scope.listPageLoader = 0;
        }
    );

    $scope.clearSearch = function() {
        $scope.searchFrm = {};
        $scope.searchFrm.m = Math.random();
        $location.url("/listCategory/1/").search($scope.searchFrm);
    };

    $scope.search = function() {
        $scope.searchFrm.m = Math.random();
        $location.url("/listCategory/1/").search($scope.searchFrm); 
    };

    ///============ FOR CHECK ALL CHECKBOX ================
    $scope.hId = {
        roles: []
    };

    $scope.checkAll = function(chk) {
        if(chk == "YES") {
            $scope.hId.roles = angular.copy($scope.allCategoryArray);
        } else {
            $scope.hId.roles = [];
        }
    };
    
    $scope.successMsg = '';
    ///////============ DELETE ALL ================================
    $scope.deleteAll = function() {

        if($scope.hId.roles.length > 0)
        {
            var c = confirm("Are you sure you wish to delete?");
            if(c)
            {
                $scope.fullPageLoader = 1;
                $http({method: 'POST', url: myConfig.ajax_url, data: {call: 'category', stype:'deleteAllData', 'DIDS': $scope.hId.roles}}).then(function(response){
                    //console.log(response);
                    $scope.successMsg = response.data.MSG;

                    $timeout(function(){
                        $scope.fullPageLoader = 0;
                        if(response.data.SUCCESS == '1')
                        {
                            $scope.pageChanged(1);
                        }
                    }, 2000);

                });
            }
        }
        else
        {
            alert("Please select a product");
        }


    };
    
    
    $scope.deleteData = function(did) {
        var c = confirm("Are you sure you wish to delete?");
        if(c)
        {
            $scope.fullPageLoader = 1;
            $http({method: 'POST', url: myConfig.ajax_url, data: {call: 'category', stype:'deleteData', 'category_id': did}}).then(function(response){
                $scope.successMsg = response.data.MSG;

                $timeout(function(){
                    $scope.fullPageLoader = 0;
                    if(response.data.SUCCESS == '1')
                    {
                        $scope.pageChanged(1);
                    }
                }, 2000);
            });
        }
    };
    
    $scope.updateStatus = function(category_id, category_current_status, $index) {
        //alert(category_id + "===" + category_current_status)
        if (parseInt(category_current_status) == parseInt(1)) {
            current_status = 0;
        } else {
            current_status = 1;
        }
        
        $scope.allCategoryArray[$index].loading = true;
        
         
        //// update ajax here ========
        $http({method: 'POST', url: myConfig.ajax_url, data: {call: 'category', stype:'updateStatus', category_id: category_id, product_status: current_status}}).then(function(response){
            //console.log(response);
            $scope.allCategoryArray[$index].loading = false;
            $scope.allCategoryArray[$index].status = current_status;
        });

        //console.log($scope.allCategoryArray);
    };
}]);
