angular.module('sonaApp').factory('CategoryDetails',['$http', 'myConfig', '$location', '$routeParams', function($http, myConfig, $location, $routeParams) {
	var factory = {};
	factory.getCategoryDetail = function(category_id) {

		// list all
		var objData = {};

		//objData.search_product_name = $location.search().search_product_name || "";
		//objData.search_product_status = $location.search().search_product_status || "";
		
		objData.call = "category";
		objData.stype = 'getCategoryDetail';
		objData.category_id = category_id;
		objData.showAll = "NO";
		objData.page = $routeParams.page;

		//console.log(objData);
		return $http({method: 'POST', url: myConfig.ajax_url, data:objData});
	};

	factory.getEditableCategoryDetail = function(category_id) {
		if (category_id) {
			var objData = {};
			
			objData.call = "category";
			objData.stype = 'getEditableCategoryDetail';
			objData.category_id = category_id;
			objData.showAll = "NO";
			objData.page = $routeParams.page;

			//console.log(objData);
			return $http({method: 'POST', url: myConfig.ajax_url, data:objData});
		} else
			return 0;
	};

	return factory;
 }]);