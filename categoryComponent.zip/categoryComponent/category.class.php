<?php
defined("INC_CLASS") or die("Invalid Access");
require_once '../library/imageresizer.class.php';
class category extends common {
	var $REQData;
	private $tbl_category = TBL_CATEGORY;
	//private $module_folder = PRODUCT_IMG_FOLDER;

	// Image Sizes
	// R300 = 300x300
	// R500 = 500x700
	// And original
	
	public function __construct() {
		parent::__construct();
		$this->path_to_uploads = '../';
	}
	
	public function startProcessing() { 
		if(preg_match('/^[a-zA-Z0-9_]+$/', $this->REQData->stype)) {
			$function = $this->trustme($this->REQData->stype);
			$return = $this->$function();
			// print_r($return);
			echo json_encode($return);
		} else {
			echo "Invalid Request";
			exit;
		} 
	}
	
	public function checkDuplicateCategory() {
		$dupArr = array(":category_name" => $this->trustme($this->REQData->category_name));

		$SQL = "";
		$SQL .= " SELECT COUNT(*) as CT FROM " . $this->tbl_category . " WHERE category_name = :category_name AND `status` <> 2 ";
		
		if (isset($this->REQData->category_id) && $this->REQData->category_id > 0) {
			$SQL .= " AND category_id <> :category_id ";
			$dupArr[":category_id"] = $this->REQData->category_id;
		}

		$stmt = $this->db->prepare($SQL);
		$res = $stmt->execute($dupArr);
		$rowObj = $stmt->fetchObject();
		$stmt->closeCursor();

		return (int)$rowObj->CT;
	}


	

	/*private function processGallery($category_id, $sub_folder) {
		if(isset($this->REQData->product_img) && trim($this->REQData->product_img) != "") {
			
			// Note 1: First Save File As it Upload ==================
			$FILE_NAME = $category_id . "-" . $this->REQData->product_img;
			
			//echo "\n=======$zipFOLDER";
			/// rename image ============
			$SOURCE_PATH =  $this->path_to_uploads . $this->temp_folder . "/" . $this->REQData->product_img;
			$DESTINATION_PATH = $this->path_to_uploads . $this->module_folder . "/" . $sub_folder . "/" . $FILE_NAME;
			
			rename($SOURCE_PATH, $DESTINATION_PATH);
			$file_type = getimagesize($DESTINATION_PATH);
			$work = new imageresizer($DESTINATION_PATH, $file_type['mime']);
			$work->resize(300, 300, $this->path_to_uploads . $this->module_folder . "/" . $sub_folder . "/R300-" . $FILE_NAME, "");
			$work->resize(500, 300, $this->path_to_uploads . $this->module_folder . "/" . $sub_folder . "/R500-" . $FILE_NAME, "");

			/// UPDATE =============
			$stmt = $this->db->prepare(" UPDATE " . $this->tbl_category . " SET product_image = :product_image WHERE category_id = :category_id ");
			$stmt->bindParam(":product_image", $FILE_NAME);
			$stmt->bindParam(":category_id", $category_id);
			$stmt->execute();
			$stmt->closeCursor();
			return array('SUCCESS' => 1);
		}
		return array('SUCCESS' => 0);
	}*/
	
	public function saveData() {
		//print_r($this->REQData);
		if ($this->checkDuplicateCategory() == 0 ) {
			$insArray = array(); 
			$insArray[':category_name'] = $this->trustme($this->REQData->category_name);
			// $insArray[':product_title_german'] = $this->trustme($this->REQData->product_title_german);
			// $insArray[':product_description_english'] = $this->trustyou($this->REQData->product_description_english);
			// $insArray[':product_description_german'] = $this->trustyou($this->REQData->product_description_german);
			$insArray[':meta_title_english'] = isset($this->REQData->meta_title_english)?$this->trustme($this->REQData->meta_title_english):'';
			
			$insArray[':meta_keyword_english'] = isset($this->REQData->meta_keyword_english)?$this->trustme($this->REQData->meta_keyword_english):'';
			
			$insArray[':meta_description_english'] = isset($this->REQData->meta_description_english)?$this->trustme($this->REQData->meta_description_english):'';
			
			
			$insArray[':add_ip'] = $this->trustme($this->ip);
			$insArray[':add_time'] = $this->time;
			//$insArray[':url_key'] = $this->createSlug($insArray[':product_name'], $this->tbl_category, 'url_key', 'category_id', isset($this->REQData->category_id)?(int)$this->REQData->category_id:0);
			
			$SQL = ""; 
			if (isset($this->REQData->category_id) && intval($this->REQData->category_id) > 0) {
				$SQL .= " UPDATE " . $this->tbl_category . " SET ";
				$SQL .= " update_ip = :add_ip, ";
				$SQL .= " update_time = :add_time, ";
			} else {
				$SQL .= " INSERT INTO " . $this->tbl_category . " SET ";
				$SQL .= " add_ip = :add_ip, "; 
				$SQL .= " add_time = :add_time, ";
			}

			$SQL .= " category_name = :category_name, ";
			// $SQL .= " product_title_german = :product_title_german, ";
			// $SQL .= " product_description_english = :product_description_english,  ";
			// $SQL .= " product_description_german = :product_description_german, ";
			$SQL .= " meta_title_english = :meta_title_english, ";
			//$SQL .= " meta_title_german = :meta_title_german, ";
			$SQL .= " meta_keyword_english = :meta_keyword_english, ";
			//$SQL .= " meta_keyword_german = :meta_keyword_german, ";
			$SQL .= " meta_description_english = :meta_description_english, ";
			//$SQL .= " meta_description_german = :meta_description_german ";

			if (isset($this->REQData->category_id) && intval($this->REQData->category_id) > 0) {
				$insArray[':category_id'] = intval($this->REQData->category_id);
				$SQL .= " WHERE category_id = :category_id "; 
			}

			$stmt = $this->db->prepare($SQL);
			$res = $stmt->execute($insArray); 
			$stmt->closeCursor();
			
			if (intval($res) == intval(1)) {
				if (!isset($this->REQData->category_id) || intval($this->REQData->category_id) == 0) {
					$lastId = intval($this->db->lastInsertId());
				} else {
					$lastId = intval($this->REQData->category_id);
				}

				/*try {
					$dir = $this->path_to_uploads . $this->module_folder . '/' . $lastId;
					$folder_name = $lastId;
					if (!file_exists($dir) || !is_dir($dir))
						mkdir($dir);
				} catch (Exception $e) {
					$folder_name = NO_FOLDER_FOLDER;
				}*/
				//$this->processGallery($lastId, $folder_name);
				return array("SUCCESS" => 1, 'MSG' => '&#x2714; Successfully Saved');
			} else
				return array("SUCCESS" => 0, 'MSG' => '&#x2757; Sorry Cannot Process Your Request');
		} else {
			return array("SUCCESS" => 2, 'MSG' => '&#x2757; Already Exists');
		}
	}

	/*public function removeImage() {
		$category_id = isset($this->REQData->category_id)?(int)$this->REQData->category_id:0;
		$PATH_TO_IMAGE = isset($this->REQData->product_img_disp)?$this->trustme($this->REQData->product_img_disp):'';

		$RETURN_ARRAY = array();
		$RETURN_ARRAY['SUCCESS'] = 0;
		$RETURN_ARRAY['MSG'] = "Sorry Cannot Process Your Request";
		
		if ($category_id > 0) {
			$stmtImg = $this->db->prepare(" SELECT product_image, category_id FROM " . $this->tbl_category . " WHERE category_id = :category_id ");
			$stmtImg->bindParam(":category_id", $category_id);
			$stmtImg->execute();
			$objImg = $stmtImg->fetchObject();
			$stmtImg->closeCursor();
			
			if(is_object($objImg)) {
				
				$file = $this->path_to_uploads . $this->module_folder . "/" . $objImg->category_id . "/R300-" . $objImg->product_image;
				if (file_exists($file) && is_file($file))
					unlink($file);
				
				$file = $this->path_to_uploads . $this->module_folder . "/" . $objImg->category_id . "/R500-" . $objImg->product_image;
				if (file_exists($file) && is_file($file))
					unlink($file);

				$file = $this->path_to_uploads . $this->module_folder . "/" . $objImg->category_id . "/" . $objImg->product_image;
				if (file_exists($file) && is_file($file))
					unlink($file);

				
				$stmtDel = $this->db->prepare(" UPDATE " . $this->tbl_category . " SET product_image='' WHERE category_id = :category_id ");
				$stmtDel->bindParam(":category_id", $category_id);
				$stmtDel->execute();
				$stmtDel->closeCursor();
				
				$RETURN_ARRAY['SUCCESS'] = 1;
				$RETURN_ARRAY['MSG'] = "Image Deleted";
			}
		} else {
			unlink($PATH_TO_IMAGE);
			$RETURN_ARRAY['SUCCESS'] = 1;
			$RETURN_ARRAY['MSG'] = "Image Deleted";
		}

		return $RETURN_ARRAY;
	}*/
	
	public function getCategoryDetail() {
		$category_id = isset($this->REQData->category_id)?(int)$this->REQData->category_id:0;
		$showAll = isset($this->REQData->showAll)?$this->REQData->showAll:0;

		$search_category_name = isset($this->REQData->search_category_name)?$this->REQData->search_category_name:'';
		$search_category_status = isset($this->REQData->search_category_status)?$this->REQData->search_category_status:'';
		$page = isset($this->REQData->page) && intval($this->REQData->page) != 0 ? $this->REQData->page : 1;
		
		$searchArr = array();

		$SQL = "SELECT TP.category_id,TP.category_name, TP.status
					FROM " . $this->tbl_category . " AS TP
					WHERE TP.`status` <> '2' ";

		if(trim($search_category_name) != "") {
			$searchArr[":category_name"] = "%" . $this->trustme($search_category_name) . "%";
			$SQL .= " AND category_name LIKE :category_name  ";
		}

		if((int)$category_id > 0) {
			$searchArr[":category_id"] = $category_id;
			$SQL .= " AND category_id = :category_id ";
		}

		if(trim($search_category_status) != "") {
			$searchArr[":status"] = intval($search_category_status);
			$SQL .= " AND TP.status = :status ";
		}

		$noOfRecords = 0;
		if ($showAll!=='YES') {
			$SQL_COUNT = "";
			$SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
				$SQL_COUNT .= $SQL;
			$SQL_COUNT .= " ) as aa ";

			$stmtCnt = $this->db->prepare($SQL_COUNT);
			$stmtCnt->execute($searchArr);
			$noOfRecords_row = $stmtCnt->fetchObject();
			$stmtCnt->closeCursor();
			$noOfRecords = intval($noOfRecords_row->CT);

		
			$rowsPerPage = common::$rowsPerPage;

			$page = intval($page) - 1;
			$offset = $rowsPerPage * $page ;
			
			$SQL .= " order by category_id ";
			$SQL .= " LIMIT " . $offset . "," . $rowsPerPage;
		} else {
			$SQL .= " order by category_id ";
		}

		//echo $SQL;
		$stmt = $this->db->prepare($SQL);
		$stmt->execute($searchArr);
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();

		$RETURN_DATA = array();
		$RETURN_DATA['SUCCESS'] = 1;
		$RETURN_DATA['MSG'] = '';
		$RETURN_DATA['total_records'] = $noOfRecords;
		$RETURN_DATA['data'] = $row;
		
		return $RETURN_DATA;
	}

	public function getEditableCategoryDetail() {
		if (!isset($this->REQData->category_id))
			return array('SUCCESS' => 0, 'MSG' => 'Sorry, cannot process your request.');

		$category_id = (int)$this->REQData->category_id;
		
		$searchArr = array();
//(CASE WHEN TP.product_image <> '' THEN CONCAT('" . $this->path_to_uploads . $this->module_folder . "/', TP.category_id, '/R300-" . "', TP.product_image) ELSE '' END ) as product_img_disp
		$SQL = "SELECT TP.category_id
					FROM " . $this->tbl_category . " AS TP
					WHERE TP.`status` <> '2'
						AND TP.category_id = :category_id LIMIT 1 ";
		$searchArr[":category_id"] = $category_id;

		//echo $SQL;
		$stmt = $this->db->prepare($SQL);
		$stmt->execute($searchArr);
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		$stmt->closeCursor();

		$RETURN_DATA = array();
		$RETURN_DATA['SUCCESS'] = 0;
		$RETURN_DATA['MSG'] = 'Sorry, cannot process your request.';

		if (!empty($row)) {
			$RETURN_DATA['SUCCESS'] = 1;
			$RETURN_DATA['MSG'] = '';
			$RETURN_DATA['data'] = $row;

			/*$sql = "SELECT T.image_id, T.image_name, T.is_featured,
						(CASE WHEN T.image_name <> '' THEN CONCAT('" . $this->path_to_uploads . $this->module_folder . "/', T.category_id, '/R300-" . "', T.image_name) ELSE '' END ) as PATH_TO_IMAGE
					FROM " . $this->tbl_category_img . " AS T WHERE T.category_id = :category_id ORDER BY T.position ";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(':category_id', $RETURN_DATA['data']['category_id']);
			$stmt->execute();
			$RETURN_DATA['data']['image_gallery'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			$stmt->closeCursor();*/
		}
		
		return $RETURN_DATA;
	}
	
	public function updateStatus() {
		$stmtDel = $this->db->prepare(" UPDATE " . $this->tbl_category . " SET `status` = :status WHERE category_id = :category_id ");
		$stmtDel->bindParam(":status", $this->REQData->product_status);
		$stmtDel->bindParam(":category_id", $this->REQData->category_id);
		$dRES = $stmtDel->execute();
		$stmtDel->closeCursor();
		
		if (intval($dRES) > 0) {
			return array("SUCCESS" => 1, "MSG" => "Successfully Saved");
		} else {
			return array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
		}
	}
	
	public function deleteData() { 
		$stmtDel = $this->db->prepare(" UPDATE " . $this->tbl_category . " SET `status` = '2' WHERE category_id = :category_id ");
		$stmtDel->bindParam(":category_id", $this->REQData->category_id);
		$dRES = $stmtDel->execute();
		$stmtDel->closeCursor();
		
		if(intval($dRES) > 0) {
			return array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
		} else {
			return array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
		}
	}
	
	public function deleteAllData() {
		$productIdsArray = @$this->REQData->DIDS;
		$successCTR = 0;

		foreach($productIdsArray as $productIdObj) {
			$stmtDel = $this->db->prepare(" UPDATE " . $this->tbl_category . " SET `status` = '2' WHERE category_id = :category_id ");
			$stmtDel->bindParam(":category_id", $productIdObj->category_id);
			$dRES = $stmtDel->execute();
			$stmtDel->closeCursor();
			
			if(intval($dRES) > 0) {
				$successCTR++;
			}
		}
		
		if ($successCTR > 0) {
			return array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
		} else {
			return array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
		}
	}

	public function __destruct() {}

} // class
?>