<?php
	// CMS CONFIG
	require_once '../config.php';
	defined("INC_CLASS") or die("Invalid Access");
	
?>