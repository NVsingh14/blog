
angular.module('isaydryfruitApp').config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider){
	$routeProvider

		.when("/welcome", {
            templateUrl: 'isaydryfruit-js/welcome.html'
		   })
		//Change Password
		.when("/changePassword", {
			title:'Change Password',
			templateUrl: 'isaydryfruit-js/changePasswordComponent/changePassword.html',
			controller: 'changePasswordController'
		})
		 //Category
		 .when("/addCategory", {
 			title:'Category',
            templateUrl: 'isaydryfruit-js/categoryComponent/addCategory.html',
            controller: 'addCategoryController'
		   })
		 .when("/addCategory/:id", {
 			title:'Category',
            templateUrl: 'isaydryfruit-js/categoryComponent/addCategory.html',
            controller: 'addCategoryController'
		   })
		 .when("/listCategory", {
 			title:'Category',
            templateUrl: 'isaydryfruit-js/categoryComponent/listCategory.html',
            controller: 'listCategoryController'
		   })
		 .when("/listCategory/:id", {
 			title:'CSR Activities',
            templateUrl: 'isaydryfruit-js/categoryComponent/listCategory.html',
            controller: 'listCategoryController'
		   })
		
		.otherwise({
			redirectTo: 'welcome'
		});

		$locationProvider.hashPrefix('');
}]).run(['$rootScope', '$route', '$location', function ($rootScope, $route, $location) {
	$rootScope.$route = $route;

	$rootScope.$on('$routeChangeSuccess',function(event,current,previous){
		if (current.$$route!==undefined && current.$$route.title!==undefined && current.$$route.title!='')
			document.title = current.$$route.title + ' | isaydryfruit';
	});


}]);
