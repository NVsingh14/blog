<?php
defined("INC_CLASS") or die("Invalid Access");
class subscribe extends common {
	var $REQData;
	private $module_folder = CAREER_FILE_FOLDER;
	
	public function __construct() {
		parent::__construct();
		$this->path_to_uploads = '';
		$this->all_uploads_folder = ALL_UPLOADS_FOLDER;
	}
	
	public function startProcessing() { 
		if(preg_match('/^[a-zA-Z0-9_]+$/', $this->REQData->fType)) {
			$function = $this->trustme($this->REQData->fType);
			$return = $this->$function();
			echo json_encode($return);
		} else {
			echo "Invalid Request";
			exit;
		} 
	}

	

	private function shootAMail() {
		//print_r($this->REQData);exit;

		if (!isset($this->REQData->subscribe_email) )
			
			return array('SUCCESS' => 0, 'MSG' => 'Please enter the required values.');
		else if (!$this->isValidEmail($this->REQData->subscribe_email))
			return array('SUCCESS' => 0, 'MSG' => 'Email Id entered is invalid.');
		else {

			$subject 	= 'New Subscription Request Received - '.COMPANY_NAME;
			$body = MAIL_HEADER;
			$body .= '	<body width="100%" bgcolor="#efefef" style="margin: 0; mso-line-height-rule: exactly;">
							<center style="width: 100%; background: #efefef; text-align: left;">
								<div style="width: 600px !important;max-width: 600px !important; margin: auto;border: 2px solid #000;" class="email-container">
									<!--[if mso]>
									<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" align="center">
									<tr>
									<td>
									<![endif]-->
									<!-- Email Body : BEGIN -->
									<table role="presentation" cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="width: 600px !important;max-width: 600px !important;">
										<tr>
											<td bgcolor="#ffffff" align="center" valign="top" style="padding: 20px 30px;">
											  <table width="100%" cellpadding="0" cellspacing="0" border="0" class="container">
												<tr>
												  <td width="100%" class="mobile" align="center" valign="top">
													 <a href="'.SITE_URL.'" target="_blank">
														  <img src="'.SITE_URL.'images-sona/logo.png" width="120" height="" alt="Sona BLW" border="0" align="center" style="width: 120px; max-width: 120px; height: auto; background: #ffffff; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555; margin: auto;" class="g-img">
													 </a>
												  </td>
												</tr>
											  </table>
											</td>
										</tr>

										<tr>
											<td bgcolor="#1F1F1F" align="center" valign="top" style="padding: 15px 30px;">
											  <table width="100%" cellpadding="0" cellspacing="0" border="0" class="container">
												<tr>
												  <td class="mobile" align="left" valign="top" style="font-family: sans-serif;font-size: 16px; line-height: 140%; color: #ffffff;">
													  <p style="margin: 0;font-size: 14px;color:#ffffff;">
														<strong style="text-transform: uppercase;font-size: 16px;">Dear Admin,</strong>
														<br>
														A new subscription request received from the following email id.
													  </p>
												  </td>
												</tr>
											  </table>
											</td>
										</tr>

										<!-- 1 Column Text + Button : BEGIN -->
										<tr>
											<td bgcolor="#ffffff">
												<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
													<tr>
														<td style="padding:30px 30px; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #333333;">
															<p style="margin: 0 0 10px 0;">Here are the details.</p>
															<p style="margin: 0 0 5px 0;"><strong>Email: </strong> '.$this->REQData->subscribe_email.'</p>
															
															
														</td>
													</tr>
												</table>
											</td>
										</tr>
										<!-- 1 Column Text + Button : END -->
									</table>
									<!-- Email Body : END -->';
			$body .= MAIL_FOOTER;
			$mail = MailObject(CAREER_FORM_EMAIL, COMPANY_NAME, COMPANY_NAME, '', '', $subject, $body, "");
			if ($mail)
				return array("SUCCESS" => 1, 'MSG' => 'Thank you for subscribing our newsletter.');
			else
				return array("SUCCESS" => 0, 'MSG' => 'Unable to process your request. Please try again.');
		}
	}
	
	public function __destruct() {
	}

} // class
?>