<?php
defined("INC_CLASS") or die("Invalid Access");
class common {
	public $db;
	public $ip;
	public $time;
	public static $rowsPerPage = 20;
	public $path_to_uploads = "";
	public $all_uploads_folder = ALL_UPLOADS_FOLDER;
	public $temp_folder = TEMP_FOLDER;

	public function __construct() {
		// open connection here
		try {
			$this->db = new PDO("mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME."",DB_USERNAME,DB_PASSWORD);
			
			$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );
			//$this->db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
			$this->db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
		} catch(Exception $e) {
			echo $e->getMessage();
		}
		$this->ip = isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'';
		$this->time = date("Y-m-d H:i:s");
	}
 
	public function trustme($var) {
		$filter = new inputfilter("","",0,0,1);
		return $filter->process(trim($var));
	}

	public function trustyou($var) {
		//return addslashes(trim($var));
		return trim($var);
	}

	public function createSlug($title, $table_name, $field_name, $field_name_id = "", $field_name_value = "") {
		$slug = preg_replace("/-$/", "", preg_replace('/[^a-z0-9]+/i', "-", strtolower($title)));
		
		$SQL  = "";
		$SQL .= " SELECT COUNT(*) AS NumHits FROM $table_name WHERE $field_name = :slug AND `status` <> '2' ";
		
		if( $field_name_id != "") {
			$SQL .= " AND $field_name_id <> $field_name_value ";
		}
		
		$stmt = $this->db->prepare($SQL);
		$stmt->bindParam(":slug", $slg);
		$slg = "{$slug}%"; 
		$stmt->execute();
		$rowStmt = $stmt->fetchObject();
		$stmt->closeCursor();
		$numHits = intval($rowStmt->NumHits);
		
		return ($numHits > 0) ? ($slug . '-' . $numHits) : $slug;
	}

	public function checkFileExists($file) {
		
		return (file_exists($file) && is_file($file))?SITE_ROOT.$file:false;
	}

	// Get first $lim characters without breaking the last word
	function read_more($str, $lim = 200) {
		$str = strip_tags($str);
		if (strlen($str)>$lim) {
			$pos = strpos($str, ' ', $lim);
			if ($pos)
				return substr($str, 0, $pos).'...';
			else
				return $str;
		}
		
		return $str;
	}

	public function isValidEmail($email) {
		return filter_var($email, FILTER_VALIDATE_EMAIL);
	}

}
?>
