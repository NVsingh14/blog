<?php
defined("INC_CLASS") or die("Invalid Access");
class media extends common {
	var $REQData;
	private $tbl_media = TBL_MEDIA;

	public function __construct() {
		parent::__construct();
	}

	public function startProcessing() { 
		if(preg_match('/^[a-zA-Z0-9_]+$/', $this->REQData->fType)) {
			$function = $this->trustme($this->REQData->fType);
			$return = $this->$function();
			echo json_encode($return);
		} else {
			echo "Invalid Request";
			exit;
		}
	}

	private function loadMore() {
		$page = (int)isset($this->REQData->page)?$this->REQData->page:1;

		$sql = "SELECT TM.media_date, TM.media_name, TM.media_desc, TM.media_type, TM.media_url, TM.url_key,
					CONCAT('".MEDIA_FOLDER."', TM.media_id, '/R300-', TM.media_img) AS path_to_image
					FROM " . $this->tbl_media . " AS TM
					WHERE TM.`status` = 1  ";

		$SQL_COUNT = "";
		$SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
			$SQL_COUNT .= $sql;
		$SQL_COUNT .= " ) as aa ";

		$stmtCnt = $this->db->prepare($SQL_COUNT);
		$stmtCnt->execute();
		$noOfRecords_row = $stmtCnt->fetchObject();
		$stmtCnt->closeCursor();
		$noOfRecords = intval($noOfRecords_row->CT);

		$rowsPerPage = PAGINATION_RECORDS;

		$offset = $rowsPerPage * ($page-1) ;
		
		$sql .= " ORDER BY TM.media_date DESC ";
		$sql .= " LIMIT " . $offset . "," . $rowsPerPage;

		//echo $sql;
		$stmt = $this->db->prepare($sql);
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();

		foreach ($row as $key => $rowObj) {
			$row[$key]['media_desc'] = $this->read_more($rowObj['media_desc'], 300);
			// $row[$key]['path_to_image'] = $this->checkFileExists($rowObj['path_to_image']);
			$row[$key]['url'] = $rowObj['media_type']==='URL'?$rowObj['media_url']:SITE_ROOT.'blog/'.$rowObj['url_key'].'.php';
			$row[$key]['target'] = $rowObj['media_type']==='URL'?'_blank':'_self';
		}
		

		return array('SUCCESS' => 1, 'MSG' => '', 'HASMORE' => $noOfRecords>$page*PAGINATION_RECORDS?true:false, 'DATA' => $row);
	}
}