<?php
	if ($_SERVER["HTTP_HOST"] == "localhost" ) {
		// Dev-mode
		ini_set("log_errors", 1);
		ini_set("error_log", $thisDirectory."Error.txt");
		ini_set('display_errors', 1); // set 0 in production
		ini_set('display_startup_errors', 1); // set 0 in production
		//error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE); // set 0 in production
		//error_reporting(E_ALL & ~ E_DEPRECATED); // set 0 in production
		//error_reporting(E_ERROR);
		error_reporting(E_ALL);

		$timezone = "Asia/Kolkata";
		// define("DEFAULT_TIME_UTC_OFFSET", 5.5);
		date_default_timezone_set($timezone);

		define("DB_HOST", "localhost");
		define("DB_USERNAME", "root");
		define("DB_PASSWORD", "");
		define("DB_NAME", "isaydryfruit");
		define("DB_PORT", 3306);

		define("FOLDERNAME", "isaydryfruit");
		define("SITE_ROOT", "/" . FOLDERNAME . "/");
		define("SITE_URL", "http://localhost/" . FOLDERNAME . "/");
		define("SITE_IMAGE", "/" . FOLDERNAME . "/" ."images-isaydryfruit"."/");
		define("SITE_CSS", "/" . FOLDERNAME . "/". "css-isaydryfruit" ."/");
		define("SITE_JS", "/" . FOLDERNAME . "/". "js-isaydryfruit" ."/");
	} else { // if (strtolower($_SERVER['SERVER_NAME'])==='sonablw.com')
		// Dev-mode - Replace 1 with 0 to be in Prod-mode
		ini_set("log_errors", 1);
		ini_set("error_log", $thisDirectory."Error.txt");
		ini_set('display_errors', 0); // set 0 in production
		ini_set('display_startup_errors', 0); // set 0 in production
		//error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE); // set 0 in production
		//error_reporting(E_ALL & ~ E_DEPRECATED); // set 0 in production
		//error_reporting(E_ERROR);
		error_reporting(E_ALL);

		$timezone = "Asia/Kolkata";
		// define("DEFAULT_TIME_UTC_OFFSET", 5.5);
		define("CAREER_FORM_EMAIL", "vishal@iws.in");
		define("FROM_EMAIL", "vishal@iws.in ");
		date_default_timezone_set($timezone);

		define("DB_HOST", "localhost");
		define("DB_USERNAME", "######");
		define("DB_PASSWORD", "######");
		define("DB_NAME", "########");
		define("DB_PORT", 3306);

		define("FOLDERNAME", "");
		define("SITE_ROOT", FOLDERNAME . "/");
		define("SITE_URL", "http://isaydryfruit.com" . FOLDERNAME . "/");
	// } else {
	// 	die("Invalid Access");
	}
	
	define("CMS_FOLDERNAME", "cms");
	define("CMS_ROOT", SITE_ROOT . CMS_FOLDERNAME . "/");
	define("CMS_IMAGES", "sona-images/");
	define("CMS_JS", "sona-js/");
	define("CMS_CSS",  "sona-css/");
	// define("CMS_FONT", "font-awesome/");

	define("COMPANY_NAME", "SONABLW");
	define("CAREER_FORM_EMAIL", "vishal@iws.in");
	define("FROM_EMAIL", "vishal@iws.in ");

	define("CONSTANT_PASSWORD_KEY", "SONA_LOGIN_KEY");

	define('MAIL_HEADER', '');
	define('MAIL_FOOTER', '');
	define('ALL_UPLOADS_FOLDER', 'sona_uploads');
	define('TEMP_FOLDER', ALL_UPLOADS_FOLDER.'/temp');
	define('TEMP_UPLOADS','temp/');
	define('NO_FOLDER_FOLDER', ALL_UPLOADS_FOLDER.'/no_folder'); // Just in case when a folder is not created. This acts as default folder
	define('NO_FOLDER_FOLDER_NAME', 'no_folder'); // Just in case when a folder is not created. This acts as default folder
	define('TECHNOLOGY_PAGE_IMG_FOLDER', ALL_UPLOADS_FOLDER.'/technology_img');
	define('PRODUCT_IMG_FOLDER', ALL_UPLOADS_FOLDER.'/product-img');
	define('CSR_ACTIVITIES_IMG_FOLDER', ALL_UPLOADS_FOLDER.'/csr-activities-img');
	define('CLIENT_IMG_FOLDER', ALL_UPLOADS_FOLDER.'/client-image');
	define('CLIENT_PAGE_IMG_FOLDER', ALL_UPLOADS_FOLDER.'/client-img/client-page-image');
	define('CAREER_PAGE_IMG_FOLDER', ALL_UPLOADS_FOLDER.'/career-image');
	define('CORE_VALUE_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/core-value');
	define('CERTIFICATION_POLICIES_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/certification-policies');
	define('AWARD_RECOGNITION_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/award-recognition');
	define('CONTACT_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/contact-img');
	define('SONA_CHAIRMAN_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/sona-chairman-img');
	define('SONA_BLW_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/sona-blw-img');
	define('MANAGEMENT_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/management-head');
	define('MANAGEMENT_TEAM_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/management-team');
	define('NEWS_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/news-image');
	define('HOME_PAGE_IMG_FOLDER',ALL_UPLOADS_FOLDER.'/homepage-image');
	define('HOME_PAGE_BANNER_FOLDER',ALL_UPLOADS_FOLDER.'/homepage-banner');
	define('CAREER_FILE_FOLDER',ALL_UPLOADS_FOLDER.'/career_uploads');

	

	// Tables
	define("TBL_TECHNOLOGY_PAGE", 'tbl_technology_pages');
	define("TBL_TECHNOLOGY_IMAGE", 'tbl_technology_image');
	define("TBL_PRODUCT","tbl_product");
	define("TBL_CSR_ACTIVITIES","tbl_csr_activities");
	define("TBL_CLIENT_PAGE","tbl_client_pages");
	define("TBL_CLIENT_IMAGE","tbl_client_image");
	define("TBL_CAREER_PAGE","tbl_career_page");
	define("TBL_CAREER_IMAGE", 'tbl_career_image');
	define("TBL_CORE_VALUE","tbl_core_value");
	define("TBL_CERTIFICATION_POLICIES","tbl_certification_policies");\
	define("TBL_AWARD_RECOGNITION","tbl_award_recognition");
	define("TBL_CONTACT","tbl_contact");
	define("TBL_SONA_BLW","tbl_sona_blw");
	define("TBL_SONA_CHAIRMEN","tbl_sona_chairmen");
	define("TBL_SONA_BLW_DESCRIPTION","tbl_sona_blw_description");
	define("TBL_MANAGEMENT_HEAD","tbl_management_head");
	define("TBL_MANAGEMENT_TEAM","tbl_management_team");
	define("TBL_NEWS","tbl_news");
	define("TBL_HOME_PAGE","tbl_home_page");
	define("TBL_HOME_PAGE_BANNER","tbl_home_page_banner");


	//define('PAGINATION_RECORDS', 20);
	
?>