<?php
defined("INC_CLASS") or die("Invalid Access");
class image_gallery extends common {
	var $REQData;
	private $tbl_project = TBL_PROJECT;
	private $tbl_project_img = TBL_PROJECT_IMG;

	public function __construct() {
		parent::__construct();
	}

	public function startProcessing() { 
		if(preg_match('/^[a-zA-Z0-9_]+$/', $this->REQData->fType)) {
			$function = $this->trustme($this->REQData->fType);
			$return = $this->$function();
			echo json_encode($return);
		} else {
			echo "Invalid Request";
			exit;
		}
	}

	private function loadMore() {
		if (!isset($this->REQData->category_id) || $this->REQData->category_id=='')
			return array('SUCCESS' => 0, 'MSG' => 'Sorry! Unable to process your request.', 'DATA' => '');

		$page = (int)isset($this->REQData->page)?$this->REQData->page:1;
		$searchArr['category_id'] = $this->REQData->category_id;

		$sql = "SELECT TP.project_id, TP.project_name, TP.url_key, TPI.position,
					CONCAT('".SITE_ROOT.PROJECT_IMG_FOLDER."/', TP.project_id, '/R300-', TPI.image_name) AS path_to_image
					FROM " . TBL_PROJECT_IMG . " AS TPI
					INNER JOIN " . TBL_PROJECT . " AS TP ON TPI.project_id = TP.project_id
					WHERE TP.`status` = 1 AND TP.category_id = :category_id AND TPI.is_featured = 1 ";

		$SQL_COUNT = "";
		$SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
			$SQL_COUNT .= $sql;
		$SQL_COUNT .= " ) as aa ";

		$stmtCnt = $this->db->prepare($SQL_COUNT);
		$stmtCnt->execute($searchArr);
		$noOfRecords_row = $stmtCnt->fetchObject();
		$stmtCnt->closeCursor();
		$noOfRecords = intval($noOfRecords_row->CT);

		$rowsPerPage = IMAGE_GALLERY_PAGINATION_FRONTEND;

		$offset = $rowsPerPage * ($page-1) ;
		
		$sql .= " ORDER BY TPI.category_position ";
		$sql .= " LIMIT " . $offset . "," . $rowsPerPage;

		//echo $sql;
		$stmt = $this->db->prepare($sql);
		$stmt->execute($searchArr);
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();
		

		return array('SUCCESS' => 1, 'MSG' => '', 'HASMORE' => $noOfRecords>$page*IMAGE_GALLERY_PAGINATION_FRONTEND?true:false, 'DATA' => $row);
	}
}