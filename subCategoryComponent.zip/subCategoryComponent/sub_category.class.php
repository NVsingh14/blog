<?php
defined("INC_CLASS") or die("Invalid Access");
require_once '../library/imageresizer.class.php';
class contact extends common {
	var $REQData;
	private $tbl_sub_category = TBL_SUB_CATEGORY;
	private $tbl_category = TBL_CATEGORY;
	//private $module_folder = CONTACT_IMG_FOLDER;


	
	public function __construct() {
		parent::__construct();
		$this->path_to_uploads = '../';
	}
	
	public function startProcessing() { 
		if(preg_match('/^[a-zA-Z0-9_]+$/', $this->REQData->stype)) {
			$function = $this->trustme($this->REQData->stype);
			$return = $this->$function();
			// print_r($return);
			echo json_encode($return);
		} else {
			echo "Invalid Request";
			exit;
		} 
	}
	
	public function checkDuplicateSubCategory() {
		$dupArr = array(":sub_category_name" => $this->trustme($this->REQData->sub_category_name));


		$SQL = "";
		$SQL .= " SELECT COUNT(*) as CT FROM " . $this->tbl_sub_category . " WHERE sub_category_name = :sub_category_name AND `status` <> 2 ";
		
		if (isset($this->REQData->sub_category_id) && $this->REQData->sub_category_id > 0) {
			$SQL .= " AND sub_category_id <> :sub_category_id ";
			$dupArr[":sub_category_id"] = $this->REQData->sub_category_id;
		}

		$stmt = $this->db->prepare($SQL);
		$res = $stmt->execute($dupArr);
		$rowObj = $stmt->fetchObject();
		$stmt->closeCursor();

		return (int)$rowObj->CT;
	}

	private function getCategoryList()
	{
		$sql = "SELECT category_id, category_name FROM " . $this->tbl_category . " WHERE status=1 ORDER BY category_name ";
		$stmt = $this->db->prepare($sql);
		$stmt->execute();
		$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();
		return array('SUCCESS' => 1, 'MSG' => '', 'DATA' => $rows);

	}

/*
	private function processImage($sub_category_id, $sub_folder) {
		if(isset($this->REQData->contact_img) && trim($this->REQData->contact_img) != "") {
			
			// Note 1: First Save File As it Upload ==================
			$FILE_NAME = $sub_category_id . "-" . $this->REQData->contact_img;
			
			//echo "\n=======$zipFOLDER";
			/// rename image ============
			$SOURCE_PATH =  $this->path_to_uploads . $this->temp_folder . "/" . $this->REQData->contact_img;
			$DESTINATION_PATH = $this->path_to_uploads . $this->module_folder . "/" . $sub_folder . "/" . $FILE_NAME;
			
			rename($SOURCE_PATH, $DESTINATION_PATH);
			$file_type = getimagesize($DESTINATION_PATH);
			$work = new imageresizer($DESTINATION_PATH, $file_type['mime']);
			$work->resize(300, 300, $this->path_to_uploads . $this->module_folder . "/" . $sub_folder . "/R300-" . $FILE_NAME, "");
			$work->resize(50, 50, $this->path_to_uploads . $this->module_folder . "/" . $sub_folder . "/R50-" . $FILE_NAME, "");
			$work->resize(1311,788, $this->path_to_uploads . $this->module_folder . "/" . $sub_folder . "/R1311-" . $FILE_NAME, "");

			/// UPDATE =============
			$stmt = $this->db->prepare(" UPDATE " . $this->tbl_sub_category . " SET contact_image = :contact_image WHERE sub_category_id = :sub_category_id ");
			$stmt->bindParam(":contact_image", $FILE_NAME);
			$stmt->bindParam(":sub_category_id", $sub_category_id);
			$stmt->execute();
			$stmt->closeCursor();
			return array('SUCCESS' => 1);
		}
		return array('SUCCESS' => 0);
	}*/
	
	public function saveData() {
		//print_r($this->REQData);
		if ($this->checkDuplicateSubCategory() == 0 ) {
			$insArray = array(); 
			$insArray[':category'] = $this->trustme($this->REQData->category);
			$insArray[':sub_category_name'] = $this->trustme($this->REQData->sub_category_name);
			$insArray[':meta_title'] = isset($this->REQData->meta_title)?$this->trustme($this->REQData->meta_title):'';
			$insArray[':meta_title_german'] = isset($this->REQData->meta_title_german)?$this->trustme($this->REQData->meta_title_german):'';
			$insArray[':meta_keyword'] = isset($this->REQData->meta_keyword)?$this->trustme($this->REQData->meta_keyword):'';
			$insArray[':meta_description'] = isset($this->REQData->meta_description)?$this->trustme($this->REQData->meta_description):'';
			
			
			$insArray[':add_ip'] = $this->trustme($this->ip);
			$insArray[':add_time'] = $this->time;
			
			$SQL = ""; 
			if (isset($this->REQData->sub_category_id) && intval($this->REQData->sub_category_id) > 0) {
				$SQL .= " UPDATE " . $this->tbl_sub_category . " SET ";
				$SQL .= " update_ip = :add_ip, ";
				$SQL .= " update_time = :add_time, ";
			} else {
				$SQL .= " INSERT INTO " . $this->tbl_sub_category . " SET ";
				$SQL .= " add_ip = :add_ip, "; 
				$SQL .= " add_time = :add_time, ";
			}

			$SQL .= " category = :category, ";
			$SQL .= " sub_category_name = :sub_category_name, ";
			$SQL .= " meta_title = :meta_title, ";
			$SQL .= " meta_keyword = :meta_keyword, ";
			$SQL .= " meta_description = :meta_description, ";
			

			if (isset($this->REQData->sub_category_id) && intval($this->REQData->sub_category_id) > 0) {
				$insArray[':sub_category_id'] = intval($this->REQData->sub_category_id);
				$SQL .= " WHERE sub_category_id = :sub_category_id "; 
			}

			$stmt = $this->db->prepare($SQL);
			$res = $stmt->execute($insArray); 
			$stmt->closeCursor();
			
			if (intval($res) == intval(1)) {
				if (!isset($this->REQData->sub_category_id) || intval($this->REQData->sub_category_id) == 0) {
					$lastId = intval($this->db->lastInsertId());
				} else {
					$lastId = intval($this->REQData->sub_category_id);
				}

				/*try {
					$dir = $this->path_to_uploads . $this->module_folder . '/' . $lastId;
					$folder_name = $lastId;
					if (!file_exists($dir) || !is_dir($dir))
						mkdir($dir);
				} catch (Exception $e) {
					$folder_name = NO_FOLDER_FOLDER;
				}*/
				//$this->processImage($lastId, $folder_name);
				return array("SUCCESS" => 1, 'MSG' => '&#x2714; Successfully Saved');
			} else
				return array("SUCCESS" => 0, 'MSG' => '&#x2757; Sorry Cannot Process Your Request');
		} else {
			return array("SUCCESS" => 2, 'MSG' => '&#x2757; Already Exists');
		}
	}

	/*public function removeImage() {
		$sub_category_id = isset($this->REQData->sub_category_id)?(int)$this->REQData->sub_category_id:0;
		$PATH_TO_IMAGE = isset($this->REQData->contact_img_disp)?$this->trustme($this->REQData->contact_img_disp):'';

		$RETURN_ARRAY = array();
		$RETURN_ARRAY['SUCCESS'] = 0;
		$RETURN_ARRAY['MSG'] = "Sorry Cannot Process Your Request";
		
		if ($sub_category_id > 0) {
			$stmtImg = $this->db->prepare(" SELECT contact_image, sub_category_id FROM " . $this->tbl_sub_category . " WHERE sub_category_id = :sub_category_id ");
			$stmtImg->bindParam(":sub_category_id", $sub_category_id);
			$stmtImg->execute();
			$objImg = $stmtImg->fetchObject();
			$stmtImg->closeCursor();
			
			if(is_object($objImg)) {
				
				$file = $this->path_to_uploads . $this->module_folder . "/" . $objImg->sub_category_id . "/R300-" . $objImg->contact_image;
				if (file_exists($file) && is_file($file))
					unlink($file);
				
				$file = $this->path_to_uploads . $this->module_folder . "/" . $objImg->sub_category_id . "/R50-" . $objImg->contact_image;
				if (file_exists($file) && is_file($file))
					unlink($file);

				$file = $this->path_to_uploads . $this->module_folder . "/" . $objImg->sub_category_id . "/R1311-" . $objImg->contact_image;
				if (file_exists($file) && is_file($file))
					unlink($file);

				$file = $this->path_to_uploads . $this->module_folder . "/" . $objImg->sub_category_id . "/" . $objImg->contact_image;
				if (file_exists($file) && is_file($file))
					unlink($file);

				
				$stmtDel = $this->db->prepare(" UPDATE " . $this->tbl_sub_category . " SET contact_image='' WHERE sub_category_id = :sub_category_id ");
				$stmtDel->bindParam(":sub_category_id", $sub_category_id);
				$stmtDel->execute();
				$stmtDel->closeCursor();
				
				$RETURN_ARRAY['SUCCESS'] = 1;
				$RETURN_ARRAY['MSG'] = "Image Deleted";
			}
		} else {
			unlink($PATH_TO_IMAGE);
			$RETURN_ARRAY['SUCCESS'] = 1;
			$RETURN_ARRAY['MSG'] = "Image Deleted";
		}

		return $RETURN_ARRAY;
	}
	*/
	public function getContactDetail() {
		$sub_category_id = isset($this->REQData->sub_category_id)?(int)$this->REQData->sub_category_id:0;
		$showAll = isset($this->REQData->showAll)?$this->REQData->showAll:0;

		$search_category = isset($this->REQData->search_category)?$this->REQData->search_category:0;
		$search_sub_category = isset($this->REQData->search_sub_category)?$this->REQData->search_sub_category:'';
		
		$page = isset($this->REQData->page) && intval($this->REQData->page) != 0 ? $this->REQData->page : 1;
		
		$searchArr = array();

		$SQL = "SELECT TP.sub_category_id,TP.sub_category_name,TP.category, TP.status,
					FROM " . $this->tbl_sub_category . " AS TP
					WHERE TP.`status` <> '2' ";

		if(trim($search_sub_category) != "") {
			$searchArr[":sub_category_name"] = "%" . $this->trustme($search_sub_category) . "%";
			$SQL .= " AND sub_category_name LIKE :sub_category_name ";
		}

		if(trim($search_category) != "") {
			$searchArr[":category"] =  $this->trustme($search_category);
			$SQL .= " AND category = :category  ";
		}


		

		if((int)$sub_category_id > 0) {
			$searchArr[":sub_category_id"] = $sub_category_id;
			$SQL .= " AND sub_category_id = :sub_category_id ";
		}

		

		$noOfRecords = 0;
		if ($showAll!=='YES') {
			$SQL_COUNT = "";
			$SQL_COUNT .= " SELECT COUNT(*) AS CT FROM ( ";
				$SQL_COUNT .= $SQL;
			$SQL_COUNT .= " ) as aa ";

			$stmtCnt = $this->db->prepare($SQL_COUNT);
			$stmtCnt->execute($searchArr);
			$noOfRecords_row = $stmtCnt->fetchObject();
			$stmtCnt->closeCursor();
			$noOfRecords = intval($noOfRecords_row->CT);

		
			$rowsPerPage = common::$rowsPerPage;

			$page = intval($page) - 1;
			$offset = $rowsPerPage * $page ;
			
			$SQL .= " order by sub_category_id ";
			$SQL .= " LIMIT " . $offset . "," . $rowsPerPage;
		} else {
			$SQL .= " order by sub_category_id ";
		}

		//echo $SQL;
		$stmt = $this->db->prepare($SQL);
		$stmt->execute($searchArr);
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$stmt->closeCursor();

		$RETURN_DATA = array();
		$RETURN_DATA['SUCCESS'] = 1;
		$RETURN_DATA['MSG'] = '';
		$RETURN_DATA['total_records'] = $noOfRecords;
		$RETURN_DATA['data'] = $row;
		
		return $RETURN_DATA;
	}

	public function getEditableSubCategoryDetail() {
		if (!isset($this->REQData->sub_category_id))
			return array('SUCCESS' => 0, 'MSG' => 'Sorry, cannot process your request.');

		$sub_category_id = (int)$this->REQData->sub_category_id;
		
		$searchArr = array();

		$SQL = "SELECT TP.sub_category_id, TP.sub_category_name,TP.category,TP.meta_title,TP.meta_keyword ,TP.meta_description
					FROM " . $this->tbl_sub_category . " AS TP
					WHERE TP.`status` <> '2'
						AND TP.sub_category_id = :sub_category_id LIMIT 1 ";
		$searchArr[":sub_category_id"] = $sub_category_id;

		//echo $SQL;
		$stmt = $this->db->prepare($SQL);
		$stmt->execute($searchArr);
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		$stmt->closeCursor();

		$RETURN_DATA = array();
		$RETURN_DATA['SUCCESS'] = 0;
		$RETURN_DATA['MSG'] = 'Sorry, cannot process your request.';

		if (!empty($row)) {
			$RETURN_DATA['SUCCESS'] = 1;
			$RETURN_DATA['MSG'] = '';
			$RETURN_DATA['data'] = $row;

			/*$sql = "SELECT T.image_id, T.image_name, T.is_featured,
						(CASE WHEN T.image_name <> '' THEN CONCAT('" . $this->path_to_uploads . $this->module_folder . "/', T.sub_category_id, '/R300-" . "', T.image_name) ELSE '' END ) as PATH_TO_IMAGE
					FROM " . $this->tbl_sub_category_img . " AS T WHERE T.sub_category_id = :sub_category_id ORDER BY T.position ";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(':sub_category_id', $RETURN_DATA['data']['sub_category_id']);
			$stmt->execute();
			$RETURN_DATA['data']['image_gallery'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			$stmt->closeCursor();*/
		}
		
		return $RETURN_DATA;
	}
	
	public function updateStatus() {
		$stmtDel = $this->db->prepare(" UPDATE " . $this->tbl_sub_category . " SET `status` = :status WHERE sub_category_id = :sub_category_id ");
		$stmtDel->bindParam(":status", $this->REQData->contact_status);
		$stmtDel->bindParam(":sub_category_id", $this->REQData->sub_category_id);
		$dRES = $stmtDel->execute();
		$stmtDel->closeCursor();
		
		if (intval($dRES) > 0) {
			return array("SUCCESS" => 1, "MSG" => "Successfully Saved");
		} else {
			return array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
		}
	}
	
	public function deleteData() { 
		$stmtDel = $this->db->prepare(" UPDATE " . $this->tbl_sub_category . " SET `status` = '2' WHERE sub_category_id = :sub_category_id ");
		$stmtDel->bindParam(":sub_category_id", $this->REQData->sub_category_id);
		$dRES = $stmtDel->execute();
		$stmtDel->closeCursor();
		
		if(intval($dRES) > 0) {
			return array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
		} else {
			return array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
		}
	}
	
	public function deleteAllData() {
		$contactIdsArray = @$this->REQData->DIDS;
		$successCTR = 0;

		foreach($contactIdsArray as $contactIdObj) {
			$stmtDel = $this->db->prepare(" UPDATE " . $this->tbl_sub_category . " SET `status` = '2' WHERE sub_category_id = :sub_category_id ");
			$stmtDel->bindParam(":sub_category_id", $contactIdObj->sub_category_id);
			$dRES = $stmtDel->execute();
			$stmtDel->closeCursor();
			
			if(intval($dRES) > 0) {
				$successCTR++;
			}
		}
		
		if ($successCTR > 0) {
			return array("SUCCESS" => 1, "MSG" => "Successfully Deleted");
		} else {
			return array("SUCCESS" => 0, "MSG" => "Sorry Cannot Process Your Request");
		}
	}

	public function __destruct() {}

} // class
?>