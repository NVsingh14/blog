angular.module('sonaApp').controller('addSubCategoryController', ['$http', 'myConfig', '$location', '$routeParams', '$scope', '$timeout', 'Upload', '$route','SubCategoryDetails', function($http, myConfig, $location, $routeParams, $scope, $timeout, Upload, $route,SubCategoryDetails) {

	$scope.dataFrm = {};
	$scope.addTitle = 'Add';
	$scope.fullPageLoader = 1;
	$scope.submitProcess = 0;
	$scope.submitProcessMsg = '';
	$scope.categoryListArr={};


	if ($routeParams.id) { 
		$scope.fullPageLoader = 1;
		$scope.addTitle = 'Modify';
		var promise = SubCategoryDetails.getEditableSubCategoryDetail($routeParams.id);

		promise.then(
			function(payload) {
				console.log(payload);
				$scope.dataFrm = payload.data.data;
				$scope.fuploading = 2;

				$timeout(function(){
					$scope.fullPageLoader = 0;
				}, 1000);
			},
			function(errorPayload) {
				console.log('failure loading details', errorPayload);
			});

	} else {
		$scope.dataFrm.status = '1';
		$scope.fullPageLoader = 0;
	}
	$scope.cancel = function() {
		// $location.url("/homeBanner");
		$route.reload();
	};


	$scope.getCategoryList = function()
	{
		$http({method: 'POST', url: myConfig.ajax_url, data: {call: 'sub_category', stype:'getCategoryList'}}).then(function(response){
			//console.log(response);
			//$scope.fullPageLoader = 0;
			if (response.data.SUCCESS===1) {
				$scope.categoryListArr = response.data.DATA;
			} else
				$scope.cancel();
		});
	}

	$scope.getCategoryList();



	// Showcase Image
	/*$scope.fuploading = 0;
	$scope.uploadImage = function (file) {
		if (!file) {
			$scope.fuploading = 3;
			$scope.fileuploaderror = 'File not supported.'
			return;
		}

		Upload.upload({
			url: 'upload-multiple.php',
			data: {file: file}
		}).then(function (resp) {
			console.log('resp', resp);
			// console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
			if(resp.data.SUCCESS == "1") {
				$scope.dataFrm.contact_img = resp.data.IMAGE_NAME;
				$scope.dataFrm.contact_img_disp = resp.data.PATH_TO_IMAGE;
				$scope.fuploading = 2;
			} else {
				$scope.fileuploaderror = resp.data.MSG;
				$scope.dataFrm.contact_img = '';
				$scope.fuploading = 3;
	
				$timeout(function(){
					$scope.fuploading = 0;
				}, 3000);
			}
			//console.log(resp.data.PATH_TO_IMAGE);
		}, function (resp) {
			console.log('Error status: ' + resp.status);
		}, function (evt) {
			var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
			//console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
			$scope.fuploading = 1;
		});
	};
	// End showcase image



	$scope.removeImage = function() {
		var c = confirm("Are you sure you wish to remove?");
		if (c) {
			$http({method: 'POST', url: myConfig.ajax_url, data: {stype: 'removeImage', call: 'contact', 'contact_id': $scope.dataFrm.contact_id?$scope.dataFrm.contact_id:0, 'contact_img': $scope.dataFrm.contact_img, 'contact_img_disp': $scope.dataFrm.contact_img_disp}}).then(function(response) {
				$scope.fuploading = 0;
				$scope.dataFrm.contact_img = '';
				$scope.dataFrm.contact_img_disp = '';
			});
		}
	};*/


	$scope.submit = function() {
		$scope.submitProcess = 1;
		$scope.dataFrm.call = 'sub_category';
		$scope.dataFrm.stype = 'saveData';
		//$scope.dataFrm.team_arr = $scope.team_arr;

		console.log($scope.dataFrm);return false;

		$http({method: 'POST', url: myConfig.ajax_url, data: $scope.dataFrm}).then(function(response){
			//console.log(response);
			$scope.submitProcess = 2;
			$scope.submitProcessMsg = response.data.MSG;

			$timeout(function(){
				$scope.submitProcess = 0;
				if (response.data.SUCCESS == '1') {
					$scope.dataFrm = {};
					 $location.url("/listSubCategory");
					$route.reload();
				} else {
					//$scope.dataFrm = {};
				}
			}, 3000);
		});
	};

}]);