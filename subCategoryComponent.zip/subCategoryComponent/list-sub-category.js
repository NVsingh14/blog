angular.module('sonaApp').controller('listSubCategoryController', ['$scope', '$http', '$location', '$routeParams', 'myConfig', '$timeout', '$filter', 'CategoryDetails', function($scope, $http, $location, $routeParams, myConfig, $timeout, $filter, CategoryDetails){
    $scope.allSubCategoryArray = {}; 
    $scope.searchedFields = {};
    $scope.dataFrm = {};
    $scope.fullPageLoader = 0;
    $scope.listPageLoader = 1;

    $scope.searchFrm = {};

    $scope.totalItems = 0;
    $scope.itemsPerPage = '20'; // this should match however many results your API puts on one page

    $scope.pagination = {
        current: $routeParams.page
    };

    
    //$scope.searchFrm.search_product_name = $location.search().search_product_name || "";
   // $scope.searchFrm.search_product_status = $location.search().search_product_status || "";

    $scope.pageChanged = function(newPage) {
        var objData = {};
        objData = $scope.searchFrm;
        objData.m = Math.random();
        $location.url("/listSubCategory/" + newPage + "/").search(objData);
    };

    var promise = CategoryDetails.getCategoryDetail();

    promise.then(
        function(payload) {
            console.log(payload);
            $scope.allSubCategoryArray = payload.data.data;
            $scope.searchedFields = payload.data.searchedFields;
            $scope.totalItems = payload.data.total_records; 
            $scope.listPageLoader = 0;
			
            //console.log($scope.allSubCategoryArray);
            $scope.showCheckAll = true;
        },
        function(errorPayload) {
            console.log('failure loading details', errorPayload);
            $scope.listPageLoader = 0;
        }
    );

    $scope.clearSearch = function() {
        $scope.searchFrm = {};
        $scope.searchFrm.m = Math.random();
        $location.url("/listSubCategory/1/").search($scope.searchFrm);
    };

    $scope.search = function() {
        $scope.searchFrm.m = Math.random();
        $location.url("/listSubCategory/1/").search($scope.searchFrm); 
    };

    ///============ FOR CHECK ALL CHECKBOX ================
    $scope.hId = {
        roles: []
    };

    $scope.checkAll = function(chk) {
        if(chk == "YES") {
            $scope.hId.roles = angular.copy($scope.allSubCategoryArray);
        } else {
            $scope.hId.roles = [];
        }
    };
    
    $scope.successMsg = '';
    ///////============ DELETE ALL ================================
    $scope.deleteAll = function() {

        if($scope.hId.roles.length > 0)
        {
            var c = confirm("Are you sure you wish to delete?");
            if(c)
            {
                $scope.fullPageLoader = 1;
                $http({method: 'POST', url: myConfig.ajax_url, data: {call: 'sub_category', stype:'deleteAllData', 'DIDS': $scope.hId.roles}}).then(function(response){
                    //console.log(response);
                    $scope.successMsg = response.data.MSG;

                    $timeout(function(){
                        $scope.fullPageLoader = 0;
                        if(response.data.SUCCESS == '1')
                        {
                            $scope.pageChanged(1);
                        }
                    }, 2000);

                });
            }
        }
        else
        {
            alert("Please select a product");
        }


    };
    
    
    $scope.deleteData = function(did) {
        var c = confirm("Are you sure you wish to delete?");
        if(c)
        {
            $scope.fullPageLoader = 1;
            $http({method: 'POST', url: myConfig.ajax_url, data: {call: 'sub_category', stype:'deleteData', 'sub_category_id': did}}).then(function(response){
                $scope.successMsg = response.data.MSG;

                $timeout(function(){
                    $scope.fullPageLoader = 0;
                    if(response.data.SUCCESS == '1')
                    {
                        $scope.pageChanged(1);
                    }
                }, 2000);
            });
        }
    };
    
    $scope.updateStatus = function(sub_category_id, category_current_status, $index) {
        //alert(sub_category_id + "===" + category_current_status)
        if (parseInt(category_current_status) == parseInt(1)) {
            current_status = 0;
        } else {
            current_status = 1;
        }
        
        $scope.allSubCategoryArray[$index].loading = true;
        
         
        //// update ajax here ========
        $http({method: 'POST', url: myConfig.ajax_url, data: {call: 'sub_category', stype:'updateStatus', sub_category_id: sub_category_id, product_status: current_status}}).then(function(response){
            //console.log(response);
            $scope.allSubCategoryArray[$index].loading = false;
            $scope.allSubCategoryArray[$index].status = current_status;
        });

        //console.log($scope.allSubCategoryArray);
    };
}]);
