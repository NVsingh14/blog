angular.module('sonaApp').factory('SubCategoryDetails',['$http', 'myConfig', '$location', '$routeParams', function($http, myConfig, $location, $routeParams) {
	var factory = {};
	factory.getSubCategoryDetail = function(sub_category_id) {

		// list all
		var objData = {};

		//objData.search_product_name = $location.search().search_product_name || "";
		//objData.search_product_status = $location.search().search_product_status || "";
		
		objData.call = "sub_category";
		objData.stype = 'getSubCategoryDetail';
		objData.sub_category_id = sub_category_id;
		objData.showAll = "NO";
		objData.page = $routeParams.page;

		//console.log(objData);
		return $http({method: 'POST', url: myConfig.ajax_url, data:objData});
	};

	factory.getEditableSubCategoryDetail = function(sub_category_id) {
		if (sub_category_id) {
			var objData = {};
			
			objData.call = "sub_category";
			objData.stype = 'getEditableSubCategoryDetail';
			objData.sub_category_id = sub_category_id;
			objData.showAll = "NO";
			objData.page = $routeParams.page;

			//console.log(objData);
			return $http({method: 'POST', url: myConfig.ajax_url, data:objData});
		} else
			return 0;
	};

	return factory;
 }]);